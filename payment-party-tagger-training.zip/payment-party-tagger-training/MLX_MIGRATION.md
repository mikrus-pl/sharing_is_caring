# Task brief: an MLX backend for party_tagger (Apple silicon)

**Dla użytkownika (PL):** ten plik jest instrukcją dla agenta (np. Claude Code) uruchomionego na Twoim Macu. Mówi mu,
jak dopisać do paczki drugi silnik liczący, MLX, tak żeby trening i uruchamianie modelu szły szybko na karcie
graficznej Maca. Wszystko inne (dane, kalibracja, routing, ocena, eksport) zostaje bez zmian. Agent pracuje małymi
krokami: każdy kończy się testem zgodności z obecnym kodem i krótkim raportem dla Ciebie po polsku. Pobieranie modeli
i długie treningi uruchamia dopiero po Twojej zgodzie.

---

## 1. Goal

Add an **MLX backend** next to the existing PyTorch one, so that on a Mac:
1. a trained run can be **used** (inference) through MLX, and
2. the v3 recipe can be **trained** through MLX,

with **the same file formats**: a run trained in MLX loads in PyTorch and vice versa, so the existing evaluation,
calibration, release gate (`scripts/check_release.py`) and comparison (`reproduce.py` step `compare`) judge the port.

**Definition of done (minimum, the user has little time):**
- inference parity on a trained run (section 8, steps 1–2);
- an MLX training run of **Gemma 4 E2B** with the v3 recipe that passes `check_release.py`;
- `reproduce.py --backend mlx` runs the whole pipeline.

**Stretch:** the same for E4B (needs about 32 GB of unified memory), and the comparison with the E4B reference within
1 percentage point.

## 2. Ground rules

- **Talk to the user in Polish**, simply; they are not an ML specialist. Report after every step: what works, numbers, next step.
- **Ask before downloading** base models (E2B 10.3 GB, E4B 16 GB) or other large files, and before any run longer than ~15 minutes.
- **Do not change** the recipe (`recipe_v3.json`), labels, data, tokenization, routing, calibration or the release
  criteria. If a hyperparameter seems to need changing for MLX, that is a bug in the port: find it.
- **The PyTorch path must keep working** and `python -m pytest -q` must stay green. New MLX tests skip when `mlx` is not installed.
- Keep the public naming: package `party_tagger`, model names `payment-party-tagger-gemma4-<e4b|e2b>`.
- Work in small, separately runnable steps. Save each step's evidence in `runs/mlx_port/` (logs, parity reports).

## 3. What already exists (read these first)

| File | What it does | Relevance |
|---|---|---|
| `src/party_tagger/backbone.py` | loads the Gemma 4 text model from the full checkpoint (`key_mapping` drops `model.language_model.`), `set_bidirectional`, PLE table on CPU | what to replicate |
| `src/party_tagger/tagger.py` | `SwiftTagger` (backbone → dropout 0.1 → `token_head`, `join_head`), `build_for_training`, `save_run`, `load_run` | heads, LoRA config, run format |
| `src/party_tagger/data.py` | `encode_text` (BOS + text, offsets), `encode_example` (token labels, join labels), `collate` (right padding) | reuse as is: it is plain Python + the HF tokenizer |
| `src/party_tagger/infer.py` | `Predictor.raw()` → per text `(offsets, token_logits, join_logits)` as CPU float32 torch tensors; `decode()` | **the single integration point for inference** |
| `src/party_tagger/device.py` | device choice (cuda/mps/cpu) | pattern for a backend switch |
| `scripts/train.py` | the training loop (section 6 copies it exactly) | spec for `train_mlx.py` |
| `scripts/evaluate.py`, `scripts/calibrate_routing.py`, `scripts/export_hf.py` | all get logits only through `Predictor.raw()` / `Predictor.predict()` | unchanged once `raw()` has an MLX backend |
| `reproduce.py`, `recipe_v3.json` | the pipeline and the recipe | add `--backend` |

## 4. The model to replicate exactly

| Part | Specification |
|---|---|
| Base | `google/gemma-4-E4B-it` (reference) or `google/gemma-4-E2B-it`. Text model only; vision/audio towers are not loaded. Weights in the checkpoint start with `model.language_model.` |
| Attention | **bidirectional**: no causal mask. `set_bidirectional` also halves the sliding window (512 → 257, symmetric). The longest field in all our data is **118 tokens**, so the window never binds: every layer is full attention over the non-padding tokens. Implement exactly that and **assert sequence length < 257** (otherwise the symmetric window would have to be implemented) |
| Padding | right padding with `pad_token_id = 0`; padded positions must be masked **as keys** in every layer (with bidirectional attention a missing padding mask changes the real tokens' outputs) |
| Gemma 4 details | per-layer embeddings (PLE, `hidden_size_per_layer_input`), KV sharing (`num_kv_shared_layers`, 18 in E4B: those layers have **no `k_proj`/`v_proj`** and reuse K/V of an earlier layer of the same type), per-layer `head_dim` (`per_layer_config`), partial rotary embeddings on full-attention layers, embedding scaling, final norm. Use mlx-lm's Gemma 4 implementation if it exists in the installed version; check that a **cache-less** forward still applies KV sharing |
| Output used | the **last hidden state after the final norm** (what HF `Gemma4TextModel(...).last_hidden_state` returns), not logits; no logit softcapping applies |
| Heads | `token_head = Linear(hidden, 16)`, `join_head = Linear(hidden, 2)`, both float32, on `dropout(0.1)(hidden.astype(float32))` (dropout only in training). `hidden` comes from the model config (E4B: 2560) |
| LoRA | rank 32, alpha 64, so the **scale is alpha / rank = 2.0**; dropout 0.05 on the LoRA input; targets `q_proj, k_proj, v_proj, o_proj, gate_proj, up_proj, down_proj` in **every** text layer where they exist (E4B: 258 modules). Init: A uniform(±1/sqrt(in)), B zeros |
| Precision | base weights bf16; matmuls in bf16; heads float32. PEFT keeps LoRA weights in float32; doing the same in MLX is the safest start |

**Do not use mlx-lm's LoRA defaults blindly.** Its `scale` is a direct multiplier, and the defaults are reportedly
`rank 8, scale 20`. With scale 20 instead of 2 the update is 10 times larger, which looks like "MLX needs a much
smaller learning rate". Set `rank=32, scale=2.0, dropout=0.05` explicitly and check in the installed `mlx_lm`
source how `scale` is applied.

## 5. File formats (interoperability)

A run folder (`runs/<name>/`) must look exactly like one from `scripts/train.py`:

```
adapter/adapter_config.json        # PEFT config (copy fields below)
adapter/adapter_model.safetensors  # PEFT tensor names and shapes
heads.safetensors                  # or heads.pt; load_run reads either
meta.json
train_log.jsonl
```

**`adapter_model.safetensors`** uses PEFT names, for example (E4B):
```
base_model.model.layers.0.mlp.down_proj.lora_A.weight   [32, 10240]   = (in → r)
base_model.model.layers.0.mlp.down_proj.lora_B.weight   [2560, 32]    = (r → out)
base_model.model.layers.0.self_attn.q_proj.lora_A.weight ...
```
PEFT stores `lora_A.weight` as `[r, in]` and `lora_B.weight` as `[out, r]`. Most MLX LoRA layers store `lora_a` as
`[in, r]` and `lora_b` as `[r, out]`, so **transpose both** when converting, and map the module path
(`model.layers.N.self_attn.q_proj` in MLX ↔ `base_model.model.layers.N.self_attn.q_proj` in PEFT). Write a converter
both ways, and a round-trip test.

**`adapter_config.json`**: `{"peft_type": "LORA", "r": 32, "lora_alpha": 64, "lora_dropout": 0.05, "bias": "none",
"target_modules": [...7 names...], "base_model_name_or_path": "<models/gemma-4-E2B-it or E4B>", "init_lora_weights": true,
"use_rslora": false, "use_dora": false, "task_type": null, "inference_mode": true}`. The safest way: let PEFT write it
once (`reproduce.py --smoke` on PyTorch produces a run; copy its config and change only the base path).

**`heads.safetensors`**: keys `token_head.weight [16, hidden]`, `token_head.bias [16]`, `join_head.weight [2, hidden]`,
`join_head.bias [2]` (PyTorch `Linear` layout `[out, in]`; MLX `nn.Linear` uses the same layout).

**`meta.json`**: the same keys `scripts/train.py` writes (`base_model, bidirectional, quant4, labels, lora, train, temperature`),
plus `"backend": "mlx"` inside `train`. `evaluate.py` later adds `temperature`, `thresholds`, `routing`.

## 6. Training loop (copy `scripts/train.py` exactly)

| Item | Value |
|---|---|
| Data | `train_big.jsonl` (100 000 fields), `dev.jsonl` for a progress check; encode with `party_tagger.data.encode_example` |
| Order | `random.seed(seed)`; `order = list(range(N)); random.shuffle(order)` whenever `order` is empty; each micro-batch takes `order[:bs]`, then `order = order[bs:]` (the last one before a reshuffle may be smaller). Same Python `random`, same order as PyTorch |
| Batch | `bs = 8`, `grad_accum = 4` (32 fields per optimizer step), 1 epoch, `total = ceil(N / 32) = 3125` steps |
| Loss per micro-batch | mean cross-entropy over tokens with label ≠ −100 (token head) **+ 0.5 ×** mean cross-entropy over tokens with join ≠ −100 (join head); divided by `grad_accum` before accumulating gradients |
| Optimizer | AdamW, betas (0.9, 0.999), eps 1e-8, **weight decay 0.0** (MLX's AdamW default is not 0), LoRA lr 1e-4, heads lr 1e-3 |
| Schedule | `warmup = max(1, int(0.05 * total))` (= 156); multiplier for optimizer step `s` (0-based): `min(1, (s + 1) / warmup) * max(0, (total - s) / max(1, total - warmup))` |
| Clipping | global gradient norm over LoRA + head parameters ≤ 1.0, after accumulation, before the update |
| Logging | every 25 steps a JSON line `{"step", "loss", "token_loss", "join_loss", "lr", "elapsed_s", "eta_s"}` to `train_log.jsonl`; every 250 steps and at the end also `dev_token_acc` (argmax accuracy on `dev.jsonl` tokens with label ≠ −100) |
| Save | section 5 formats; `temperature = {"token": 1.0, "join": 1.0}` (evaluation calibrates it) |
| Memory | short sequences (≤ 118 tokens): weights dominate. Gradient checkpointing should not be needed for E2B; for E4B on a 32 GB Mac try without it first |
| MLX specifics | call `mx.eval(...)` on the loss, gradients and optimizer state every micro-batch (lazy evaluation otherwise builds a huge graph); consider `mx.compile` only after correctness is proven |

## 7. Integration points

1. **Inference:** `src/party_tagger/mlx_backend.py` with `load_run_mlx(run_dir, model_path)` and
   `raw_logits(texts) -> list[(offsets, token_logits, join_logits)]`. Make `Predictor` pick it when the environment
   variable `TAGGER_BACKEND=mlx` is set (default: torch). Return **CPU float32 torch tensors** with the same shapes as
   today, so `decode`, `evaluate.py`, `calibrate_routing.py` and `export_hf.py` need no change.
2. **Training:** `scripts/train_mlx.py` with the same command-line arguments as `scripts/train.py`
   (`--model --out --train-files --lora-r --bs --grad-accum --epochs --lr --head-lr --join-weight --seed --max-train --max-steps`).
3. **Pipeline:** `reproduce.py --backend {torch,mlx}` (default: `mlx` on macOS when `import mlx` works, else `torch`):
   step `train` calls `train_mlx.py`, and all later steps run with `TAGGER_BACKEND=mlx` in the environment.
4. **Dependencies:** `requirements-mlx.txt` with the exact `mlx` and `mlx-lm` versions that worked.

## 8. Step plan (each step ends with a check and a short report to the user)

| Step | What | Done when | Rough effort |
|---|---|---|---|
| 0 | Setup: Python 3.12 venv, `pip install torch`, `pip install -r requirements.txt`, `pip install mlx mlx-lm`; `python reproduce.py --steps env,data`; ask the user to download **E2B** (`python reproduce.py --model e2b --steps model`) | env step passes; data matches SHA256SUMS | 15 min + download |
| 1 | **Measure the existing PyTorch path** on the Mac: `python reproduce.py --model e2b --smoke` | seconds per training step and memory noted; tells the user whether plain PyTorch could already be good enough | 15–30 min |
| 2 | **Backbone parity:** MLX Gemma 4 text model, bidirectional, padding mask. Compare the last hidden state with PyTorch on 8 fields from `data/generated/handcrafted.jsonl` (PyTorch on MPS or CPU, bf16) | cosine similarity ≥ 0.995 for every real token; also check a padded batch equals unpadded single runs | 2–4 h |
| 3 | **Inference parity on a trained run:** use the run from step 1 (`runs/smoke_e2b`, quality irrelevant) or the published v3 (`hf download msw1410/payment-party-tagger-gemma4-e4b`, needs the user's login). Implement `mlx_backend.py` + `TAGGER_BACKEND=mlx` | on 30 handcrafted fields: token probabilities differ by ≤ 0.01, argmax labels and routing decisions (`send_to` of every unit) identical | 1–2 h |
| 4 | **Trainer:** `scripts/train_mlx.py`; `--max-steps 20 --max-train 256` | the saved run loads in **both** backends with matching outputs (≤ 0.01); loss falls like the PyTorch smoke run in step 1 | 3–5 h |
| 5 | **Full E2B training in MLX** (ask the user first): `python reproduce.py --model e2b --backend mlx` | `check_release.py` passes; `compare.md` written; the user gets the table | training time + ~15 min |
| 6 | Integration: `reproduce.py --backend`, `requirements-mlx.txt`, MLX tests (skipped without mlx), README section | `python -m pytest -q` green on the Mac and still green where mlx is missing | 1 h |
| 7 (stretch) | E4B in MLX | as step 5, plus comparison with the E4B reference within 1 pp | training time |

If time is short, stop after step 3: fast **inference** on the Mac is already useful, and training can happen on
Colab (`COLAB.md`).

## 9. Pitfalls checklist

- [ ] LoRA scale 2.0 (alpha / rank), not mlx-lm's default; rank 32; dropout 0.05.
- [ ] AdamW weight decay 0.0.
- [ ] Bidirectional: no causal mask anywhere (check every attention call, including sliding-window layers); padding masked as keys.
- [ ] KV-shared layers get K/V from the right source layer in a cache-less forward; they have no `k_proj`/`v_proj` adapters.
- [ ] The hidden state used is after the final norm.
- [ ] BOS is added by `encode_text` (do not let a tokenizer wrapper add a second one).
- [ ] Transposes and names in the PEFT converter; round-trip test.
- [ ] `mx.eval` inside the loop; watch memory (`mx.metal.get_peak_memory()` or the current equivalent).
- [ ] The published 4-bit community checkpoints are a different model; use the original bf16 weights.
- [ ] Reported problem: some Gemma 4 E2B checkpoints carry extra tensors for KV-shared layers that a model class has
      no slot for; skip them deliberately and log which ones.
- [ ] Parity first, speed second: no `mx.compile`, fused kernels or quantization until steps 2–4 pass.

## 10. If blocked

- mlx-lm has no usable Gemma 4 text model → port HF's `transformers/models/gemma4/modeling_gemma4.py` (installed with
  `transformers==5.19.0`) to MLX: only the text decoder layers, without cache. Ask the user before starting this (it is the biggest risk).
- Parity cannot be reached → report the layer where hidden states diverge (compare layer by layer) and stop.
- Out of memory with E4B → stay with E2B, or ask about trying 8-bit base weights (4-bit reportedly broke a LoRA-adapted
  Gemma 4 E4B in another project; any quantized variant must pass the release gate).
- No time at all → the existing PyTorch path works on the Mac (`python reproduce.py --model e2b`), only slower; Colab is the other route.

## 11. Final report to the user (in Polish)

What works (inference / training / E2B / E4B), measured speed (seconds per step, fields per second), memory, the
release gate result and the `compare.md` table, what is not done, and the exact commands to repeat it.
