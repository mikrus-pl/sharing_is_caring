# Architektura modelu v3

## Zadanie
**Wejście:** zawartość jednego pola strony z wiadomości SWIFT MT (`50K`, `59`, `50F`, `59F`), do 4 linii po 35 znaków
(plus linia konta). Pole wyciąga z wiadomości zwykły parser, a nie model.

**Wyjście:** dla każdego tokenu rola (16 etykiet) i, na każdym łamaniu linii, decyzja „słowo ciągnie się w następnej
linii”. Z tego kod buduje słowa, frazy, podmioty i decyzję, co trafia do agenta nazw, co do agenta geo, a co jest pomijane.

Model jest **dyskryminacyjny**: nie generuje tekstu, tylko w jednym przebiegu liczy prawdopodobieństwa dla każdego tokenu.

## Schemat

```
pole tekstowe ─► tokenizer Gemmy (BOS + tekst, z pozycjami znaków)
              ─► Gemma 4 E4B, część tekstowa, atencja DWUKIERUNKOWA, nakładka LoRA
              ─► stany ukryte ostatniej warstwy (E4B: 2560 liczb na token) ─► dropout 0.1
                   ├─► głowica etykiet:      Linear 2560 → 16 (float32)
                   └─► głowica łamania linii: Linear 2560 → 2  (float32)
              (dla E2B rozmiar stanów może być inny; głowice dostają go z konfiguracji modelu)
              ─► softmax z temperaturą (skalibrowaną po treningu)
              ─► słowa i frazy ─► reguły deterministyczne + progi z gwarancją
              ─► agent nazw / agent geo / pominięte  (+ podpowiedź pól ISO 20022)
```

## Elementy

| Element | Ustawienie | Gdzie w kodzie |
|---|---|---|
| Model bazowy | `google/gemma-4-E4B-it` (v3); opcjonalnie `google/gemma-4-E2B-it` (`--model e2b`, nietrenowany). Wczytana tylko część tekstowa (wieże obrazu i dźwięku pominięte); rozmiar stanów ukrytych kod odczytuje z modelu | `backbone.load_backbone` |
| Atencja | maska przyczynowa wyłączona: każdy token widzi całe pole; okno lokalnej atencji symetryczne (połowa) | `backbone.set_bidirectional` |
| Tablica osadzeń warstwowych (PLE, 2,8 mld liczb) | na kartach < 24 GB trzymana w pamięci CPU; na A100 i Macu na urządzeniu | `backbone.CpuEmbedding` |
| LoRA | r = 32, alfa = 64, dropout 0.05, na `q,k,v,o,gate,up,down` | `tagger.build_for_training` |
| Głowice | dwie warstwy liniowe w float32 | `tagger.SwiftTagger` |
| Precyzja | wagi bf16, obliczenia w autocast bf16 (CUDA, CPU; MPS jeśli wspiera), głowice float32 | `device.autocast` |
| Urządzenie | CUDA → MPS → CPU, wybierane samo (`TAGGER_DEVICE` wymusza) | `device.DEVICE` |

## Etykiety

| Etykieta | Grupa | Pole ISO 20022 | Znaczenie |
|---|---|---|---|
| `O` | – | – | separator, spacja |
| `NAME_PERSON` | nazwa | Nm | osoba |
| `NAME_ORG` | nazwa | Nm | organizacja z formą prawną; także dział po ATTN |
| `PARTY_INTRO` | nazwa | – | znacznik strony: C/O, ATTN, OBO, FFC, T/A, BENEFICIARY |
| `PARTY_ID` | nazwa | Id / CtctDtls | identyfikator lub kontakt: TEL, VAT, BIC, data urodzenia, REF |
| `STREET` | adres | StrtNm | ulica |
| `BUILDING` | adres | BldgNb | numer budynku, też zakres `142/144` |
| `UNIT` | adres | Room | lokal |
| `POSTCODE` | adres | PstCd | kod pocztowy |
| `TOWN` | adres | TwnNm | miejscowość |
| `REGION` | adres | CtrySubDvsn | stan, województwo |
| `COUNTRY` | adres | Ctry | kraj |
| `PO_BOX` | adres | PstBx | skrytka |
| `ACCOUNT` | szum | – | linia konta |
| `LINE_PREFIX` | szum | – | kody linii `1/` `2/` `3/` w 50F/59F |
| `NOISE` | szum | – | tylko śmieci i wypełniacze (`%@#$`, `NOTPROVIDED`) |

Zasada: wszystko o stronie, co nie jest jej adresem pocztowym, to „kto” (nazwa); adres pocztowy to „gdzie”.

## Trening

| Co | Ustawienie |
|---|---|
| Etykieta tokenu | najczęstsza etykieta jego znaków (bez spacji); tokeny z samych spacji pomijane |
| Strata | entropia krzyżowa etykiet + 0,5 × entropia krzyżowa łamania linii |
| Optymalizator | AdamW, LoRA lr 1e-4, głowice lr 1e-3, bez weight decay, przycinanie gradientu 1.0 |
| Harmonogram | rozgrzewka 5% kroków, potem liniowo do zera |
| Paczka | 8 pól × 4 akumulacje = 32 pola na krok (profil `fast`: 32 × 1), 3125 kroków = 1 epoka 100 tys. pól |
| Pamięć | gradient checkpointing (profil `fast`: wyłączony) |
| Losowość | seed 0 (kolejność danych, inicjalizacja głowic) |
| Nauczyciel | brak (v3 trenowany bez destylacji) |

## Po treningu (krok `evaluate` i `calibrate`)
1. **Temperatura:** jedna liczba dla każdej głowicy, dobrana na zbiorze kalibracyjnym tak, żeby prawdopodobieństwa
   odpowiadały rzeczywistej trafności.
2. **Próg automatu z gwarancją:** dla pewności całego pola. Przedział Clopper–Pearsona 95% wyliczony na 70% zbioru
   kalibracyjnego (FIT) i sprawdzony na pozostałych 30% (CERT). Pole poniżej progu idzie do przeglądu.
3. **Progi routingu** (polityka „gwarancja 99.5%”): progi konformalne osobno dla nazwy i adresu. Słowo niepewne trafia do
   obu agentów. Szum odpada tylko przy P(szum) > 0.95 **i** gdy słowo w ogóle może być szumem.
4. **Reguły deterministyczne:**
   - IBAN (suma kontrolna mod 97), linia konta, kody linii `1/`–`8/`;
   - znaczniki C/O, ATTN, OBO, FFC, T/A; strona po C/O idzie do obu agentów;
   - bezpiecznik: słowo z literą lub cyfrą nigdy nie jest wyrzucane.

## Kontrakt wyjścia (`out["routing"]`)

```
name_agent: {text, party_type, entities: [{value, type, role, marker?}], identifiers, parts}
geo_agent:  {text, iso20022_hint: {StrtNm, BldgNb, PstCd, TwnNm, Ctry, ...}, care_of, parts}
ignored, ambiguous, review, review_reasons
```

Przykłady pełnego wyjścia: `expected/` oraz opis modelu na Hugging Face.

## Pliki przebiegu (`runs/<nazwa>/`)
`adapter/` (LoRA), `heads.pt` (głowice), `meta.json` (etykiety, temperatury, progi, ustawienia treningu, urządzenie),
`metrics.json`, `routing_metrics.json`, `report.md`, `routing_report.md`, `handcrafted_review.md`, `train_log.jsonl`,
`reproduce.log`, `compare.md`.
