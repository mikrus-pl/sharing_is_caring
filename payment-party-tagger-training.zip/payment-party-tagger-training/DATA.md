# Dane

## Zasady
- **W 100% syntetyczne.** Brak prawdziwych wiadomości SWIFT i danych osobowych. Imiona, nazwiska, firmy i adresy są
  fikcyjne (Faker), uzupełnione ręcznymi listami (formy prawne, skróty ulic, pośrednicy).
- **Etykiety liczy kod**, więc są dokładne. Generator najpierw składa pole z części o znanej roli, a dopiero potem
  psuje je tak, jak robią to prawdziwe systemy i ludzie.
- **Odtwarzalne:** stałe ziarna losowania, `PYTHONHASHSEED=0` (skrypty same się z nim uruchamiają), przypięta wersja
  `faker==40.43.0`, zapis z linuksowymi końcami linii. 2026-10-26 na Windows generator odtworzył wszystkie 12 plików bit
  w bit. Na innych systemach `reproduce.py --regenerate-data` sprawdza to sumami kontrolnymi, a przy różnicy używa plików z paczki.

## Pliki (`data/generated/`)

| Plik | Pól | Skąd | Do czego |
|---|---|---|---|
| `train_big.jsonl` | 100 000 | 40 000 zwykłych (seed 31, 14 krajów) + 60 000 trudnych i uszkodzonych (seed 32, 32 kraje) | **trening v3** |
| `calib_big.jsonl` | 5 000 | 2 000 zwykłych (seed 33) + 3 000 trudnych (seed 34) | kalibracja temperatury i progów |
| `dev.jsonl` | 300 | seed 12 | podgląd w trakcie treningu |
| `test.jsonl` | 1 000 | seed 14, kraje treningowe | test |
| `test_heldout.jsonl` | 1 000 | seed 15, **Portugalia i Rumunia** (nigdy w treningu) | test uogólniania |
| `test_hard.jsonl` | 1 000 | seed 24, trudne + uszkodzone | test |
| `test_hard_heldout.jsonl` | 1 000 | seed 25, trudne, PT i RO | test |
| `handcrafted.jsonl` | 30 | z `data/handcrafted.txt` | ręczne trudne przypadki (C/O, ATTN, FFC, śmieci, zakresy numerów) |
| `train.jsonl`, `train_hard.jsonl`, `calib.jsonl`, `calib_hard.jsonl` | 8 000 / 8 000 / 1 000 / 1 000 | seed 11, 21, 13, 23 | starsze zestawy (v0–v2); `calib.jsonl` używa `--smoke` |

Budują je `scripts/make_data.py`, `scripts/make_hard_data.py` i `scripts/make_big_data.py`, w tej kolejności (ostatni
sprawdza, czy żadne pole treningowe nie jest identyczne z testowym).

## Format rekordu (JSONL, jedno pole na linię)

```json
{"text": "ACME LTD\nC/O ALPHA CORPORATE SERVICES LTD\n2 ARCH MAKARIOS III AVE\n1065 NICOSIA",
 "char_labels": ["NAME_ORG", "NAME_ORG", "...", "O", "PARTY_INTRO", "..."],
 "char_comp": [0, 0, "...", -1, 1, "..."],
 "joins": [[8, false], [41, false], [65, false]],
 "meta": {"locale": "en_GB", "style": "natural", "tag": "50K", "party": "org", "second_party": "care_of"}}
```

- `char_labels`: etykieta każdego znaku; `char_comp`: numer części (−1 = separator).
- `joins`: każde łamanie linii i to, czy rozcina słowo (`true` = słowo ciągnie się w następnej linii).

## Jak powstaje pole (`src/party_tagger/swiftgen.py`, `corrupt.py`)
1. **Strona:** osoba albo firma (Faker dla 34 lokalizacji, firmy typu „marka + branża + forma prawna”).
2. **Drugi podmiot** w 26% pól: C/O, ATTN, OBO, FFC, T/A z nazwą pośrednika (firmy obsługujące spółki, hotele, kancelarie).
3. **Adres** według zwyczajów kraju: kolejność numeru i ulicy, kod przed albo po mieście, regiony, skrytki, zakresy
   numerów (`142/144`), budynek i lokal (`142/5`), numeracja czeska (`1079/3A`).
4. **Dodatki:** identyfikatory (TEL, VAT, BIC, REF) jako `PARTY_ID`; szum tylko jako śmieci i wypełniacze (1% znaków).
5. **Zapis:** 5 stylów: naturalne linie, sklejone z twardym cięciem co 35 znaków (słowa cięte w środku), sklejone z
   łamaniem po słowach, format F z kodami `1/ 2/ 3/` (oraz `4/–8/` w 50F), linia nazwy + sklejony adres.
6. **Uszkodzenia** w danych trudnych (13 rodzajów): brak spacji, dziwne separatory, literówki, wielkość liter,
   znaki diakrytyczne, śmieci (także w środku nazw), duplikaty, losowe łamanie linii, ucięcie, sklejone linie,
   uszkodzony prefiks, inny zapis konta.

## Konwencje etykietowania
- „Kto” (nazwa, identyfikatory, kontakt) kontra „gdzie” (adres pocztowy); szum bardzo rzadki.
- `ATTN JOHN SMITH`, `ATTN ACCOUNTS DEPT` → strona nazwy (uproszczenie względem ISO: CtctDtls / Dept).
- `C/O` + strona → znacznik `PARTY_INTRO` + nazwa; routing wysyła do obu agentów.
- `142/5` = budynek + lokal; `142/144` (rosnące, różnica ≤ 6) = jeden budynek; CZ/SK `1079/3A` = budynek.
- 50F linie `4/`–`7/` (data i miejsce urodzenia, identyfikatory) → `PARTY_ID`.
