"""Where the model runs: an NVIDIA GPU (cuda), an Apple GPU (mps) or the CPU. Chosen once and used everywhere.

Override with the environment variable TAGGER_DEVICE=cuda|mps|cpu.
"""

from __future__ import annotations

import contextlib
import os

import torch


def default_device() -> str:
    forced = os.environ.get("TAGGER_DEVICE")
    if forced:
        return forced
    if torch.cuda.is_available():
        return "cuda"
    if getattr(torch.backends, "mps", None) is not None and torch.backends.mps.is_available():
        return "mps"
    return "cpu"


DEVICE = default_device()


def device_name(device: str | None = None) -> str:
    """Human-readable name of the hardware, recorded in run metadata and reports."""
    device = device or DEVICE
    if device == "cuda":
        return torch.cuda.get_device_name(0)
    if device == "mps":
        return "Apple GPU (MPS)"
    import platform

    return f"CPU ({platform.processor() or platform.machine()})"


def autocast(device: str | None = None):
    """bf16 mixed precision where the device supports it; the heads always run in float32 (SwiftTagger.forward)."""
    device = device or DEVICE
    if device in ("cuda", "cpu"):
        return torch.autocast(device, dtype=torch.bfloat16)
    try:
        return torch.autocast("mps", dtype=torch.bfloat16)
    except (RuntimeError, ValueError):  # older torch: no autocast on MPS; weights are bf16 already
        return contextlib.nullcontext()


def synchronize(device: str | None = None) -> None:
    device = device or DEVICE
    if device == "cuda":
        torch.cuda.synchronize()
    elif device == "mps":
        torch.mps.synchronize()


def peak_memory_gib(device: str | None = None) -> float | None:
    device = device or DEVICE
    if device == "cuda":
        return round(torch.cuda.max_memory_allocated() / 2**30, 2)
    if device == "mps":
        return round(torch.mps.driver_allocated_memory() / 2**30, 2)
    return None
