"""Evaluation of field segmentation: character-level F1, whole-field correctness, joins, coverage at a target error."""

from __future__ import annotations

import math
import zlib
from collections import defaultdict

from party_tagger.labels import COARSE, LABELS
from party_tagger.swiftgen import Example


def _prf(tp: int, fp: int, fn: int) -> dict:
    p = tp / (tp + fp) if tp + fp else 0.0
    r = tp / (tp + fn) if tp + fn else 0.0
    return {"p": round(p, 4), "r": round(r, 4), "f1": round(2 * p * r / (p + r), 4) if p + r else 0.0, "support": tp + fn}


def counted(ch: str, coarse: bool) -> bool:
    """Characters that are scored: name/address/noise is judged on letters and digits only
    (a '/' or ',' separator does not change what is name and what is address); fine labels on every non-space."""
    return ch.isalnum() if coarse else not ch.isspace()


def field_correct(ex: Example, pred_chars: list[str | None], coarse: bool) -> bool:
    for i, ch in enumerate(ex.text):
        if not counted(ch, coarse):
            continue
        g, p = ex.char_labels[i], pred_chars[i] or "O"
        if coarse:
            g, p = COARSE[g], COARSE[p]
        if g != p:
            return False
    return True


def evaluate(examples: list[Example], outputs: list[dict]) -> dict:
    counts = {"fine": defaultdict(lambda: [0, 0, 0]), "coarse": defaultdict(lambda: [0, 0, 0])}
    chars = chars_ok = 0
    fields_fine = fields_coarse = 0
    joins = joins_ok = 0
    group_ok = defaultdict(int)
    for ex, out in zip(examples, outputs):
        pred = out["char_labels"]
        for i, ch in enumerate(ex.text):
            if ch.isspace():
                continue
            g, p = ex.char_labels[i], pred[i] or "O"
            chars += 1
            chars_ok += g == p
            for level, (gl, pl) in (("fine", (g, p)), ("coarse", (COARSE[g], COARSE[p]))):
                if not counted(ch, level == "coarse"):
                    continue
                if gl == pl:
                    counts[level][gl][0] += 1
                else:
                    counts[level][pl][1] += 1
                    counts[level][gl][2] += 1
        fields_fine += field_correct(ex, pred, coarse=False)
        ok_coarse = field_correct(ex, pred, coarse=True)
        fields_coarse += ok_coarse
        for group in ("NAME", "ADDRESS", "NOISE"):
            gold = {i for i, c in enumerate(ex.text) if c.isalnum() and COARSE[ex.char_labels[i]] == group}
            got = {i for i, c in enumerate(ex.text) if c.isalnum() and COARSE[pred[i] or "O"] == group}
            group_ok[group] += gold == got
        pred_joins = {j["pos"]: j["word_continues"] for j in out["joins"]}
        for pos, cont in ex.joins:
            joins += 1
            joins_ok += pred_joins.get(pos, False) == cont
    n = len(examples)
    per_label = {level: {lbl: _prf(*counts[level][lbl]) for lbl in (LABELS if level == "fine" else ["NAME", "ADDRESS", "NOISE", "O"])
                         if sum(counts[level][lbl])} for level in counts}
    macro = {level: round(sum(v["f1"] for k, v in per_label[level].items() if k != "O") /
                          max(1, len([k for k in per_label[level] if k != "O"])), 4) for level in per_label}
    return {
        "fields": n,
        "char_accuracy_fine": round(chars_ok / max(chars, 1), 4),
        "macro_f1": macro,
        "field_exact_fine": round(fields_fine / n, 4),
        "field_exact_coarse": round(fields_coarse / n, 4),
        "name_exact": round(group_ok["NAME"] / n, 4),
        "address_exact": round(group_ok["ADDRESS"] / n, 4),
        "noise_exact": round(group_ok["NOISE"] / n, 4),
        "join_accuracy": round(joins_ok / max(joins, 1), 4),
        "per_label": per_label,
    }


def _binom_cdf(k: int, n: int, p: float) -> float:
    if p <= 0:
        return 1.0
    if p >= 1:
        return 0.0 if k < n else 1.0
    lp, lq = math.log(p), math.log1p(-p)
    return min(1.0, sum(math.exp(math.lgamma(n + 1) - math.lgamma(i + 1) - math.lgamma(n - i + 1) + i * lp + (n - i) * lq)
                        for i in range(k + 1)))


def clopper_pearson_upper(errors: int, n: int, confidence: float = 0.95) -> float:
    """One-sided upper confidence bound on an error rate after `errors` mistakes in `n` decisions."""
    if n == 0 or errors >= n:
        return 1.0
    lo, hi = errors / n, 1.0
    for _ in range(60):
        mid = (lo + hi) / 2
        if _binom_cdf(errors, n, mid) > 1 - confidence:
            lo = mid
        else:
            hi = mid
    return hi


def certified_threshold(confidences: list[float], correct: list[bool], target: float,
                        confidence: float = 0.95, min_accepted: int = 50) -> float | None:
    """Lowest confidence whose accepted decisions have a one-sided Clopper-Pearson upper error bound <= target.

    Scans from the most confident decision down; equal confidences are accepted or rejected together.
    None = no threshold can be certified (every decision goes to a person).
    """
    pairs = sorted(zip(confidences, correct), reverse=True)
    best = None
    errors = 0
    for k, (conf, ok) in enumerate(pairs, 1):
        errors += not ok
        if k < len(pairs) and pairs[k][0] == conf:
            continue
        if k >= min_accepted and clopper_pearson_upper(errors, k, confidence) <= target:
            best = conf
    return best


def split_fit_cert(keys: list[str], fit_share: float = 0.7) -> list[bool]:
    """True = FIT, False = CERT; decided by a stable hash of the group key, so a group never straddles both."""
    return [zlib.crc32(k.encode("utf-8")) % 1000 < fit_share * 1000 for k in keys]


def threshold_for_error(confidences: list[float], correct: list[bool], target: float) -> float:
    """Lowest confidence threshold whose accepted set has error <= target (decided on calibration data)."""
    pairs = sorted(zip(confidences, correct), reverse=True)
    best = 1.01
    errors = 0
    for k, (conf, ok) in enumerate(pairs, 1):
        errors += not ok
        if errors / k <= target and (k == len(pairs) or pairs[k][0] < conf):
            best = conf
    return best


def coverage(confidences: list[float], correct: list[bool], threshold: float) -> dict:
    accepted = [ok for c, ok in zip(confidences, correct) if c >= threshold]
    return {
        "threshold": round(threshold, 4),
        "coverage": round(len(accepted) / max(len(correct), 1), 4),
        "error_among_accepted": round(1 - sum(accepted) / len(accepted), 4) if accepted else None,
    }
