"""Gemma backbone + token heads: a label for every token and a 'word continues' decision for line breaks."""

from __future__ import annotations

import json
from pathlib import Path

import torch
from peft import LoraConfig, PeftModel, get_peft_model
from torch import nn

from party_tagger.backbone import load_backbone
from party_tagger.device import DEVICE
from party_tagger.labels import LABELS

LORA_TARGETS = ["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"]


class SwiftTagger(nn.Module):
    def __init__(self, backbone: nn.Module, hidden_size: int, num_labels: int = len(LABELS), dropout: float = 0.1):
        super().__init__()
        self.backbone = backbone
        self.dropout = nn.Dropout(dropout)
        self.token_head = nn.Linear(hidden_size, num_labels)
        self.join_head = nn.Linear(hidden_size, 2)

    def forward(self, input_ids: torch.Tensor, attention_mask: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        hidden = self.backbone(input_ids=input_ids, attention_mask=attention_mask, use_cache=False).last_hidden_state
        hidden = self.dropout(hidden.float())
        return self.token_head(hidden), self.join_head(hidden)

    def heads_state(self) -> dict:
        return {"token_head": self.token_head.state_dict(), "join_head": self.join_head.state_dict()}


def build_for_training(model_path: str, *, bidirectional: bool, lora_r: int, grad_ckpt: bool, quant4: bool = False) -> SwiftTagger:
    """quant4: the frozen backbone is stored in 4-bit NF4 and the LoRA adapters train in higher precision (QLoRA)."""
    backbone = load_backbone(model_path, bidirectional=bidirectional, quant4=quant4)
    hidden = backbone.config.hidden_size
    if grad_ckpt:
        backbone.gradient_checkpointing_enable(gradient_checkpointing_kwargs={"use_reentrant": False})
    lora = LoraConfig(r=lora_r, lora_alpha=2 * lora_r, lora_dropout=0.05, target_modules=LORA_TARGETS)
    backbone = get_peft_model(backbone, lora)
    model = SwiftTagger(backbone, hidden)
    model.token_head.to(DEVICE)
    model.join_head.to(DEVICE)
    return model


def save_run(model: SwiftTagger, out_dir: Path, meta: dict) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    model.backbone.save_pretrained(out_dir / "adapter")
    torch.save(model.heads_state(), out_dir / "heads.pt")
    (out_dir / "meta.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")


def load_run(run_dir: str | Path, model_path: str | None = None) -> tuple[SwiftTagger, dict]:
    run_dir = Path(run_dir)
    meta = json.loads((run_dir / "meta.json").read_text(encoding="utf-8"))
    quant4 = meta.get("quant4", False)
    backbone = load_backbone(model_path or meta["base_model"], bidirectional=meta["bidirectional"], quant4=quant4)
    hidden = backbone.config.hidden_size
    backbone = PeftModel.from_pretrained(backbone, run_dir / "adapter")
    if not quant4:  # merging into 4-bit weights would re-round them; keep the adapters separate there
        backbone = backbone.merge_and_unload()
    model = SwiftTagger(backbone, hidden, num_labels=len(meta["labels"]))
    if (run_dir / "heads.safetensors").exists():  # published runs: no pickle files
        from safetensors.torch import load_file

        flat = load_file(run_dir / "heads.safetensors")
        heads = {h: {k.split(".", 1)[1]: v for k, v in flat.items() if k.startswith(h + ".")} for h in ("token_head", "join_head")}
    else:
        heads = torch.load(run_dir / "heads.pt", map_location="cpu")
    model.token_head.load_state_dict(heads["token_head"])
    model.join_head.load_state_dict(heads["join_head"])
    model.token_head.to(DEVICE)
    model.join_head.to(DEVICE)
    model.eval()
    return model, meta
