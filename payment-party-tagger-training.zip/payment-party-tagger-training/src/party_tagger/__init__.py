"""Token tagger that splits a payment party field into name (who) and postal address (where)."""
