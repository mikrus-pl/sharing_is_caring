"""Inference: one forward pass -> token labels -> spans -> name / address / noise / ISO 20022 fields."""

from __future__ import annotations

import re
import time
from pathlib import Path

import torch

from party_tagger.backbone import load_tokenizer
from party_tagger.data import encode_text
from party_tagger.device import DEVICE, autocast, synchronize
from party_tagger.labels import COARSE, ISO_ELEMENT
from party_tagger.routing import build_units, route_units
from party_tagger.swiftgen import COUNTRIES, EXTRA_COUNTRIES
from party_tagger.tagger import load_run

TRIM = ",;/"
COUNTRY_CODES = {name: iso for iso, names, _ in list(COUNTRIES.values()) + list(EXTRA_COUNTRIES.values()) for name in names}
COUNTRY_CODES.update({
    "AUSTRIA": "AT", "OESTERREICH": "AT", "BELGIUM": "BE", "NORWAY": "NO", "NORGE": "NO", "FINLAND": "FI",
    "HONG KONG": "HK", "CHINA": "CN", "JAPAN": "JP", "SINGAPORE": "SG", "CANADA": "CA", "AUSTRALIA": "AU",
    "LUXEMBOURG": "LU", "HUNGARY": "HU", "SLOVAKIA": "SK", "LITHUANIA": "LT", "LATVIA": "LV", "ESTONIA": "EE",
    "UKRAINE": "UA", "GREECE": "GR", "INDIA": "IN", "UNITED ARAB EMIRATES": "AE", "UAE": "AE", "ISRAEL": "IL",
    "CYPRUS": "CY", "RUSSIA": "RU", "RUSSIAN FEDERATION": "RU", "MALTA": "MT", "BULGARIA": "BG", "SERBIA": "RS",
    "BELARUS": "BY", "KAZAKHSTAN": "KZ", "GEORGIA": "GE", "ARMENIA": "AM", "AZERBAIJAN": "AZ", "MOLDOVA": "MD",
    "IRAN": "IR", "IRAQ": "IQ", "SYRIA": "SY", "SYRIAN ARAB REPUBLIC": "SY", "LEBANON": "LB", "SAUDI ARABIA": "SA",
    "QATAR": "QA", "KUWAIT": "KW", "EGYPT": "EG", "SOUTH AFRICA": "ZA", "NIGERIA": "NG", "KENYA": "KE", "MOROCCO": "MA",
    "BRAZIL": "BR", "ARGENTINA": "AR", "CHILE": "CL", "COLOMBIA": "CO", "PANAMA": "PA", "VENEZUELA": "VE", "CUBA": "CU",
    "NORTH KOREA": "KP", "DPRK": "KP", "SOUTH KOREA": "KR", "REPUBLIC OF KOREA": "KR", "TAIWAN": "TW", "THAILAND": "TH",
    "VIETNAM": "VN", "VIET NAM": "VN", "MALAYSIA": "MY", "PHILIPPINES": "PH", "PAKISTAN": "PK", "BANGLADESH": "BD",
    "SRI LANKA": "LK", "ICELAND": "IS", "LIECHTENSTEIN": "LI", "MONACO": "MC", "ANDORRA": "AD", "SAN MARINO": "SM",
    "GIBRALTAR": "GI", "JERSEY": "JE", "GUERNSEY": "GG", "ISLE OF MAN": "IM", "BERMUDA": "BM", "CAYMAN ISLANDS": "KY",
    "BRITISH VIRGIN ISLANDS": "VG", "SEYCHELLES": "SC", "MAURITIUS": "MU", "AFGHANISTAN": "AF", "MYANMAR": "MM",
    "LIBYA": "LY", "SUDAN": "SD", "SOUTH SUDAN": "SS", "YEMEN": "YE", "UZBEKISTAN": "UZ", "TURKMENISTAN": "TM",
    "KYRGYZSTAN": "KG", "TAJIKISTAN": "TJ", "MONTENEGRO": "ME", "BOSNIA AND HERZEGOVINA": "BA", "NORTH MACEDONIA": "MK",
    "ALBANIA": "AL",
    # left out on purpose: KOREA (north or south?) and KOSOVO (no ISO 3166 code); they stay as written
})


def _value(text: str, start: int, end: int, continues: dict[int, bool]) -> str:
    """Span text as one line: line breaks inside a split word disappear, other breaks become spaces."""
    out = []
    for i in range(start, end):
        ch = text[i]
        if ch == "\n":
            out.append("" if continues.get(i, False) else " ")
        else:
            out.append(ch)
    return re.sub(r" {2,}", " ", "".join(out)).strip()


def decode(text: str, offsets, token_probs: torch.Tensor, join_probs: torch.Tensor, labels: list[str],
           routing_thresholds: dict | None = None) -> dict:
    tokens, joins = [], []
    char_label: list[str | None] = [None] * len(text)
    char_token: list[int | None] = [None] * len(text)
    token_p: dict[int, float] = {}
    continues: dict[int, bool] = {}
    for k, (s, e) in enumerate(offsets):
        if k == 0 or s == e:
            continue
        piece = text[s:e]
        probs = token_probs[k]
        top = torch.topk(probs, 3)
        label = labels[int(top.indices[0])]
        p = float(top.values[0])
        whitespace = piece.isspace()
        tokens.append({
            "i": k, "text": piece, "start": s, "end": e,
            "label": None if whitespace else label, "p": None if whitespace else round(p, 4),
            "top": [[labels[int(i)], round(float(v), 4)] for i, v in zip(top.indices, top.values)],
        })
        if not whitespace:
            token_p[k] = p
            for i in range(s, e):
                if not text[i].isspace():
                    char_label[i], char_token[i] = label, k
        if "\n" in piece:
            pos = s + piece.index("\n")
            pc = float(join_probs[k][1])
            continues[pos] = pc > 0.5
            joins.append({"pos": pos, "word_continues": pc > 0.5, "p": round(max(pc, 1 - pc), 4)})

    spans: list[dict] = []
    cur = None
    for i, ch in enumerate(text):
        if ch.isspace():
            continue
        label = char_label[i]
        if label is None or label == "O":
            cur = None
            continue
        gap = text[cur["end"]:i] if cur is not None else ""
        if cur is not None and cur["label"] == label and (gap == "" or gap.isspace()):
            cur["end"] = i + 1
            cur["_tokens"].add(char_token[i])
        else:
            cur = {"label": label, "start": i, "end": i + 1, "_tokens": {char_token[i]}}
            spans.append(cur)
    for sp in spans:
        if sp["label"] in ("ACCOUNT", "LINE_PREFIX"):
            continue
        # separator punctuation glued to a token ("ROMA," or "/LINDENSTR.") is not part of the value
        while sp["start"] < sp["end"] and (text[sp["start"]] in TRIM or text[sp["start"]].isspace()):
            char_label[sp["start"]] = "O" if not text[sp["start"]].isspace() else None
            sp["start"] += 1
        while sp["end"] > sp["start"] and (text[sp["end"] - 1] in TRIM or text[sp["end"] - 1].isspace()):
            char_label[sp["end"] - 1] = "O" if not text[sp["end"] - 1].isspace() else None
            sp["end"] -= 1
    spans = [sp for sp in spans if sp["end"] > sp["start"]]
    for sp in spans:
        sp["coarse"] = COARSE[sp["label"]]
        sp["text"] = text[sp["start"]:sp["end"]]
        sp["value"] = _value(text, sp["start"], sp["end"], continues)
        sp["confidence"] = round(min(token_p[t] for t in sp.pop("_tokens")), 4)

    iso: dict[str, str] = {}
    for sp in spans:
        key = ISO_ELEMENT.get(sp["label"])
        if key:
            iso[key] = f"{iso[key]} {sp['value']}" if key in iso else sp["value"]
    if "Ctry" in iso:
        raw = iso["Ctry"]
        code = COUNTRY_CODES.get(raw, raw if re.fullmatch(r"[A-Z]{2}", raw) else None)
        iso["Ctry"] = code or raw
        if code and code != raw:
            iso["Ctry_written"] = raw
    labels_found = {sp["label"] for sp in spans}
    party = ("mixed" if {"NAME_PERSON", "NAME_ORG"} <= labels_found else
             "person" if "NAME_PERSON" in labels_found else "organization" if "NAME_ORG" in labels_found else "unknown")
    result = {
        "name": " ".join(sp["value"] for sp in spans if sp["label"] in ("NAME_PERSON", "NAME_ORG")),
        "party_details": [sp["value"] for sp in spans if sp["label"] in ("PARTY_INTRO", "PARTY_ID")],
        "address": " ".join(sp["value"] for sp in spans if sp["coarse"] == "ADDRESS"),
        "noise": [sp["value"] for sp in spans if sp["coarse"] == "NOISE"],
        "party_type": party,
        "iso20022": iso,
        "hybrid_address_ready": "TwnNm" in iso and "Ctry" in iso,
    }
    confidence = min(token_p.values()) if token_p else 0.0
    units = build_units(text, offsets, token_probs, labels, continues)
    routing = route_units(units, labels, routing_thresholds, text)
    hint = routing["geo_agent"]["iso20022_hint"]
    if "Ctry" in hint:
        written = hint["Ctry"]
        code = COUNTRY_CODES.get(written, written if re.fullmatch(r"[A-Z]{2}", written) else None)
        if code and code != written:
            hint["Ctry"], hint["Ctry_written"] = code, written
    return {
        "input": text,
        "routing": routing,
        "units": units,
        "result": result,
        "spans": spans,
        "joins": joins,
        "confidence": round(confidence, 4),
        "char_labels": char_label,
        "tokens": tokens,
    }


class Predictor:
    def __init__(self, run_dir: str | Path, model_path: str | None = None):
        self.model, self.meta = load_run(run_dir, model_path)
        self.tokenizer = load_tokenizer(model_path or self.meta["base_model"])
        self.labels = self.meta["labels"]

    @torch.no_grad()
    def raw(self, texts: list[str], temperature: dict | None = None):
        """Token and join probabilities for a batch of texts."""
        temperature = temperature or self.meta["temperature"]
        enc = [encode_text(t, self.tokenizer) for t in texts]
        width = max(len(ids) for ids, _ in enc)
        pad = self.tokenizer.pad_token_id
        ids = torch.tensor([i + [pad] * (width - len(i)) for i, _ in enc], device=DEVICE)
        mask = torch.tensor([[1] * len(i) + [0] * (width - len(i)) for i, _ in enc], device=DEVICE)
        with autocast():
            token_logits, join_logits = self.model(ids, mask)
        out = []
        for b, (i, offsets) in enumerate(enc):
            n = len(i)
            out.append((offsets, token_logits[b, :n].float().cpu(), join_logits[b, :n].float().cpu()))
        return out

    def predict_many(self, texts: list[str], batch_size: int = 32) -> list[dict]:
        t_tok, t_join = self.meta["temperature"]["token"], self.meta["temperature"]["join"]
        thresholds = (self.meta.get("routing") or {}).get("thresholds")
        gate = self.meta.get("thresholds") or {}
        automat = gate.get("field_error_1pct")
        uncertified = "field_error_1pct" in gate and automat is None
        results = []
        for i in range(0, len(texts), batch_size):
            chunk = texts[i:i + batch_size]
            for text, (offsets, tl, jl) in zip(chunk, self.raw(chunk)):
                out = decode(text, offsets, (tl / t_tok).softmax(-1), (jl / t_join).softmax(-1), self.labels, thresholds)
                reasons = []
                if out["routing"]["review"]:
                    reasons.append("unsure_noise_and_owner")
                if automat is not None and out["confidence"] < automat:
                    reasons.append("field_confidence_below_automation_threshold")
                if uncertified:
                    reasons.append("no_certified_automation_threshold")
                out["routing"]["review"] = bool(reasons)
                out["routing"]["review_reasons"] = reasons
                results.append(out)
        return results

    def predict(self, text: str) -> dict:
        synchronize()
        t = time.perf_counter()
        out = self.predict_many([text])[0]
        synchronize()
        out["latency_ms"] = round((time.perf_counter() - t) * 1000, 1)
        return out
