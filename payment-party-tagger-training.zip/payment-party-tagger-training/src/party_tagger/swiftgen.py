"""Synthetic generator of SWIFT MT party fields (50K/59/50F/59F) with character-level labels.

Every example is built from labelled components, so the label of each character is known exactly
(labels computed by code, as in basal). Rendering mimics how party data gets flattened into free text:
natural lines, glued components hard-wrapped every 35 characters (also mid-word), word-wrapped glue,
the numbered 50F/59F layout, optional account line, noise, missing parts and truncation to 4 lines.
"""

from __future__ import annotations

import json
import random
import re
import unicodedata
from dataclasses import asdict, dataclass, field

from faker import Faker

from party_tagger.labels import SHORT

LINE_WIDTH = 35
MAX_LINES = 4

# locale -> (ISO2, country names as written in payments, real towns)
COUNTRIES = {
    "en_US": ("US", ["UNITED STATES", "USA", "US", "UNITED STATES OF AMERICA"],
              ["NEW YORK", "CHICAGO", "HOUSTON", "LOS ANGELES", "MIAMI", "BOSTON", "SEATTLE", "DALLAS", "ATLANTA", "SAN FRANCISCO", "DENVER", "CHARLOTTE"]),
    "en_GB": ("GB", ["UNITED KINGDOM", "UK", "GB", "GREAT BRITAIN", "ENGLAND"],
              ["LONDON", "MANCHESTER", "BIRMINGHAM", "LEEDS", "GLASGOW", "BRISTOL", "LIVERPOOL", "EDINBURGH", "CARDIFF", "READING"]),
    "de_DE": ("DE", ["GERMANY", "DEUTSCHLAND", "DE", "FED. REP. OF GERMANY"],
              ["BERLIN", "HAMBURG", "MUENCHEN", "FRANKFURT AM MAIN", "KOELN", "STUTTGART", "DUESSELDORF", "LEIPZIG", "DORTMUND", "BREMEN"]),
    "fr_FR": ("FR", ["FRANCE", "FR"],
              ["PARIS", "LYON", "MARSEILLE", "TOULOUSE", "NICE", "NANTES", "STRASBOURG", "BORDEAUX", "LILLE", "RENNES"]),
    "pl_PL": ("PL", ["POLAND", "POLSKA", "PL"],
              ["WARSZAWA", "KRAKOW", "WROCLAW", "POZNAN", "GDANSK", "LODZ", "KATOWICE", "SZCZECIN", "LUBLIN", "BYDGOSZCZ"]),
    "it_IT": ("IT", ["ITALY", "ITALIA", "IT"],
              ["ROMA", "MILANO", "NAPOLI", "TORINO", "BOLOGNA", "FIRENZE", "GENOVA", "VERONA", "PADOVA", "BARI"]),
    "es_ES": ("ES", ["SPAIN", "ESPANA", "ES"],
              ["MADRID", "BARCELONA", "VALENCIA", "SEVILLA", "ZARAGOZA", "MALAGA", "BILBAO", "MURCIA", "ALICANTE", "VALLADOLID"]),
    "nl_NL": ("NL", ["NETHERLANDS", "THE NETHERLANDS", "NEDERLAND", "HOLLAND", "NL"],
              ["AMSTERDAM", "ROTTERDAM", "DEN HAAG", "UTRECHT", "EINDHOVEN", "GRONINGEN", "TILBURG", "ALMERE", "BREDA", "NIJMEGEN"]),
    "de_CH": ("CH", ["SWITZERLAND", "SCHWEIZ", "SUISSE", "CH"],
              ["ZURICH", "GENEVE", "BASEL", "BERN", "LAUSANNE", "LUZERN", "ZUG", "LUGANO", "WINTERTHUR", "ST. GALLEN"]),
    "sv_SE": ("SE", ["SWEDEN", "SVERIGE", "SE"],
              ["STOCKHOLM", "GOTEBORG", "MALMO", "UPPSALA", "VASTERAS", "OREBRO", "LINKOPING", "HELSINGBORG", "JONKOPING", "NORRKOPING"]),
    "cs_CZ": ("CZ", ["CZECH REPUBLIC", "CZECHIA", "CESKA REPUBLIKA", "CZ"],
              ["PRAHA", "BRNO", "OSTRAVA", "PLZEN", "LIBEREC", "OLOMOUC", "PARDUBICE", "ZLIN", "KLADNO", "JIHLAVA"]),
    "da_DK": ("DK", ["DENMARK", "DANMARK", "DK"],
              ["KOBENHAVN", "AARHUS", "ODENSE", "AALBORG", "ESBJERG", "RANDERS", "KOLDING", "HORSENS", "VEJLE", "ROSKILDE"]),
    "en_IE": ("IE", ["IRELAND", "IE", "REPUBLIC OF IRELAND"],
              ["DUBLIN", "CORK", "LIMERICK", "GALWAY", "WATERFORD", "DROGHEDA", "KILKENNY", "SLIGO", "ATHLONE", "WEXFORD"]),
    "tr_TR": ("TR", ["TURKEY", "TURKIYE", "TR"],
              ["ISTANBUL", "ANKARA", "IZMIR", "BURSA", "ANTALYA", "KONYA", "ADANA", "GAZIANTEP", "KAYSERI", "MERSIN"]),
    # held out from training by default (test of generalisation to unseen countries)
    "pt_PT": ("PT", ["PORTUGAL", "PT"],
              ["LISBOA", "PORTO", "BRAGA", "COIMBRA", "FUNCHAL", "SETUBAL", "AVEIRO", "EVORA", "FARO", "VISEU"]),
    "ro_RO": ("RO", ["ROMANIA", "RO"],
              ["BUCURESTI", "CLUJ-NAPOCA", "TIMISOARA", "IASI", "CONSTANTA", "CRAIOVA", "BRASOV", "GALATI", "PLOIESTI", "ORADEA"]),
}
TRAIN_LOCALES = [loc for loc in COUNTRIES if loc not in ("pt_PT", "ro_RO")]
HELDOUT_LOCALES = ["pt_PT", "ro_RO"]

# extra training countries used by the hard data (Latin script; Portugal and Romania stay held out)
EXTRA_COUNTRIES = {
    "fi_FI": ("FI", ["FINLAND", "SUOMI", "FI"], ["HELSINKI", "ESPOO", "TAMPERE", "VANTAA", "OULU", "TURKU", "JYVASKYLA", "LAHTI", "KUOPIO", "PORI"]),
    "no_NO": ("NO", ["NORWAY", "NORGE", "NO"], ["OSLO", "BERGEN", "TRONDHEIM", "STAVANGER", "DRAMMEN", "KRISTIANSAND", "TROMSO", "FREDRIKSTAD", "SANDNES", "BODO"]),
    "hu_HU": ("HU", ["HUNGARY", "MAGYARORSZAG", "HU"], ["BUDAPEST", "DEBRECEN", "SZEGED", "MISKOLC", "PECS", "GYOR", "NYIREGYHAZA", "KECSKEMET", "SZEKESFEHERVAR", "SZOMBATHELY"]),
    "sk_SK": ("SK", ["SLOVAKIA", "SLOVENSKO", "SLOVAK REPUBLIC", "SK"], ["BRATISLAVA", "KOSICE", "PRESOV", "ZILINA", "NITRA", "BANSKA BYSTRICA", "TRNAVA", "MARTIN", "TRENCIN", "POPRAD"]),
    "lt_LT": ("LT", ["LITHUANIA", "LIETUVA", "LT"], ["VILNIUS", "KAUNAS", "KLAIPEDA", "SIAULIAI", "PANEVEZYS", "ALYTUS", "MARIJAMPOLE", "MAZEIKIAI", "JONAVA", "UTENA"]),
    "lv_LV": ("LV", ["LATVIA", "LATVIJA", "LV"], ["RIGA", "DAUGAVPILS", "LIEPAJA", "JELGAVA", "JURMALA", "VENTSPILS", "REZEKNE", "VALMIERA", "OGRE", "TUKUMS"]),
    "et_EE": ("EE", ["ESTONIA", "EESTI", "EE"], ["TALLINN", "TARTU", "NARVA", "PARNU", "KOHTLA-JARVE", "VILJANDI", "RAKVERE", "MAARDU", "KURESSAARE", "VORU"]),
    "sl_SI": ("SI", ["SLOVENIA", "SLOVENIJA", "SI"], ["LJUBLJANA", "MARIBOR", "CELJE", "KRANJ", "KOPER", "VELENJE", "NOVO MESTO", "PTUJ", "NOVA GORICA", "MURSKA SOBOTA"]),
    "hr_HR": ("HR", ["CROATIA", "HRVATSKA", "HR"], ["ZAGREB", "SPLIT", "RIJEKA", "OSIJEK", "ZADAR", "PULA", "SLAVONSKI BROD", "KARLOVAC", "VARAZDIN", "SIBENIK"]),
    "de_AT": ("AT", ["AUSTRIA", "OESTERREICH", "OSTERREICH", "AT"], ["WIEN", "GRAZ", "LINZ", "SALZBURG", "INNSBRUCK", "KLAGENFURT", "VILLACH", "WELS", "ST. POELTEN", "DORNBIRN"]),
    "nl_BE": ("BE", ["BELGIUM", "BELGIE", "BELGIQUE", "BE"], ["ANTWERPEN", "GENT", "BRUGGE", "LEUVEN", "MECHELEN", "AALST", "HASSELT", "KORTRIJK", "OOSTENDE", "BRUSSEL"]),
    "fr_CH": ("CH", ["SWITZERLAND", "SUISSE", "SCHWEIZ", "CH"], ["GENEVE", "LAUSANNE", "NEUCHATEL", "FRIBOURG", "SION", "MONTREUX", "NYON", "VEVEY", "YVERDON-LES-BAINS", "LA CHAUX-DE-FONDS"]),
    "en_AU": ("AU", ["AUSTRALIA", "AU"], ["SYDNEY", "MELBOURNE", "BRISBANE", "PERTH", "ADELAIDE", "CANBERRA", "HOBART", "DARWIN", "GOLD COAST", "NEWCASTLE"]),
    "en_CA": ("CA", ["CANADA", "CA"], ["TORONTO", "MONTREAL", "VANCOUVER", "CALGARY", "OTTAWA", "EDMONTON", "WINNIPEG", "QUEBEC", "HAMILTON", "HALIFAX"]),
    "en_NZ": ("NZ", ["NEW ZEALAND", "NZ"], ["AUCKLAND", "WELLINGTON", "CHRISTCHURCH", "HAMILTON", "TAURANGA", "DUNEDIN", "NAPIER", "NELSON", "ROTORUA", "WHANGAREI"]),
    "en_IN": ("IN", ["INDIA", "IN"], ["MUMBAI", "DELHI", "BANGALORE", "CHENNAI", "KOLKATA", "HYDERABAD", "PUNE", "AHMEDABAD", "JAIPUR", "SURAT"]),
    "es_MX": ("MX", ["MEXICO", "MX"], ["CIUDAD DE MEXICO", "GUADALAJARA", "MONTERREY", "PUEBLA", "TIJUANA", "LEON", "CANCUN", "MERIDA", "QUERETARO", "TOLUCA"]),
    "id_ID": ("ID", ["INDONESIA", "ID"], ["JAKARTA", "SURABAYA", "BANDUNG", "MEDAN", "SEMARANG", "MAKASSAR", "PALEMBANG", "DENPASAR", "YOGYAKARTA", "BATAM"]),
}
EXTRA_LOCALES = list(EXTRA_COUNTRIES)


def country_info(loc: str) -> tuple[str, list[str], list[str]]:
    return COUNTRIES[loc] if loc in COUNTRIES else EXTRA_COUNTRIES[loc]


POSTCODE_BEFORE_TOWN = {"de_DE", "fr_FR", "pl_PL", "it_IT", "es_ES", "nl_NL", "de_CH", "sv_SE", "cs_CZ", "da_DK", "tr_TR", "pt_PT", "ro_RO",
                        "fi_FI", "no_NO", "hu_HU", "sk_SK", "lt_LT", "lv_LV", "et_EE", "sl_SI", "hr_HR", "de_AT", "nl_BE", "fr_CH", "es_MX"}
NUMBER_BEFORE_STREET = {"en_US", "en_GB", "en_IE", "fr_FR", "en_AU", "en_CA", "en_NZ", "en_IN", "fr_CH"}

# ---- material for the hard data
LEGAL_FORMS = {
    "fi_FI": ["OY", "OYJ", "KY", "AB"], "no_NO": ["AS", "ASA", "ANS", "DA"], "hu_HU": ["KFT", "KFT.", "ZRT", "NYRT", "BT"],
    "sk_SK": ["S.R.O.", "A.S.", "SPOL. S R.O.", "V.O.S."], "lt_LT": ["UAB", "AB", "MB", "VSI"], "lv_LV": ["SIA", "AS", "IK"],
    "et_EE": ["OU", "AS", "MTU", "TU"], "sl_SI": ["D.O.O.", "D.D.", "S.P."], "hr_HR": ["D.O.O.", "D.D.", "J.D.O.O."],
    "de_AT": ["GMBH", "AG", "KG", "OG", "GESMBH"], "nl_BE": ["BV", "NV", "BVBA", "CVBA", "VZW"], "fr_CH": ["SA", "SARL", "SAGL", "AG"],
    "en_AU": ["PTY LTD", "PTY. LIMITED", "LTD"], "en_CA": ["INC.", "LTD.", "CORP.", "ULC"], "en_NZ": ["LIMITED", "LTD"],
    "en_IN": ["PVT LTD", "PRIVATE LIMITED", "LLP", "LTD"], "es_MX": ["S.A. DE C.V.", "S. DE R.L. DE C.V.", "S.C.", "S.A.P.I. DE C.V."],
    "id_ID": ["PT", "CV", "TBK", "PT TBK"], "pl_PL": ["SP. Z O.O.", "S.A.", "SP.K.", "SP.J."], "de_DE": ["GMBH", "AG", "KG", "GMBH + CO. KG", "UG"],
    "it_IT": ["S.R.L.", "S.P.A.", "S.N.C.", "S.A.S."], "es_ES": ["S.L.", "S.A.", "S.L.U.", "S.COOP."], "fr_FR": ["SAS", "SARL", "SA", "SNC", "EURL"],
    "nl_NL": ["BV", "B.V.", "NV", "VOF"], "sv_SE": ["AB", "HB", "KB"], "da_DK": ["A/S", "APS", "I/S"], "cs_CZ": ["S.R.O.", "A.S.", "V.O.S."],
    "tr_TR": ["A.S.", "LTD. STI.", "LTD STI"], "en_US": ["INC", "INC.", "LLC", "CORP", "CO.", "LP"], "en_GB": ["LTD", "PLC", "LLP", "LIMITED"],
    "en_IE": ["LTD", "DAC", "CLG", "PLC"], "de_CH": ["AG", "GMBH", "SA", "SARL"],
}
LOCAL_STREETS = {  # countries whose Faker street names are English placeholders
    "lt_LT": ["G.", "GATVE", "PR.", "PROSPEKTAS", "AL."], "lv_LV": ["IELA", "IELA", "BULVARIS", "PROSPEKTS"],
    "et_EE": ["TANAV", "MNT", "PST", "TEE"],
}
POSTCODE_PREFIX = {"lt_LT": "LT-", "lv_LV": "LV-"}
ABBREVIATIONS = [("STREET", "ST"), ("STREET", "ST."), ("AVENUE", "AVE"), ("AVENUE", "AV."), ("ROAD", "RD"), ("BOULEVARD", "BLVD"),
                 ("STRASSE", "STR."), ("ULICA", "UL."), ("UTCA", "U."), ("CALLE", "C/"), ("AVENIDA", "AVDA."), ("PLATZ", "PL."),
                 ("DRIVE", "DR"), ("LANE", "LN"), ("PLACE", "PL")]
# User rules (2026-10-18): every word of the party is "who" (name side) or "where" (address side). Identifiers and contact
# details are "who" (PARTY_ID); NOISE is only garbage and placeholders that carry no information.
HARD_IDS = ["BIC {bic}", "SWIFT {bic}", "SWIFT: {bic}", "INFO(AT){domain}.COM", "WWW.{domain}.COM", "ACC NO {num}", "ID {num}",
            "DOB {date}", "CUST NO {num}", "PASSPORT {pp}", "REG NO {num}"]
GARBAGE = ["?", "...", "===", "???", "+++", "---", "//", "*", "***", "###", "%@#$^$#", "@@@", "~~~", "$$$", "^^", "<>", "(?)", "#"]
PLACEHOLDERS = ["NOT PROVIDED", "NOTPROVIDED", "N/A", "UNKNOWN", "XXX", "NONE", "-", "NIL", "TBC", "SEE ABOVE"]
ROLE_WORDS = ["BENEFICIARY", "BENEFICIARY:", "CUSTOMER", "ACCOUNT HOLDER", "ORDERING CUSTOMER", "PAYEE", "CLIENT"]
DEPARTMENTS = ["ACCOUNTS DEPT", "FINANCE", "TREASURY", "PAYMENTS", "A/P DEPT", "ACCOUNTS PAYABLE", "BACK OFFICE", "SALES",
               "FINANCE DEPARTMENT", "LEGAL DEPT", "COMPLIANCE", "PROCUREMENT"]

# a second party inside the field: marker (PARTY_INTRO) + the party's name
SECOND_PARTY = [  # (role, marker variants, weight)
    ("care_of", ["C/O"] * 6 + ["C/O.", "C/O:", "CARE OF", "C.O.", "C / O"], 0.40),
    ("attention", ["ATTN"] * 4 + ["ATTN:", "ATTN.", "ATTENTION", "FAO"], 0.25),
    ("on_behalf_of", ["OBO", "OBO", "O.B.O.", "ON BEHALF OF"], 0.12),
    ("further_credit", ["FFC", "FFC", "FFC:", "F.F.C.", "FOR FURTHER CREDIT TO", "FOR FURTHER CREDIT OF"], 0.12),
    ("trading_as", ["T/A", "T/A", "TRADING AS", "DBA", "D/B/A"], 0.11),
]
BRAND_WORDS = ["ALPHA", "BETA", "DELTA", "GAMMA", "OMEGA", "SIGMA", "ATLAS", "ORION", "PHOENIX", "APEX", "SUMMIT", "NOVA", "PRIME",
               "UNITED", "GLOBAL", "GOLDEN", "SILVER", "EAGLE", "FALCON", "LION", "NORTHSTAR", "BLUE OCEAN", "GREENFIELD", "VERTEX",
               "ZENITH", "HORIZON", "PIONEER", "MERIDIAN", "CRESCENT", "TITAN", "AURORA", "POLARIS", "ASTRA", "BALTIC", "NORDIC",
               "EURO", "TRANS", "INTER", "PACIFIC", "ATLANTIC", "CONTINENTAL", "IMPERIAL", "ROYAL", "STAR", "SUNRISE", "OAK", "CEDAR"]
INDUSTRY_WORDS = ["CORPORATE SERVICES", "TRADING", "HOLDINGS", "SHIPPING", "LOGISTICS", "INVESTMENTS", "CAPITAL", "MANAGEMENT",
                  "CONSULTING", "TRUST", "NOMINEES", "FIDUCIARY SERVICES", "IMPORT EXPORT", "ENERGY", "MINING", "TEXTILES", "FOODS",
                  "MOTORS", "TECHNOLOGIES", "SOLUTIONS", "PROPERTIES", "REAL ESTATE", "MARINE", "AGRO", "PHARMA", "CHEMICALS",
                  "METALS", "TIMBER", "FREIGHT", "VENTURES", "PARTNERS", "SECURITIES", "INSURANCE", "ENGINEERING", "CONSTRUCTION"]
INTERMEDIARIES = ["{brand} CORPORATE SERVICES {form}", "{brand} TRUST COMPANY {form}", "{brand} NOMINEES {form}", "{brand} MANAGEMENT {form}",
                  "{brand} FIDUCIARY {form}", "GRAND HOTEL {place}", "HOTEL {place}", "{place} HOTEL", "{place} RESIDENCE",
                  "{last} + PARTNERS", "{last} LAW OFFICE", "{last} + {last2} {form}", "{brand} BANK {form}", "{last} ACCOUNTANTS {form}",
                  "{brand} SHIPPING AGENCY {form}", "{brand} BUSINESS CENTRE", "{brand} REGISTERED AGENTS {form}"]
HOTEL_WORDS = ["EUROPA", "CONTINENTAL", "PLAZA", "ROYAL", "IMPERIAL", "CENTRAL", "PALACE", "ASTORIA", "BRISTOL", "METROPOL", "SAVOY"]
SEPARATORS = [" ", " ", " ", ", ", ", ", " ,", "; ", " / ", " - "]

_TRANSLIT = str.maketrans({"Ł": "L", "ł": "l", "Ø": "O", "ø": "o", "Æ": "AE", "æ": "ae", "Œ": "OE", "œ": "oe",
                           "Đ": "D", "đ": "d", "Þ": "TH", "þ": "th", "ß": "SS", "ı": "i", "İ": "I", "&": "+",
                           "\"": "", "_": " ", "@": "(AT)", "!": "", "#": "NO ", "*": "", ";": ",", "’": "'"})
_NOT_X = re.compile(r"[^A-Z0-9/\-?:().,'+ \n]")


def to_swift_x(text: str) -> str:
    """Upper-case, transliterate and keep only SWIFT X characters."""
    text = text.translate(_TRANSLIT)
    text = unicodedata.normalize("NFKD", text)
    text = "".join(c for c in text if not unicodedata.combining(c)).upper()
    text = _NOT_X.sub(" ", text)
    return re.sub(r" {2,}", " ", text).strip()


@dataclass
class Comp:
    label: str
    text: str
    before: str | None = None  # separator forced before this component ("/" in 142/5)


@dataclass
class Example:
    text: str
    char_labels: list[str]
    char_comp: list[int]
    joins: list[tuple[int, bool]]  # (index of "\n", the line break splits a word)
    meta: dict = field(default_factory=dict)

    def spans(self) -> list[dict]:
        """Gold components as character spans."""
        by_comp: dict[int, list[int]] = {}
        for i, c in enumerate(self.char_comp):
            if c >= 0:
                by_comp.setdefault(c, []).append(i)
        out = []
        for c, idx in sorted(by_comp.items(), key=lambda kv: kv[1][0]):
            s, e = idx[0], idx[-1] + 1
            out.append({"start": s, "end": e, "label": self.char_labels[s], "text": self.text[s:e]})
        return out

    def to_json(self) -> str:
        return json.dumps(asdict(self), ensure_ascii=False)

    @staticmethod
    def from_json(line: str) -> "Example":
        d = json.loads(line)
        d["joins"] = [tuple(j) for j in d["joins"]]
        return Example(**d)


# ---------------------------------------------------------------- components

def _person(fk: Faker, rng: random.Random) -> str:
    first, last = fk.first_name(), fk.last_name()
    style = rng.random()
    if style < 0.40:
        name = f"{first} {last}"
    elif style < 0.60:
        name = f"{last} {first}"
    elif style < 0.70:
        name = f"{last}, {first}"
    elif style < 0.78:
        name = f"{first[0]}. {last}"
    elif style < 0.86:
        name = f"{first} {fk.first_name()} {last}"
    elif style < 0.93:
        name = f"{rng.choice(['MR', 'MRS', 'MS', 'DR', 'MR.', 'MRS.'])} {first} {last}"
    else:
        name = f"{first} {last} {rng.choice(['AND', '+', '&'])} {fk.first_name()} {fk.last_name()}"
    return to_swift_x(name)


def _legal_form(rng: random.Random, loc: str) -> str:
    return rng.choice(LEGAL_FORMS.get(loc, LEGAL_FORMS["en_GB"]) + ["LTD", "LIMITED", "CO LTD", "CO., LTD.", "INC"])


def _brand_company(fk: Faker, rng: random.Random, loc: str, form_p: float = 0.75) -> str:
    """ALPHA CORPORATE SERVICES LTD, NORDIC TIMBER TRADING AS: invented brand + industry + legal form."""
    brand = rng.choice(BRAND_WORDS) if rng.random() < 0.6 else fk.last_name()
    if rng.random() < 0.2:
        brand = f"{brand} {rng.choice(BRAND_WORDS)}"
    name = f"{brand} {rng.choice(INDUSTRY_WORDS)}" if rng.random() < 0.9 else brand
    if rng.random() < 0.06:
        name = f"THE {name} COMPANY"
    if rng.random() < form_p:
        name = f"{name} {_legal_form(rng, loc)}"
    return to_swift_x(name)


def _intermediary(fk: Faker, rng: random.Random, loc: str) -> str:
    """Typical C/O parties: corporate service providers, hotels, law firms, banks."""
    place = rng.choice(HOTEL_WORDS) if rng.random() < 0.7 else rng.choice(country_info(loc)[2])
    name = rng.choice(INTERMEDIARIES).format(
        brand=rng.choice(BRAND_WORDS) if rng.random() < 0.6 else fk.last_name(), form=_legal_form(rng, loc) if rng.random() < 0.8 else "",
        place=place, last=fk.last_name(), last2=fk.last_name())
    return to_swift_x(name)


def _company(fk: Faker, rng: random.Random, loc: str = "", hard: bool = False) -> str:
    if rng.random() < 0.25:
        return _brand_company(fk, rng, loc)
    if hard and loc in LOCAL_STREETS:  # Faker gives English "X and Sons" companies here
        base = fk.last_name()
        form = rng.choice(LEGAL_FORMS[loc])
        name = f"{form} {base}" if loc == "lt_LT" and rng.random() < 0.6 else f"{base} {form}"
    else:
        name = fk.company()
    if rng.random() < 0.15:
        name = f"{name} {rng.choice(['TRADING', 'HOLDING', 'INTERNATIONAL', 'LOGISTICS', 'GROUP', 'SERVICES'])}"
    if hard:
        if rng.random() < 0.12:  # company named after a town: the same word is name here and address elsewhere
            word = rng.choice(['METAL', 'TRADING', 'SHIPPING', 'BANK', 'MOTORS', 'FOODS', 'TEXTILE', 'ENERGY'])
            name = f"{rng.choice(country_info(loc)[2])} {word}"
        last = to_swift_x(name).split(" ")[-1].replace(".", "")
        has_form = any(last == f.replace(".", "").split(" ")[-1] for forms in LEGAL_FORMS.values() for f in forms)
        if rng.random() < 0.45 and not has_form:
            name = f"{name} {rng.choice(LEGAL_FORMS.get(loc, LEGAL_FORMS['en_GB']))}"
    return to_swift_x(name)


def _street_line(fk: Faker, rng: random.Random, loc: str, hard: bool = False) -> list[Comp]:
    if hard and loc in LOCAL_STREETS:
        street = to_swift_x(f"{fk.last_name()} {rng.choice(LOCAL_STREETS[loc])}")
    elif hard and rng.random() < 0.1:  # street named after a person (GEORGE WASHINGTON AVENUE, JANA PAWLA II)
        street = to_swift_x(f"{fk.first_name()} {fk.last_name()} {rng.choice(['STREET', 'AVENUE', 'ROAD', 'STRASSE', 'PLACE'])}")
    else:
        street = to_swift_x(fk.street_name())
    if loc == "pl_PL" and not street.startswith(("UL", "AL", "PL", "OS")):
        street = f"{rng.choice(['UL.', 'UL', 'AL.', 'PL.', 'OS.'])} {street}"
    if hard and rng.random() < 0.5:
        for full, short in rng.sample(ABBREVIATIONS, len(ABBREVIATIONS)):
            if re.search(rf"\b{full}\b", street):
                street = re.sub(rf"\b{full}\b", short, street, count=1)
                break
    number = to_swift_x(fk.building_number()).replace("NR. ", "").replace("NR ", "") or str(rng.randint(1, 200))
    faker_flat = None
    pair = re.fullmatch(r"(\d+)[/-](\d+)", number)
    if pair:  # Faker writes "74/39": a range only when ascending and close, otherwise building + flat
        b, s = int(pair.group(1)), int(pair.group(2))
        if not b < s <= b + 6:
            number, faker_flat = str(b), str(s)
    base = int(number) if number.isdigit() else None
    shape = rng.random()
    if base is not None and shape < 0.07:
        # one building on several numbers (142/144, 142/143, 142/144/146): ascending and close -> all BUILDING
        step = rng.choice([1, 2, 2])
        parts = [base + i * step for i in range(rng.choice([2, 2, 3]))]
        number = rng.choice(["/", "/", "/", "-"]).join(map(str, parts))
    elif loc in ("cs_CZ", "sk_SK") and shape < 0.5:
        # Czech/Slovak "conscription/orientation" number (1079/3A): both identify the building, no flat
        number = f"{rng.randint(100, 3500)}/{rng.randint(1, 80)}{rng.choice(['', '', '', 'A', 'B'])}"
    if hard:
        r = rng.random()
        if r < 0.08 and loc in ("es_ES", "es_MX", "it_IT", "fr_FR"):
            number = rng.choice(["S/N", "SN", "SIN NUMERO"])
        elif r < 0.2:
            number = f"{rng.choice(['NO', 'NO.', 'NR', 'NR.', 'N.', 'NUM.'])} {number}"
    comps = []
    unit = None
    if faker_flat and "/" not in number:
        unit = Comp("UNIT", faker_flat, before="/")
    elif rng.random() < 0.3:
        u_val = rng.randint(1, 120)
        while base is not None and base < u_val <= base + 6:  # 142/144 reads as a range of building numbers, not a flat
            u_val = rng.randint(1, 120)
        u = str(u_val)
        kinds = [Comp("UNIT", f"APT {u}"), Comp("UNIT", f"FLAT {u}"), Comp("UNIT", f"SUITE {u}"),
                 Comp("UNIT", f"LOK. {u}"), Comp("UNIT", f"M. {u}"), Comp("UNIT", f"UNIT {u}")]
        if "/" not in number:
            kinds.append(Comp("UNIT", u, before="/"))  # 142/5 = building 142, flat 5
        unit = rng.choice(kinds)
    if loc in NUMBER_BEFORE_STREET and rng.random() < 0.85:
        comps += [Comp("BUILDING", number), Comp("STREET", street)]
        if unit:
            unit.before = None
            comps.append(unit)
    else:
        comps += [Comp("STREET", street), Comp("BUILDING", number)]
        if unit:
            comps.append(unit)
    return comps


def _address(fk: Faker, rng: random.Random, loc: str, hard: bool = False) -> list[list[Comp]]:
    """Address as logical lines of components."""
    iso2, country_names, towns = country_info(loc)
    lines: list[list[Comp]] = []
    if rng.random() < 0.08:
        lines.append([Comp("PO_BOX", rng.choice(["PO BOX", "P.O. BOX", "POSTFACH", "SKRYTKA"]) + f" {rng.randint(1, 9999)}")])
    elif rng.random() < 0.95:
        lines.append(_street_line(fk, rng, loc, hard))
    english_city = hard and loc in LOCAL_STREETS
    town = rng.choice(towns) if rng.random() < 0.6 or english_city else to_swift_x(fk.city())
    postcode = to_swift_x(fk.postcode()) if rng.random() < 0.85 else None
    if hard and postcode and loc in POSTCODE_PREFIX and rng.random() < 0.6:
        postcode = POSTCODE_PREFIX[loc] + postcode
    region_fn = getattr(fk, "state_abbr", None) or getattr(fk, "province_abbr", None)
    town_line: list[Comp] = []
    if hard and rng.random() < 0.04:  # placeholder where the town should be
        town_line.append(Comp("NOISE", rng.choice(PLACEHOLDERS)))
    elif loc == "en_US" or (hard and loc in ("en_CA", "en_AU", "es_MX") and region_fn):
        town_line.append(Comp("TOWN", town))
        if rng.random() < 0.8:
            town_line.append(Comp("REGION", to_swift_x(region_fn())))
        if postcode:
            town_line.append(Comp("POSTCODE", postcode))
    elif loc in POSTCODE_BEFORE_TOWN and rng.random() < 0.85:
        if postcode:
            town_line.append(Comp("POSTCODE", postcode))
        town_line.append(Comp("TOWN", town))
    else:
        town_line.append(Comp("TOWN", town))
        if postcode:
            town_line.append(Comp("POSTCODE", postcode))
    lines.append(town_line)
    if rng.random() < 0.75:
        lines.append([Comp("COUNTRY", rng.choice(country_names))])
    if rng.random() < (0.15 if hard else 0.05):
        rng.shuffle(lines)
    return lines


def _extra(fk: Faker, rng: random.Random, hard: bool = False) -> Comp:
    """Text in the field that is neither the party's name nor its postal address."""
    if hard and rng.random() < 0.3:
        bic = "".join(rng.choice("ABCDEFGHIJKLMNOPQRSTUVWXYZ") for _ in range(6)) + rng.choice(["2X", "PW", "FF", "22", "XX"]) + rng.choice(["", "XXX"])
        return Comp("PARTY_ID", to_swift_x(rng.choice(HARD_IDS).format(
            bic=bic, domain=to_swift_x(fk.last_name()).replace(" ", ""), num=rng.randint(1000, 9999999),
            date=f"{rng.randint(1950, 2005)}-{rng.randint(1, 12):02d}-{rng.randint(1, 28):02d}", pp=f"{rng.choice('ABCDEFXYZ')}{rng.randint(1000000, 9999999)}")))
    kind = rng.random()
    if kind < 0.24:
        return Comp("PARTY_ID", rng.choice(["REF", "INV", "INVOICE", "PO", "ORDER", "CONTRACT"]) + rng.choice([" ", " NO ", " NR "]) + str(rng.randint(100, 999999)))
    if kind < 0.42:
        return Comp("PARTY_ID", rng.choice(["TEL", "PHONE", "MOB", "FAX"]) + " " + re.sub(r"[^0-9+ ]", " ", fk.phone_number()).strip())
    if kind < 0.58:
        return Comp("PARTY_ID", rng.choice(["VAT", "NIP", "TAX ID", "REGON", "KRS"]) + " " + str(rng.randint(10**7, 10**10)))
    if kind < 0.72:
        return Comp("NOISE", rng.choice(PLACEHOLDERS))
    if kind < 0.84:
        return Comp("NOISE", rng.choice(GARBAGE))  # raw: garbage may be outside the SWIFT X character set
    if kind < 0.93:
        return Comp("PARTY_INTRO", rng.choice(ROLE_WORDS))
    return Comp("PARTY_ID", "AS PER INVOICE")


def _second_party(fk: Faker, rng: random.Random, loc: str, hard: bool) -> tuple[str, list[Comp]]:
    """C/O, ATTN, OBO, FFC or T/A followed by another party's name."""
    roles, variants, weights = zip(*SECOND_PARTY)
    k = rng.choices(range(len(roles)), weights=weights)[0]
    role, r = roles[k], rng.random()
    if role == "care_of":
        entity = (Comp("NAME_ORG", _intermediary(fk, rng, loc)) if r < 0.5 else Comp("NAME_PERSON", _person(fk, rng)) if r < 0.7
                  else Comp("NAME_ORG", _company(fk, rng, loc, hard)))
    elif role == "attention":
        entity = Comp("NAME_ORG", rng.choice(DEPARTMENTS)) if r < 0.45 else Comp("NAME_PERSON", _person(fk, rng))
    elif role == "trading_as":
        entity = Comp("NAME_ORG", _brand_company(fk, rng, loc, form_p=0.3))
    else:
        entity = Comp("NAME_PERSON", _person(fk, rng)) if r < 0.5 else Comp("NAME_ORG", _company(fk, rng, loc, hard))
    entity.before = " "
    return role, [Comp("PARTY_INTRO", rng.choice(variants[k])), entity]


def _account(fk: Faker, rng: random.Random, loc: str) -> str:
    kind = rng.random()
    if kind < 0.6:
        try:
            return "/" + fk.iban()
        except Exception:
            pass
    if kind < 0.8:
        return "/" + str(rng.randint(10**7, 10**16))
    if kind < 0.9:
        return "//FW" + str(rng.randint(10**8, 10**9 - 1))
    return "/" + "".join(rng.choice("ABCDEFGHJKLMNPQRSTUVWXYZ0123456789") for _ in range(rng.randint(8, 20)))


# ---------------------------------------------------------------- rendering

Char = tuple[str, str, int]  # (character, label, component id)


class _Canvas:
    def __init__(self):
        self.next_comp = 0

    def comp(self, c: Comp) -> list[Char]:
        cid = self.next_comp
        self.next_comp += 1
        return [(ch, c.label, cid) for ch in c.text]

    @staticmethod
    def sep(text: str) -> list[Char]:
        return [(ch, "O", -1) for ch in text]


def _glue(canvas: _Canvas, comps: list[Comp], rng: random.Random, sep: str | None = None) -> list[Char]:
    out: list[Char] = []
    for i, c in enumerate(comps):
        if i:
            out += canvas.sep(c.before if c.before is not None else (sep if sep is not None else " "))
        out += canvas.comp(c)
    return out


def _word_wrap(chars: list[Char], width: int) -> list[list[Char]]:
    lines, cur = [], []
    words: list[list[Char]] = []
    w: list[Char] = []
    for ch in chars:
        if ch[0] == " ":
            if w:
                words.append(w)
                w = []
        else:
            w.append(ch)
    if w:
        words.append(w)
    for i, word in enumerate(words):
        gap = [(" ", "O", -1)]
        if cur:
            # the space keeps the component id if the words around it belong to the same component
            if cur[-1][2] == word[0][2] and word[0][2] >= 0:
                gap = [(" ", word[0][1], word[0][2])]
        if cur and len(cur) + 1 + len(word) > width:
            lines.append(cur)
            cur = []
        if not cur:
            while len(word) > width:
                lines.append(word[:width])
                word = word[width:]
            cur = list(word)
        else:
            cur += gap + word
    if cur:
        lines.append(cur)
    return lines


def _hard_wrap(chars: list[Char], width: int) -> list[list[Char]]:
    lines = []
    rest = list(chars)
    while rest:
        line, rest = rest[:width], rest[width:]
        while rest and rest[0][0] == " ":
            rest = rest[1:]
        while line and line[-1][0] == " ":
            line = line[:-1]
        if line:
            lines.append(line)
    return lines


def _render(lines: list[list[Char]], account: list[Char] | None, meta: dict) -> Example:
    if len(lines) > MAX_LINES:
        lines = lines[:MAX_LINES]
        meta["truncated"] = True
    if account:
        lines = [account] + lines
    chars: list[Char] = []
    joins: list[tuple[int, bool]] = []
    for i, line in enumerate(lines):
        if i:
            prev, nxt = chars[-1], line[0]
            continues = prev[2] == nxt[2] and prev[2] >= 0 and prev[0].isalnum() and nxt[0].isalnum() and meta.get("_midword", {}).get(id(line), False)
            joins.append((len(chars), continues))
            # a mid-word break stays inside the component; other breaks are separators
            chars.append(("\n", prev[1], prev[2]) if continues else ("\n", "O", -1))
        chars += line
    meta.pop("_midword", None)
    return Example(
        text="".join(c[0] for c in chars),
        char_labels=[c[1] for c in chars],
        char_comp=[c[2] for c in chars],
        joins=joins,
        meta=meta,
    )


def _mark_midword(lines: list[list[Char]], source: list[Char], meta: dict) -> None:
    """Remember which wrapped lines start in the middle of a word of the source string."""
    flags = meta.setdefault("_midword", {})
    pos = 0
    text = "".join(c[0] for c in source)
    for line in lines:
        piece = "".join(c[0] for c in line)
        start = text.find(piece, pos)
        flags[id(line)] = start > 0 and text[start - 1] != " "
        pos = start + len(piece)


def generate_example(rng: random.Random, fakers: dict[str, Faker], locales: list[str], hard: bool = False) -> Example:
    """One labelled field. hard=True: more countries' conventions, more and stranger noise, twins,
    abbreviations, placeholders, name-only / address-only fields and more shuffled orders."""
    loc = rng.choice(locales)
    fk = fakers[loc]
    canvas = _Canvas()
    is_person = rng.random() < 0.45
    name = Comp("NAME_PERSON", _person(fk, rng)) if is_person else Comp("NAME_ORG", _company(fk, rng, loc, hard))
    address = _address(fk, rng, loc, hard)
    counts, weights = ([0, 1, 2, 3], [0.30, 0.35, 0.25, 0.10]) if hard else ([0, 1, 2], [0.55, 0.35, 0.10])
    noise = [_extra(fk, rng, hard) for _ in range(rng.choices(counts, weights=weights)[0])]
    meta = {"locale": loc, "party": "person" if is_person else "org", "truncated": False}
    parts = "both"
    if hard:
        r = rng.random()
        if r < 0.04:
            parts, address = "name_only", []
        elif r < 0.08:
            parts, meta["party"] = "address_only", "none"
    meta["parts"] = parts
    second, place = None, None
    if parts != "address_only" and rng.random() < (0.30 if hard else 0.22):
        role, second = _second_party(fk, rng, loc, hard)
        meta["second_party"] = role
        where = rng.random()
        place = ("after_name" if role not in ("attention", "on_behalf_of", "further_credit") or where < 0.55
                 else "end" if role == "attention" and where < 0.9 else "start")
        if place == "after_name" and rng.random() < (0.6 if role == "trading_as" else 0.3):
            place = "same_line"

    style = rng.choices(["natural", "glued_hard", "glued_word", "f_format", "name_then_glued"],
                        weights=[0.20, 0.35, 0.15, 0.15, 0.15] if hard else [0.25, 0.30, 0.15, 0.15, 0.15])[0]
    meta["style"] = style
    noise_at = rng.choice(["end", "end", "start", "after_name"] + (["middle", "middle"] if hard else [])) if noise else None
    sep = rng.choice(SEPARATORS)

    if style == "f_format":
        meta["tag"] = rng.choice(["50F", "59F"])
        lines: list[list[Char]] = []
        if parts != "address_only":
            for chunk in _hard_wrap(canvas.comp(name), LINE_WIDTH - 2):
                lines.append([("1", "LINE_PREFIX", -2), ("/", "LINE_PREFIX", -2)] + chunk)
        if second:  # C/O usually sits in an address line (2/), the other markers continue the name (1/)
            code = "2" if meta["second_party"] == "care_of" and rng.random() < 0.75 else "1"
            for chunk in _word_wrap(_glue(canvas, second, rng), LINE_WIDTH - 2):
                lines.append([(code, "LINE_PREFIX", -2), ("/", "LINE_PREFIX", -2)] + chunk)
        for comps in address:
            if any(c.label == "COUNTRY" for c in comps):
                continue
            body = _glue(canvas, comps, rng)[: LINE_WIDTH - 2]
            while body and body[-1][0] == " ":
                body.pop()
            lines.append([("2", "LINE_PREFIX", -2), ("/", "LINE_PREFIX", -2)] + body)
        iso2 = country_info(loc)[0]
        town = next((c for comps in address for c in comps if c.label == "TOWN"), None)
        if town:
            # 3/CC/TOWN replaces the last "2/" line that held the town
            lines = [ln for ln in lines if not any(ch[1] == "TOWN" for ch in ln)]
            pc = next((c for comps in address for c in comps if c.label == "POSTCODE"), None)
            line3 = [("3", "LINE_PREFIX", -2), ("/", "LINE_PREFIX", -2)] + canvas.comp(Comp("COUNTRY", iso2)) + canvas.sep("/") + canvas.comp(town)
            if pc and rng.random() < 0.6:
                line3 += canvas.sep(" ") + canvas.comp(pc)
            lines.append(line3[:LINE_WIDTH])
        if meta["tag"] == "50F":
            # 50F identity lines: 4/ date of birth, 5/ place of birth, 6/ customer id, 7/ national id. ISO 20022 keeps them in
            # the party's identification (Id), not in the postal address, so they are PARTY_ID ("who"); 5/ holds a town that is
            # NOT the address
            ident = []
            if meta["party"] == "person" and rng.random() < 0.4:
                ident.append(("4", f"{rng.randint(1940, 2005)}{rng.randint(1, 12):02d}{rng.randint(1, 28):02d}"))
            if meta["party"] == "person" and rng.random() < 0.3:
                ident.append(("5", f"{iso2}/{rng.choice(country_info(loc)[2])}"))
            if rng.random() < 0.2:
                ident.append(("6", f"{iso2}/{rng.choice(['BANK', 'CUST', 'CRN', 'TAX'])}/{rng.randint(10**5, 10**9)}"))
            if meta["party"] == "person" and rng.random() < 0.2:
                ident.append(("7", f"{iso2}/{rng.choice('ABCDEFGHJKLMNPRSTUVWXYZ')}{rng.randint(10**6, 10**8)}"))
            for code, value in ident:
                lines.append([(code, "LINE_PREFIX", -2), ("/", "LINE_PREFIX", -2)] + canvas.comp(Comp("PARTY_ID", value)))
            for n in noise:  # 8/ = additional information
                lines.append([("8", "LINE_PREFIX", -2), ("/", "LINE_PREFIX", -2)] + canvas.comp(n)[: LINE_WIDTH - 2])
        else:
            # 59F only has codes 1, 2 and 3: extra text ends up inside address lines (2/)
            for n in noise:
                lines.append([("2", "LINE_PREFIX", -2), ("/", "LINE_PREFIX", -2)] + canvas.comp(n)[: LINE_WIDTH - 2])
    else:
        meta["tag"] = rng.choice(["50K", "59"])
        name_part = [name] if parts != "address_only" else []
        addr_lines = [list(line) for line in address]
        if noise_at == "start":
            name_part = noise + name_part
        elif noise_at == "after_name":
            name_part = name_part + noise
        elif noise_at == "end":
            addr_lines.append(noise)
        elif noise_at == "middle":
            addr_lines.insert(min(1, len(addr_lines)), noise)
        head: list[list[Comp]] = [name_part]
        if place == "same_line":
            name_part += second
        elif place == "after_name":
            head.append(second)
        elif place == "start":
            head.insert(0, second)
        elif place == "end":
            addr_lines.append(second)

        if style == "natural":
            lines = []
            for comps in head + addr_lines:
                lines += _word_wrap(_glue(canvas, comps, rng), LINE_WIDTH)
        else:
            flat = [c for comps in head + addr_lines for c in comps]
            if style == "name_then_glued":
                lines = [ln for comps in head for ln in _word_wrap(_glue(canvas, comps, rng), LINE_WIDTH)]
                rest = [c for comps in addr_lines for c in comps]
                glued = _glue(canvas, rest, rng, sep)
                wrapped = _hard_wrap(glued, LINE_WIDTH)
                _mark_midword(wrapped, glued, meta)
                lines += wrapped
            else:
                glued = _glue(canvas, flat, rng, sep)
                if style == "glued_hard":
                    lines = _hard_wrap(glued, LINE_WIDTH)
                    _mark_midword(lines, glued, meta)
                else:
                    lines = _word_wrap(glued, LINE_WIDTH)

    account = None
    if rng.random() < 0.5:
        account = [(ch, "ACCOUNT", 10_000) for ch in _account(fk, rng, loc)[:35]]
    ex = _render(lines, account, meta)
    # component -2 marks line prefixes: give each prefix its own id so spans stay separate
    comp = ex.char_comp
    next_id = 20_000
    for i, c in enumerate(comp):
        if c == -2:
            if i == 0 or comp[i - 1] != next_id:
                next_id += 1
            comp[i] = next_id
    return ex


def ensure_hash_seed() -> None:
    """Faker output for some countries depends on string hashing; re-run the script with a fixed hash seed."""
    import os
    import subprocess
    import sys

    if os.environ.get("PYTHONHASHSEED") != "0":
        env = dict(os.environ, PYTHONHASHSEED="0")
        sys.exit(subprocess.run([sys.executable] + sys.argv, env=env).returncode)


def make_fakers(locales: list[str], seed: int) -> dict[str, Faker]:
    fakers = {}
    for i, loc in enumerate(locales):
        fk = Faker(loc)
        fk.seed_instance(seed * 100 + i)
        fakers[loc] = fk
    return fakers


def generate(n: int, seed: int, locales: list[str], hard: bool = False) -> list[Example]:
    rng = random.Random(seed)
    fakers = make_fakers(locales, seed)
    return [generate_example(rng, fakers, locales, hard) for _ in range(n)]


# ---------------------------------------------------------------- hand-written examples

_MARK = re.compile(r"\{([A-Z]+)\|(.*?)\}", re.S)


def parse_markup(src: str, meta: dict | None = None) -> Example:
    """Parse '{ORG|ACME LTD}\n{STR|MAIN ST} {BLD|5}' into a labelled example.

    A line break written as '¦' + newline marks a word split by the line break (WARS¦\nZAWA);
    every other line break separates words.
    """
    text, labels, comps, split_after = [], [], [], set()
    pos, cid = 0, 0

    def put(chunk: str, label: str, comp: int):
        for ch in chunk:
            if ch == "¦":
                split_after.add(len(text))
                continue
            text.append(ch); labels.append(label); comps.append(comp)

    for m in _MARK.finditer(src):
        put(src[pos:m.start()], "O", -1)
        put(m.group(2), SHORT[m.group(1)], cid)
        cid += 1
        pos = m.end()
    put(src[pos:], "O", -1)
    joins = []
    for i, ch in enumerate(text):
        if ch == "\n":
            joins.append((i, i in split_after))
            if i not in split_after or comps[i] < 0:
                labels[i], comps[i] = "O", -1
    return Example("".join(text), labels, comps, joins, meta or {})


def load_markup_file(path) -> list[Example]:
    raw = open(path, encoding="utf-8").read().strip()
    blocks = [b.strip("\n") for b in re.split(r"^---$", raw, flags=re.M)]
    return [parse_markup(b, {"source": "handcrafted", "id": i}) for i, b in enumerate(blocks) if b.strip()]
