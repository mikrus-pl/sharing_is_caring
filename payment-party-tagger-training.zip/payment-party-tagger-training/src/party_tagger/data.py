"""Turning character-labelled examples into token-level training targets."""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from pathlib import Path

import torch

from party_tagger.device import DEVICE
from party_tagger.labels import LABEL2ID
from party_tagger.swiftgen import Example

IGNORE = -100


@dataclass
class Encoded:
    input_ids: list[int]
    offsets: list[tuple[int, int]]
    labels: list[int]  # per token, IGNORE for BOS and whitespace-only tokens
    joins: list[int]  # per token: 1 / 0 for tokens holding a line break, IGNORE elsewhere


def encode_text(text: str, tokenizer) -> tuple[list[int], list[tuple[int, int]]]:
    enc = tokenizer(text, add_special_tokens=False, return_offsets_mapping=True)
    return [tokenizer.bos_token_id] + enc["input_ids"], [(0, 0)] + [tuple(o) for o in enc["offset_mapping"]]


def encode_example(ex: Example, tokenizer) -> Encoded:
    ids, offsets = encode_text(ex.text, tokenizer)
    join_at = dict(ex.joins)
    labels, joins = [], []
    for k, (s, e) in enumerate(offsets):
        if k == 0:
            labels.append(IGNORE)
            joins.append(IGNORE)
            continue
        chars = [ex.char_labels[i] for i in range(s, e) if not ex.text[i].isspace()]
        # a token like "A," mixes a component with a separator: it takes the component's label
        # (decode trims separator punctuation from span edges)
        content = [c for c in chars if c != "O"] or chars
        labels.append(LABEL2ID[Counter(content).most_common(1)[0][0]] if chars else IGNORE)
        newline = next((i for i in range(s, e) if ex.text[i] == "\n"), None)
        joins.append(int(join_at[newline]) if newline is not None else IGNORE)
    return Encoded(ids, offsets, labels, joins)


def load_jsonl(path: str | Path, limit: int | None = None) -> list[Example]:
    out = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            out.append(Example.from_json(line))
            if limit and len(out) >= limit:
                break
    return out


def collate(batch: list[Encoded], pad_id: int, device: str | None = None) -> dict[str, torch.Tensor]:
    device = device or DEVICE
    width = max(len(b.input_ids) for b in batch)

    def pad(rows, value):
        return torch.tensor([r + [value] * (width - len(r)) for r in rows], device=device)

    return {
        "input_ids": pad([b.input_ids for b in batch], pad_id),
        "attention_mask": pad([[1] * len(b.input_ids) for b in batch], 0),
        "labels": pad([b.labels for b in batch], IGNORE),
        "joins": pad([b.joins for b in batch], IGNORE),
    }
