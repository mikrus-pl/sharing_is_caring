"""Loading the Gemma 4 text backbone for token-level decisions.

Supported checkpoints:
- Gemma-4-E4B (model_type "gemma4"): multimodal; we load only the text decoder and keep the Per-Layer Embedding
  table (2.8B params of pure lookups) in CPU RAM, so the GPU holds ~9 GB of weights.
- Gemma-4-12B (model_type "gemma4_unified"): no per-layer table; loaded in 4-bit (QLoRA) to fit 16 GB.
"""

from __future__ import annotations

from pathlib import Path

import torch
from torch import nn
from transformers import (
    AutoConfig,
    AutoTokenizer,
    BitsAndBytesConfig,
    Gemma4TextConfig,
    Gemma4TextModel,
    Gemma4UnifiedTextConfig,
    Gemma4UnifiedTextModel,
)
from transformers.utils import logging as hf_logging

from party_tagger.device import DEVICE

CHECKPOINT_PREFIX = r"^model\.language_model\."


class CpuEmbedding(nn.Module):
    """Runs an embedding lookup on CPU and returns the result on the compute device.

    The table is deliberately not registered as a submodule, so model.to("cuda") cannot move it.
    """

    def __init__(self, embedding: nn.Embedding, out_device: torch.device):
        super().__init__()
        embedding.requires_grad_(False)
        object.__setattr__(self, "embedding", embedding)
        self.out_device = out_device

    @property
    def weight(self) -> torch.Tensor:
        return self.embedding.weight

    def forward(self, input_ids: torch.Tensor) -> torch.Tensor:
        return self.embedding(input_ids.to("cpu")).to(self.out_device, non_blocking=True)


def set_bidirectional(model: nn.Module, enabled: bool) -> None:
    """Switch every attention layer between causal and bidirectional attention.

    Mirrors the config's __post_init__ for use_bidirectional_attention="all": the mask builders read
    `config.is_causal`, and the sliding window becomes a symmetric half-window.
    """
    config = model.config
    currently = config.use_bidirectional_attention == "all"
    if currently == enabled:
        return
    if enabled:
        config.sliding_window = config.sliding_window // 2 + 1
    else:
        config.sliding_window = (config.sliding_window - 1) * 2
    config.use_bidirectional_attention = "all" if enabled else None
    config.is_causal = not enabled
    for module in model.modules():
        if module.__class__.__name__.endswith("TextAttention"):
            module.is_causal = not enabled
            if module.sliding_window is not None:
                module.sliding_window = config.sliding_window


def model_classes(path: str | Path):
    if AutoConfig.from_pretrained(path).model_type == "gemma4_unified":
        return Gemma4UnifiedTextConfig, Gemma4UnifiedTextModel
    return Gemma4TextConfig, Gemma4TextModel


def load_backbone(
    path: str | Path,
    *,
    bidirectional: bool = True,
    ple_on_cpu: bool | None = None,
    quant4: bool = False,
    device: str | None = None,
    dtype: torch.dtype = torch.bfloat16,
) -> nn.Module:
    """ple_on_cpu (default: only on CUDA) keeps the large per-layer embedding table in CPU memory, which saves
    GPU memory on a 16 GB card; on Apple silicon CPU and GPU share memory, so it would only add copies."""
    device = device or DEVICE
    if ple_on_cpu is None:  # only needed on small cards (the RTX 4080 has 16 GB; an A100 holds everything)
        ple_on_cpu = device == "cuda" and torch.cuda.get_device_properties(0).total_memory < 24 * 2**30
    if quant4 and device != "cuda":
        raise ValueError("quant4 (4-bit NF4 via bitsandbytes) needs an NVIDIA GPU")
    config_cls, model_cls = model_classes(path)
    config = config_cls.from_pretrained(path)
    kwargs = {"config": config, "key_mapping": {CHECKPOINT_PREFIX: ""}, "dtype": dtype}
    if quant4:
        kwargs["quantization_config"] = BitsAndBytesConfig(
            load_in_4bit=True, bnb_4bit_quant_type="nf4", bnb_4bit_compute_dtype=torch.bfloat16, bnb_4bit_use_double_quant=True
        )
        kwargs["device_map"] = {"": 0}
    else:
        kwargs["device_map"] = {"": "cpu"}
    # the checkpoint also holds the vision (and audio) towers; skipping them is expected
    verbosity = hf_logging.get_verbosity()
    hf_logging.set_verbosity_error()
    try:
        model = model_cls.from_pretrained(path, **kwargs)
    finally:
        hf_logging.set_verbosity(verbosity)
    model.eval()
    if not quant4:
        target = torch.device(device)
        for name, child in model.named_children():
            if ple_on_cpu and name == "embed_tokens_per_layer":
                continue
            child.to(target)
        if ple_on_cpu and getattr(model, "embed_tokens_per_layer", None) is not None:
            model.embed_tokens_per_layer = CpuEmbedding(model.embed_tokens_per_layer, target)
    set_bidirectional(model, bidirectional)
    return model


def load_tokenizer(path: str | Path):
    return AutoTokenizer.from_pretrained(path)
