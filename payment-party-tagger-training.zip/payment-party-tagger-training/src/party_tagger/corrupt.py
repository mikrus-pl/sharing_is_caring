"""Damage generated fields in the ways real flattened data gets damaged, keeping every character's label exact.

Each operation edits a list of [char, label, component, word_continues] cells; labels travel with the characters,
so the gold segmentation stays correct after the damage.
"""

from __future__ import annotations

import random
import string

from party_tagger.swiftgen import Example

NAME_ADDRESS = {"NAME_PERSON", "NAME_ORG", "STREET", "BUILDING", "UNIT", "POSTCODE", "TOWN", "REGION", "COUNTRY", "PO_BOX"}
JUNK = ["???", "...", "XXX", "N/A", "-----", "NOTPROVIDED", "//", "#", "0000", "TBC", "SEE ABOVE", "UNKNOWN", "NIL", "*", "==",
        "%@#$^$#", "@@", "***", "~~", "$$$", "^^^", "<>", "(?)"]
ODD_SEPARATORS = [" , ", ",,", " - ", " / ", "  ", ";", " // ", "...", " | ", ", ,", "-"]
ACCENTS = {"A": "ÁÄÅĄ", "E": "ÉËĘ", "O": "ÓÖØ", "U": "ÜÚ", "C": "ÇČĆ", "S": "ŠŚ", "Z": "ŽŻŹ", "N": "ÑŃ", "L": "Ł", "I": "Í", "R": "Ř"}

Cell = list  # [char, label, comp, continues]


def to_cells(ex: Example) -> list[Cell]:
    joins = dict(ex.joins)
    return [[ch, lbl, comp, joins.get(i)] for i, (ch, lbl, comp) in enumerate(zip(ex.text, ex.char_labels, ex.char_comp))]


def to_example(cells: list[Cell], meta: dict) -> Example:
    cells = _cleanup(cells)
    return Example(
        text="".join(c[0] for c in cells),
        char_labels=[c[1] for c in cells],
        char_comp=[c[2] for c in cells],
        joins=[(i, bool(c[3])) for i, c in enumerate(cells) if c[0] == "\n"],
        meta=meta,
    )


def _cleanup(cells: list[Cell]) -> list[Cell]:
    """No spaces around line breaks, no empty lines, nothing blank at the ends."""
    out: list[Cell] = []
    for c in cells:
        if c[0] == "\n":
            while out and out[-1][0] == " ":
                out.pop()
            if not out or out[-1][0] == "\n":
                continue
        elif c[0] == " " and (not out or out[-1][0] in " \n"):
            if out and out[-1][0] == " ":
                out.append(c)  # keep deliberate double spaces inside a line
            continue
        out.append(c)
    while out and out[-1][0] in " \n":
        out.pop()
    for i, c in enumerate(out):
        if c[0] != "\n":
            continue
        if c[3]:  # still a word split by the line break only with the same word's letters on both sides
            c[3] = (0 < i < len(out) - 1 and out[i - 1][0].isalnum() and out[i + 1][0].isalnum()
                    and out[i - 1][2] == out[i + 1][2] == c[2] >= 0)
        if not c[3]:
            c[1], c[2] = "O", -1
    return out


def _new_comp(cells: list[Cell]) -> int:
    return max([c[2] for c in cells] + [0]) + 1


def _lines(cells: list[Cell]) -> int:
    return 1 + sum(c[0] == "\n" for c in cells)


def _line_len_at(cells: list[Cell], i: int) -> int:
    s = i
    while s > 0 and cells[s - 1][0] != "\n":
        s -= 1
    e = i
    while e < len(cells) and cells[e][0] != "\n":
        e += 1
    return e - s


# ---------------------------------------------------------------- operations (return True when applied)

def drop_space_between(cells, rng):
    """'KOWALSKI UL.' -> 'KOWALSKIUL.': the space between two parts disappears."""
    idx = [i for i in range(1, len(cells) - 1) if cells[i][0] == " " and cells[i][1] == "O"
           and cells[i - 1][0] not in " \n" and cells[i + 1][0] not in " \n" and cells[i - 1][2] != cells[i + 1][2]]
    if not idx:
        return False
    del cells[rng.choice(idx)]
    return True


def drop_space_inside(cells, rng):
    """'UL. MARSZALKOWSKA' -> 'UL.MARSZALKOWSKA'."""
    idx = [i for i in range(1, len(cells) - 1) if cells[i][0] == " " and cells[i][2] >= 0
           and cells[i - 1][2] == cells[i][2] == cells[i + 1][2]]
    if not idx:
        return False
    del cells[rng.choice(idx)]
    return True


def odd_separator(cells, rng):
    idx = [i for i, c in enumerate(cells) if c[0] == " " and c[1] == "O"]
    if not idx:
        return False
    i = rng.choice(idx)
    cells[i:i + 1] = [[ch, "O", -1, None] for ch in rng.choice(ODD_SEPARATORS)]
    return True


def typo(cells, rng):
    idx = [i for i, c in enumerate(cells) if c[0].isalpha() and c[1] in NAME_ADDRESS]
    if not idx:
        return False
    i = rng.choice(idx)
    kind = rng.random()
    if kind < 0.35:
        cells[i][0] = rng.choice(string.ascii_uppercase)
    elif kind < 0.6:
        del cells[i]
    elif kind < 0.8:
        cells.insert(i, list(cells[i]))
    elif i + 1 < len(cells) and cells[i + 1][0].isalpha() and cells[i + 1][2] == cells[i][2]:
        cells[i][0], cells[i + 1][0] = cells[i + 1][0], cells[i][0]
    else:
        return False
    return True


def change_case(cells, rng):
    kind = rng.random()
    if kind < 0.5:
        for c in cells:
            c[0] = c[0].lower()
    elif kind < 0.8:
        start = True
        for c in cells:
            c[0] = c[0].upper() if start else c[0].lower()
            start = not c[0].isalnum()
    else:  # one line in lower case
        n = rng.randrange(_lines(cells))
        line = 0
        for c in cells:
            if c[0] == "\n":
                line += 1
            elif line == n:
                c[0] = c[0].lower()
    return True


def accents(cells, rng):
    idx = [i for i, c in enumerate(cells) if c[0].upper() in ACCENTS and c[1] in NAME_ADDRESS]
    if not idx:
        return False
    for i in rng.sample(idx, min(len(idx), rng.randint(1, 4))):
        ch = cells[i][0]
        repl = rng.choice(ACCENTS[ch.upper()])
        cells[i][0] = repl if ch.isupper() else repl.lower()
    return True


def insert_junk(cells, rng):
    """Garbage between parts, or inside a multi-word name or address ("ALPHA ### CORPORATE"): it must not change the
    labels of the words around it."""
    between = [i for i, c in enumerate(cells) if c[0] == " " and c[1] == "O"] + [len(cells)]
    inside = [i for i, c in enumerate(cells) if c[0] == " " and c[1] in NAME_ADDRESS]
    i = rng.choice(inside) if inside and rng.random() < 0.4 else rng.choice(between)
    if i < len(cells) and cells[i][1] != "O":  # the words after the junk become a separate part with the same label
        old, new = cells[i][2], _new_comp(cells)
        for c in cells[i + 1:]:
            if c[2] == old:
                c[2] = new
        cells[i] = [" ", "O", -1, None]
    comp = _new_comp(cells)
    junk = [[ch, "NOISE", comp, None] for ch in rng.choice(JUNK)]
    if i < len(cells):
        cells[i:i + 1] = [[" ", "O", -1, None]] + junk + [[" ", "O", -1, None]]  # replaces the space: no double spaces
    else:
        cells += [[" ", "O", -1, None]] + junk
    return True


def duplicate_part(cells, rng):
    comps = sorted({c[2] for c in cells if c[1] in NAME_ADDRESS and c[2] >= 0})
    if not comps:
        return False
    comp = rng.choice(comps)
    idx = [i for i, c in enumerate(cells) if c[2] == comp]
    copy_id = _new_comp(cells)
    copy = []
    for c in cells[idx[0]: idx[-1] + 1]:
        if c[0] == "\n" and c[3]:
            continue  # a word split by a line break is copied whole
        if c[0] == "\n" or c[1] == "O":
            copy.append([" " if c[0] == "\n" else c[0], "O", -1, None])
        else:
            copy.append([c[0], c[1], copy_id, None])
    end = idx[-1] + 1
    cells[end:end] = [[" ", "O", -1, None]] + copy
    return True


def random_line_break(cells, rng):
    if _lines(cells) >= 5:
        return False
    idx = [i for i in range(2, len(cells) - 2) if cells[i][0] != "\n" and cells[i - 1][0] != "\n" and cells[i + 1][0] != "\n"]
    if not idx:
        return False
    i = rng.choice(idx)
    if cells[i][0] == " ":
        cells[i] = ["\n", "O", -1, False]
    elif cells[i - 1][0].isalnum() and cells[i][0].isalnum() and cells[i - 1][2] == cells[i][2] >= 0:
        cells.insert(i, ["\n", cells[i][1], cells[i][2], True])  # a word split by the line break
    else:
        return False
    return True


def truncate(cells, rng):
    if len(cells) < 30:
        return False
    cut = rng.randint(int(len(cells) * 0.6), len(cells) - 3)
    del cells[cut:]
    return True


def glue_lines(cells, rng):
    idx = [i for i, c in enumerate(cells) if c[0] == "\n" and not c[3] and _line_len_at(cells, i - 1) + _line_len_at(cells, i + 1) <= 44]
    if not idx:
        return False
    i = rng.choice(idx)
    if rng.random() < 0.5:
        del cells[i]  # 'WARSZAWA\nPOLAND' -> 'WARSZAWAPOLAND'
    else:
        cells[i] = [" ", "O", -1, None]
    return True


def damage_prefix(cells, rng):
    idx = [i for i, c in enumerate(cells) if c[1] == "LINE_PREFIX" and c[0] == "/"]
    if not idx:
        return False
    for i in sorted(idx, reverse=True):
        if rng.random() < 0.7:
            cells[i:i + 1] = [[ch, "LINE_PREFIX", cells[i][2], None] for ch in rng.choice([" /", ")", ".", "-", ": ", " "])]
    return True


def account_variant(cells, rng):
    idx = [i for i, c in enumerate(cells) if c[1] == "ACCOUNT"]
    if not idx or cells[idx[0]][0] != "/":
        return False
    first, last, comp = idx[0], idx[-1], cells[idx[0]][2]
    kind = rng.random()
    if kind < 0.3:
        del cells[first]
    elif kind < 0.55:
        cells[first:first + 1] = [[ch, "ACCOUNT", comp, None] for ch in rng.choice(["IBAN ", "IBAN: ", "ACC ", "A/C "])]
    elif kind < 0.8:  # spaces every 4 characters, as printed IBANs
        body = [c for c in cells[first + 1: last + 1]]
        spaced = []
        for k, c in enumerate(body):
            if k and k % 4 == 0:
                spaced.append([" ", "ACCOUNT", comp, None])
            spaced.append(c)
        cells[first + 1: last + 1] = spaced
    else:  # account at the end instead of the first line
        block = cells[first: last + 1]
        rest = cells[last + 2:] if last + 1 < len(cells) and cells[last + 1][0] == "\n" else cells[last + 1:]
        cells[:] = rest + [["\n", "O", -1, False]] + block
    return True


OPERATIONS = {
    "brak spacji między częściami": (drop_space_between, 12),
    "brak spacji w części": (drop_space_inside, 6),
    "dziwny separator": (odd_separator, 10),
    "literówka": (typo, 12),
    "wielkość liter": (change_case, 6),
    "znaki diakrytyczne": (accents, 6),
    "śmieci": (insert_junk, 10),
    "zdublowany fragment": (duplicate_part, 5),
    "losowe łamanie linii": (random_line_break, 10),
    "ucięcie": (truncate, 7),
    "sklejone linie": (glue_lines, 6),
    "uszkodzony prefiks 1/2/3": (damage_prefix, 4),
    "inny zapis konta": (account_variant, 6),
}


def corrupt(ex: Example, rng: random.Random, n_ops: int) -> Example:
    cells = to_cells(ex)
    names, weights = zip(*[(k, w) for k, (_, w) in OPERATIONS.items()])
    applied = []
    tries = 0
    while len(applied) < n_ops and tries < 4 * n_ops + 4:
        tries += 1
        name = rng.choices(names, weights=weights)[0]
        if name in applied:
            continue
        if OPERATIONS[name][0](cells, rng):
            applied.append(name)
    meta = dict(ex.meta)
    meta["corruptions"] = applied
    if "ucięcie" in applied:
        meta["truncated"] = True
    return to_example(cells, meta)
