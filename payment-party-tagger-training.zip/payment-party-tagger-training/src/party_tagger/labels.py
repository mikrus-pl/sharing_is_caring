"""Label set for SWIFT party-field segmentation."""

LABELS = [
    "O",  # separator / whitespace between parts
    "NAME_PERSON",
    "NAME_ORG",
    "STREET",
    "BUILDING",
    "UNIT",
    "POSTCODE",
    "TOWN",
    "REGION",
    "COUNTRY",
    "PO_BOX",
    "ACCOUNT",
    "LINE_PREFIX",
    "NOISE",  # only garbage and placeholders (%@#$, ===, NOTPROVIDED, N/A); never a real word of the party
    # added 2026-10-18 (appended so older runs and teacher files keep their column order)
    "PARTY_INTRO",  # words that introduce a party or contact: C/O, ATTN, OBO, FFC, T/A, BENEFICIARY
    "PARTY_ID",  # identifiers and contact details of the party (ISO Id / CtctDtls): TEL, VAT, BIC, DOB, passport, REF
]
LABEL2ID = {label: i for i, label in enumerate(LABELS)}

COARSE = {
    "O": "O",
    "NAME_PERSON": "NAME",
    "NAME_ORG": "NAME",
    "STREET": "ADDRESS",
    "BUILDING": "ADDRESS",
    "UNIT": "ADDRESS",
    "POSTCODE": "ADDRESS",
    "TOWN": "ADDRESS",
    "REGION": "ADDRESS",
    "COUNTRY": "ADDRESS",
    "PO_BOX": "ADDRESS",
    "ACCOUNT": "NOISE",
    "LINE_PREFIX": "NOISE",
    "NOISE": "NOISE",
    "PARTY_INTRO": "NAME",  # user rule: "who" vs "where"; everything about the party that is not its postal address -> name side
    "PARTY_ID": "NAME",
}

# ISO 20022 PostalAddress element for each address label
ISO_ELEMENT = {
    "STREET": "StrtNm",
    "BUILDING": "BldgNb",
    "UNIT": "Room",
    "POSTCODE": "PstCd",
    "TOWN": "TwnNm",
    "REGION": "CtrySubDvsn",
    "COUNTRY": "Ctry",
    "PO_BOX": "PstBx",
}

# short names used in the hand-written markup: {TOWN|WARSZAWA}
SHORT = {
    "PER": "NAME_PERSON",
    "ORG": "NAME_ORG",
    "STR": "STREET",
    "BLD": "BUILDING",
    "UNIT": "UNIT",
    "PC": "POSTCODE",
    "TOWN": "TOWN",
    "REG": "REGION",
    "CTRY": "COUNTRY",
    "POB": "PO_BOX",
    "ACC": "ACCOUNT",
    "PFX": "LINE_PREFIX",
    "NOISE": "NOISE",
    "INTRO": "PARTY_INTRO",
    "ID": "PARTY_ID",
}
