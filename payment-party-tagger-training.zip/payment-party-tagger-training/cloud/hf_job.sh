#!/usr/bin/env bash
# Entry point inside a Hugging Face Job (see CLOUD_GPU.md): unpack the package, train, evaluate, export,
# then copy the results to the bucket mounted at /out. Results are copied even when a step fails (logs included).
#
#   bash hf_job.sh <model: e4b|e2b> <profile: fast|v3> [--smoke]
set -uo pipefail
MODEL="${1:-e4b}"
PROFILE="${2:-fast}"
EXTRA="${3:-}"
STAMP="$(date +%Y%m%d-%H%M)"
OUT="/out/${MODEL}-${PROFILE}${EXTRA:+-smoke}-${STAMP}"

mkdir -p /work
python -m zipfile -e /pkg/payment-party-tagger-training.zip /work
cd /work/payment-party-tagger-training
nvidia-smi || true
python -m pip install -q -r requirements.txt
python reproduce.py --model "$MODEL" --profile "$PROFILE" $EXTRA
STATUS=$?

mkdir -p "$OUT"
cp -r runs publish "$OUT"/ 2>/dev/null || true
echo "exit status ${STATUS}; results in ${OUT}"
exit $STATUS
