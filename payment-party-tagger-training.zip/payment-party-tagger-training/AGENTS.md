# Agent guide for this package (AGENTS.md; CLAUDE.md imports this file)

This folder is the training package of **payment-party-tagger v3**: a Gemma 4 model with bidirectional attention,
LoRA and two small heads that splits a SWIFT MT party field (50K/59/50F/59F) into name (who), postal address (where)
and noise. Code: `src/party_tagger/`; pipeline: `reproduce.py`; recipe: `recipe_v3.json`.

## The user
- Speaks **Polish**; reply in Polish, simply, without jargon. They are not an ML specialist and do not know cloud tools:
  you do the technical work, they only log in, pay and approve.
- Works on a **Mac** (Apple silicon). Google Colab may or may not be available.
- Wants a working prototype quickly: prefer the shortest path that gives a real result, report after every step.

## Rules
- Ask before: downloading anything over ~1 GB (base models: E4B 16 GB, E2B 10.3 GB), any paid cloud run (state hardware,
  time, cost), uploading or publishing anything (everything stays private unless the user says otherwise), and runs
  longer than ~15 minutes.
- Never type passwords, tokens or payment data, never accept consent screens: ask the user and guide them click by click.
- Do not change the recipe, labels, data or release criteria to make a number look better.
- Keep `python -m pytest -q` green. Keep the public name `payment-party-tagger-*`.

## Which document for which request

| The user wants | Read |
|---|---|
| "train it" / "run it in the cloud" / "use Colab" | `CLOUD_GPU.md` (Hugging Face Jobs recommended, Colab through its MCP server) |
| "make it fast on my Mac" / "train on the Mac" | `MLX_MIGRATION.md` (MLX backend, step by step with parity tests) |
| "just run it here" / details of every step | `README.md` |
| how the model works | `ARCHITECTURE.md` |
| what the data is | `DATA.md` |

## Commands
```bash
python reproduce.py --dry-run                  # plan of every step, nothing is downloaded or run
python reproduce.py --model e2b --smoke        # quick end-to-end check with the smaller model
python reproduce.py --model e4b                # full reference training (needs ~32 GB of unified memory on a Mac)
python -m pytest -q                            # tests (need a downloaded base model for the tokenizer tests)
```
On this Mac the PyTorch path uses the Apple GPU (MPS) automatically; `TAGGER_DEVICE=cpu` forces the CPU.
