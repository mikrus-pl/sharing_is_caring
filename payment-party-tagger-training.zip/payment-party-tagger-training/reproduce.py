"""Reproduce the training of payment-party-tagger v3 from scratch: NVIDIA GPU (Colab A100), Apple silicon (MPS) or CPU.

    python reproduce.py                  # all steps, base model Gemma 4 E4B (the reference v3)
    python reproduce.py --model e2b      # the same recipe on the smaller Gemma 4 E2B (not trained yet, results unknown)
    python reproduce.py --profile fast   # big GPU (A100/H100): same effective batch, no gradient checkpointing
    python reproduce.py --smoke          # 5-10 minute check of the whole pipeline on a tiny subset (results meaningless)
    python reproduce.py --dry-run        # show what every step would do; downloads and runs nothing
    python reproduce.py --steps data     # chosen steps only: env,model,data,train,evaluate,calibrate,export,gate,compare

Every step is skipped when its result already exists (--force redoes it), so an interrupted session can simply be
started again. Logs: <run>/reproduce.log.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import importlib.metadata
import json
import os
import platform
import shutil
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
RECIPE = json.loads((HERE / "recipe_v3.json").read_text(encoding="utf-8"))
STEPS = ["env", "model", "data", "train", "evaluate", "calibrate", "export", "gate", "compare"]
DATA = HERE / "data" / "generated"
SUMS = HERE / "data" / "SHA256SUMS"
DRY = False


# ---------------------------------------------------------------- helpers

def say(msg: str, log: Path | None = None) -> None:
    line = f"[{time.strftime('%H:%M:%S')}] {msg}"
    print(line, flush=True)
    if log:
        with open(log, "a", encoding="utf-8") as f:
            f.write(line + "\n")


def child_env(extra: dict | None = None) -> dict:
    env = dict(os.environ, PYTHONIOENCODING="utf-8", PYTHONPATH=str(HERE / "src"))
    if platform.system() == "Darwin":
        env.setdefault("PYTORCH_ENABLE_MPS_FALLBACK", "1")  # an op missing on MPS falls back to CPU instead of failing
    env.update(extra or {})
    return env


def run(cmd: list, log: Path, env: dict | None = None, allow_fail: bool = False) -> int:
    cmd = [str(c) for c in cmd]
    if DRY:
        say("[dry-run] would run: " + " ".join(cmd), log)
        return 0
    say("$ " + " ".join(cmd), log)
    with open(log, "a", encoding="utf-8") as f:
        proc = subprocess.Popen(cmd, cwd=HERE, env=env or child_env(), stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                text=True, encoding="utf-8", errors="replace")
        for line in proc.stdout:
            sys.stdout.write(line)
            f.write(line)
        code = proc.wait()
    if code and not allow_fail:
        raise SystemExit(f"step failed (exit {code}): {' '.join(cmd[1:3])}; see {log}")
    return code


def digest(path: Path) -> str:
    """sha256 of a text file with Windows line endings made Linux ones (the same data on every system)."""
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for line in f:
            h.update(line.replace(b"\r\n", b"\n"))
    return h.hexdigest()


def expected_sums() -> dict[str, str]:
    out = {}
    for line in SUMS.read_text(encoding="utf-8").splitlines():
        if line.strip():
            value, name = line.split()
            out[name] = value
    return out


def model_spec(args) -> dict:
    return RECIPE["models"][args.model]


# ---------------------------------------------------------------- steps

def step_env(args, log):
    import torch

    sys.path.insert(0, str(HERE / "src"))
    from party_tagger.device import DEVICE, device_name

    spec = model_spec(args)
    say(f"base model: {args.model} = {spec['hub']} ({spec['status']})", log)
    say(f"Python {platform.python_version()} on {platform.system()} {platform.machine()}", log)
    say(f"torch {torch.__version__}, device: {DEVICE} = {device_name()}", log)
    if DEVICE == "cuda":
        gib = torch.cuda.get_device_properties(0).total_memory / 2**30
        say(f"GPU memory {gib:.0f} GiB" + ("  (profile 'fast' recommended)" if gib >= 40 and args.profile != "fast" else ""), log)
    elif DEVICE == "mps":
        try:
            gib = int(subprocess.check_output(["sysctl", "-n", "hw.memsize"]).strip()) / 2**30
            need = spec["mac_min_memory_gib"]
            warn = f"  WARNING: training {args.model.upper()} needs about {need} GiB" + (
                "; try --model e2b" if args.model == "e4b" else "") if gib < need else ""
            say(f"unified memory {gib:.0f} GiB{warn}", log)
        except Exception:
            pass
    else:
        say("WARNING: no GPU found; training on CPU would take days. Use --smoke to check the pipeline only.", log)
    pinned = {}
    for line in (HERE / "requirements.txt").read_text(encoding="utf-8").splitlines():
        line = line.split("#")[0].strip()
        if "==" in line:
            name, version = line.split("==")
            pinned[name.strip()] = version.strip()
    for name, version in pinned.items():
        try:
            have = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            raise SystemExit(f"missing package {name}: pip install -r requirements.txt")
        if have != version:
            say(f"note: {name} {have} installed, recipe used {version}" + (" (regenerated data may differ)" if name == "faker" else ""), log)


def step_model(args, log):
    spec = model_spec(args)
    target = HERE / args.model_dir
    if (target / "config.json").exists() and any(target.glob("*.safetensors")) and not args.force:
        say(f"base model present: {target}", log)
        return
    if DRY:
        say(f"[dry-run] would download {spec['hub']} (~{spec['download_gb']} GB) to {target}", log)
        return
    from huggingface_hub import snapshot_download

    say(f"downloading {spec['hub']} (~{spec['download_gb']} GB) to {target}", log)
    snapshot_download(spec["hub"], local_dir=target)


def step_data(args, log):
    sums = expected_sums()
    if DRY:
        missing = [n for n in sums if not (DATA / n).exists()]
        say(f"[dry-run] would {'regenerate' if args.regenerate_data else 'unpack'} data and check {len(sums)} files "
            f"against SHA256SUMS ({len(missing)} not unpacked yet)", log)
        return
    DATA.mkdir(parents=True, exist_ok=True)
    if args.regenerate_data:
        env = child_env({"PYTHONHASHSEED": "0"})
        for script in ("make_data.py", "make_hard_data.py", "make_big_data.py"):
            run([sys.executable, HERE / "scripts" / script, "--out", DATA], log, env)
    bad = []
    for name, value in sums.items():
        path = DATA / name
        if not path.exists():
            with gzip.open(DATA / f"{name}.gz", "rb") as src, open(path, "wb") as dst:
                shutil.copyfileobj(src, dst)
        if digest(path) != value:
            bad.append(name)
    if bad and args.regenerate_data:
        say(f"regenerated files differ from the recipe on this system: {bad}; using the packaged files instead", log)
        for name in bad:
            with gzip.open(DATA / f"{name}.gz", "rb") as src, open(DATA / name, "wb") as dst:
                shutil.copyfileobj(src, dst)
        bad = [n for n in bad if digest(DATA / n) != sums[n]]
    if bad:
        raise SystemExit(f"data does not match SHA256SUMS: {bad}")
    say(f"data OK: {len(sums)} files match SHA256SUMS" + (" (regenerated here, identical)" if args.regenerate_data else ""), log)


def step_train(args, log):
    run_dir = HERE / args.run
    if (run_dir / "meta.json").exists() and (run_dir / "adapter").exists() and not args.force:
        say(f"trained run present: {run_dir}", log)
        return
    prof = dict(RECIPE["train"], **RECIPE["profiles"][args.profile])
    cmd = [sys.executable, HERE / "scripts" / "train.py", "--model", args.model_dir, "--out", args.run,
           "--train-files", *RECIPE["data"]["train_files"], "--lora-r", prof["lora_r"], "--bs", prof["bs"],
           "--grad-accum", prof["grad_accum"], "--epochs", prof["epochs"], "--lr", prof["lr"], "--head-lr", prof["head_lr"],
           "--join-weight", prof["join_weight"], "--seed", prof["seed"]]
    if not prof["grad_ckpt"]:
        cmd.append("--no-grad-ckpt")
    if args.smoke:
        cmd += ["--max-train", 256, "--max-steps", 20]
    run(cmd, log)


def step_evaluate(args, log):
    run_dir = HERE / args.run
    if (run_dir / "metrics.json").exists() and not args.force:
        say("evaluation present", log)
        return
    sets = ["handcrafted"] if args.smoke else RECIPE["data"]["eval_sets"]
    calib = ["calib.jsonl"] if args.smoke else RECIPE["data"]["calib_files"]
    run([sys.executable, HERE / "scripts" / "evaluate.py", "--run", args.run, "--calib-files", *calib, "--sets", *sets], log)


def step_calibrate(args, log):
    run_dir = HERE / args.run
    if (run_dir / "routing_metrics.json").exists() and not args.force:
        say("routing calibration present", log)
        return
    sets = ["handcrafted"] if args.smoke else RECIPE["data"]["eval_sets"]
    calib = ["calib.jsonl"] if args.smoke else RECIPE["data"]["calib_files"]
    run([sys.executable, HERE / "scripts" / "calibrate_routing.py", "--run", args.run, "--calib-files", *calib,
         "--sets", *sets], log)


def export_dir(args) -> str:
    return f"publish/{model_spec(args)['name']}" + ("_smoke" if args.smoke else "")


def step_export(args, log):
    out = HERE / export_dir(args)
    if (out / "README.md").exists() and not args.force:
        say(f"export present: {out}", log)
        return
    run([sys.executable, HERE / "scripts" / "export_hf.py", "--run", args.run, "--repo", model_spec(args)["hub_repo"],
         "--out", export_dir(args), "--base-local", HERE / args.model_dir] + (["--draft"] if args.smoke else []), log)


def step_gate(args, log):
    if args.smoke:
        say("release gate skipped in --smoke (it needs all five test sets)", log)
        return
    code = run([sys.executable, HERE / "scripts" / "check_release.py", "--run", args.run, "--export", export_dir(args)],
               log, allow_fail=True)
    if not DRY:
        say("release gate: " + ("PASSED" if code == 0 else "NOT PASSED"), log)


def step_compare(args, log):
    run_dir = HERE / args.run
    if DRY:
        say(f"[dry-run] would compare {run_dir / 'metrics.json'} with expected/metrics.json (E4B v3)", log)
        return
    own_reference = model_spec(args)["has_reference"]
    new = json.loads((run_dir / "metrics.json").read_text(encoding="utf-8"))["sets"]
    ref = json.loads((HERE / "expected" / "metrics.json").read_text(encoding="utf-8"))["sets"]
    tol = RECIPE["tolerance_pp"]
    rows = [f"| Set | Metric | Reference v3 (E4B) | This run ({args.model.upper()}) | Difference |", "|---|---|---|---|---|"]
    worst = 0.0
    for name in RECIPE["data"]["eval_sets"]:
        if name not in new:
            continue
        for metric in ("field_exact_coarse", "field_exact_fine", "char_accuracy_fine"):
            a, b = ref[name][metric], new[name][metric]
            diff = 100 * (b - a)
            if name != "handcrafted" and metric == "field_exact_coarse":
                worst = min(worst, diff)
            rows.append(f"| {name} | {metric} | {100 * a:.1f}% | {100 * b:.1f}% | {diff:+.1f} pp |")
    if args.smoke:
        verdict = "smoke run: numbers are meaningless, only the pipeline was checked"
    elif not own_reference:
        verdict = (f"{args.model.upper()} has no reference of its own yet; the E4B numbers are for orientation "
                   f"(largest drop on a big set: {worst:+.1f} pp). The release gate decides whether it is good enough")
    else:
        verdict = ("matches the reference" if worst >= -tol else
                   f"WORSE than the reference by more than {tol} pp on at least one set")
    text = "\n".join(["# Comparison with the reference v3", "", *rows, "", f"Verdict: {verdict}.", ""])
    (run_dir / "compare.md").write_text(text, encoding="utf-8")
    print(text)
    say(f"comparison written to {run_dir / 'compare.md'}", log)


def main():
    global DRY
    for stream in (sys.stdout, sys.stderr):  # Windows consoles (cp1250) cannot print progress-bar characters
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8", errors="replace")
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--steps", default=",".join(STEPS), help="comma-separated subset of: " + ",".join(STEPS))
    ap.add_argument("--model", choices=sorted(RECIPE["models"]), default=RECIPE["default_model"],
                    help="base model: e4b (reference v3) or e2b (smaller, not trained yet)")
    ap.add_argument("--profile", choices=sorted(RECIPE["profiles"]), default="v3")
    ap.add_argument("--run", default=None, help="output folder (default from the recipe; runs/smoke_<model> with --smoke)")
    ap.add_argument("--model-dir", default=None, help="where the base model is or will be downloaded (default from the recipe)")
    ap.add_argument("--regenerate-data", action="store_true", help="rebuild the data with the generator instead of unpacking it")
    ap.add_argument("--smoke", action="store_true")
    ap.add_argument("--dry-run", action="store_true", help="print what each step would do; download and run nothing")
    ap.add_argument("--force", action="store_true", help="redo steps whose results exist")
    args = ap.parse_args()
    DRY = args.dry_run
    spec = model_spec(args)
    args.model_dir = args.model_dir or spec["dir"]
    args.run = args.run or (f"runs/smoke_{args.model}" if args.smoke else spec["run"])
    (HERE / args.run).mkdir(parents=True, exist_ok=True)
    log = HERE / args.run / "reproduce.log"
    chosen = [s.strip() for s in args.steps.split(",") if s.strip()]
    unknown = [s for s in chosen if s not in STEPS]
    if unknown:
        raise SystemExit(f"unknown steps: {unknown}")
    t0 = time.time()
    for name in STEPS:
        if name in chosen:
            say(f"=== {name}", log)
            globals()[f"step_{name}"](args, log)
    say(f"done in {(time.time() - t0) / 60:.1f} min", log)


if __name__ == "__main__":
    main()
