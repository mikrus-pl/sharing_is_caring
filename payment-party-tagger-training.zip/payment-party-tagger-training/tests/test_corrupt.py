import random

from party_tagger.corrupt import OPERATIONS, corrupt
from party_tagger.labels import LABELS
from party_tagger.swiftgen import EXTRA_LOCALES, TRAIN_LOCALES, generate


def test_hard_generation_and_corruptions_keep_labels_consistent():
    rng = random.Random(0)
    examples = generate(1500, seed=3, locales=TRAIN_LOCALES + EXTRA_LOCALES, hard=True)
    used = set()
    for ex in examples:
        bad = corrupt(ex, rng, rng.choice([1, 2, 3]))
        used.update(bad.meta["corruptions"])
        assert len(bad.text) == len(bad.char_labels) == len(bad.char_comp)
        assert set(bad.char_labels) <= set(LABELS)
        assert bad.text == bad.text.strip() and "\n\n" not in bad.text
        assert [i for i, ch in enumerate(bad.text) if ch == "\n"] == [i for i, _ in bad.joins]
        for i, cont in bad.joins:
            if cont:
                assert bad.text[i - 1].isalnum() and bad.text[i + 1].isalnum()
                assert bad.char_comp[i - 1] == bad.char_comp[i + 1] >= 0
        for i, (lbl, comp) in enumerate(zip(bad.char_labels, bad.char_comp)):
            assert (lbl == "O") == (comp == -1), (bad.text, i)
    assert used == set(OPERATIONS), set(OPERATIONS) - used


def test_generation_is_deterministic_for_a_seed():
    # Faker also depends on PYTHONHASHSEED, so the data scripts fix it (see scripts/make_data.py)
    a = generate(200, seed=11, locales=TRAIN_LOCALES + EXTRA_LOCALES, hard=True)
    b = generate(200, seed=11, locales=TRAIN_LOCALES + EXTRA_LOCALES, hard=True)
    assert [e.text for e in a] == [e.text for e in b]
