from pathlib import Path

from party_tagger.labels import LABELS
from party_tagger.swiftgen import HELDOUT_LOCALES, LINE_WIDTH, MAX_LINES, PLACEHOLDERS, TRAIN_LOCALES, generate, load_markup_file, parse_markup

HANDCRAFTED = Path(__file__).parents[1] / "data" / "handcrafted.txt"


def test_generated_examples_are_consistent():
    examples = generate(2000, seed=1, locales=TRAIN_LOCALES + HELDOUT_LOCALES)
    styles = set()
    for ex in examples:
        styles.add(ex.meta["style"])
        assert len(ex.text) == len(ex.char_labels) == len(ex.char_comp)
        assert set(ex.char_labels) <= set(LABELS)
        lines = ex.text.split("\n")
        has_account = lines[0].startswith("/") and all(lbl == "ACCOUNT" for lbl in ex.char_labels[: len(lines[0])])
        assert len(lines) <= MAX_LINES + (1 if has_account else 0)
        for line in lines:
            assert 0 < len(line) <= LINE_WIDTH, repr(ex.text)
        assert [i for i, ch in enumerate(ex.text) if ch == "\n"] == [i for i, _ in ex.joins]
        for span in ex.spans():
            assert span["text"].strip() == span["text"]
    assert styles == {"natural", "glued_hard", "glued_word", "f_format", "name_then_glued"}


def test_some_line_breaks_split_words():
    examples = generate(1000, seed=2, locales=TRAIN_LOCALES)
    splits = [(ex, i) for ex in examples for i, cont in ex.joins if cont]
    assert splits, "hard-wrapped styles must produce mid-word line breaks"
    for ex, i in splits:
        assert ex.text[i - 1].isalnum() and ex.text[i + 1].isalnum()
        assert ex.char_comp[i - 1] == ex.char_comp[i + 1] >= 0


def test_markup():
    ex = parse_markup("{ORG|ACME LTD}\n{STR|MAIN} {BLD|5} {TOWN|WARS¦\nZAWA}")
    assert ex.text == "ACME LTD\nMAIN 5 WARS\nZAWA"
    assert ex.joins == [(8, False), (20, True)]
    assert [s["label"] for s in ex.spans()] == ["NAME_ORG", "STREET", "BUILDING", "TOWN"]


def test_markup_line_break_inside_component_without_split():
    ex = parse_markup("{ORG|ANADOLU TICARET\nA.S.} {BLD|5}")
    assert ex.joins == [(15, False)]
    assert ex.char_labels[15] == "O"


def test_handcrafted_file_respects_swift_limits():
    examples = load_markup_file(HANDCRAFTED)
    assert len(examples) >= 20
    for ex in examples:
        assert "{" not in ex.text and "¦" not in ex.text
        for line in ex.text.split("\n"):
            assert 0 < len(line) <= LINE_WIDTH, repr(line)


def test_building_ranges_and_flats_follow_the_user_rule():
    import re

    examples = generate(4000, seed=9, locales=TRAIN_LOCALES)
    ranges = flats = 0
    for ex in examples:
        for s in ex.spans():
            line_end = ex.text.find("\n", s["start"])
            line_start = ex.text.rfind("\n", 0, s["start"]) + 1
            cut = s["end"] == (line_end if line_end >= 0 else len(ex.text)) and (line_end if line_end >= 0 else len(ex.text)) - line_start == LINE_WIDTH
            if cut:
                continue  # a range cut by the 35-character limit ("23/24" -> "23/2") stays a building number
            if s["label"] == "BUILDING" and re.fullmatch(r"\d+([/-]\d+)+", s["text"]) and ex.meta["locale"] not in ("cs_CZ",):
                nums = [int(x) for x in re.split(r"[/-]", s["text"])]
                assert nums == sorted(nums) and nums[-1] - nums[0] <= 6, s["text"]  # a range: ascending and close
                ranges += 1
            if s["label"] == "UNIT" and s["start"] > 0 and ex.text[s["start"] - 1] == "/":
                bstart = ex.text.rfind(" ", 0, s["start"] - 1) + 1
                building = ex.text[bstart:s["start"] - 1]
                if building.isdigit() and s["text"].isdigit():
                    assert not (int(building) < int(s["text"]) <= int(building) + 6), ex.text  # never reads as a range
                    flats += 1
    assert ranges > 30 and flats > 30


def test_59f_has_only_codes_1_2_3():
    for ex in generate(2000, seed=10, locales=TRAIN_LOCALES):
        if ex.meta.get("tag") == "59F":
            codes = {line[:2] for line in ex.text.split("\n") if len(line) > 1 and line[1] == "/" and line[0].isdigit()}
            assert codes <= {"1/", "2/", "3/"}, ex.text


def test_noise_is_only_garbage_and_second_parties_have_markers():
    """User rules: NOISE never holds a real word; C/O, ATTN, OBO, FFC, T/A are followed by a party's name."""
    from party_tagger.routing import MARKERS, _PLACEHOLDER, _REPEATED

    examples = generate(3000, seed=11, locales=TRAIN_LOCALES, hard=True)
    roles = set()
    for ex in examples:
        spans = ex.spans()
        for n, s in enumerate(spans):
            if s["label"] == "NOISE":
                ok = False
                for t in (s["text"].replace(chr(10), ""), s["text"].replace(chr(10), " ")):  # split or broken by a line break
                    ok |= not any(c.isalnum() for c in t) or bool(_PLACEHOLDER.fullmatch(t) or _REPEATED.fullmatch(t))
                    ok |= any(t and (ph.startswith(t) or ph.endswith(t)) for ph in PLACEHOLDERS)  # cut at 35 chars
                assert ok, s["text"]
            if s["label"] == "PARTY_INTRO":
                role = next((r for r, rx in MARKERS if rx.fullmatch(s["text"])), None)
                if role:
                    roles.add(role)
                    nxt = next((x for x in spans[n + 1:] if x["label"] != "LINE_PREFIX"), None)
                    cut = nxt is None and ex.meta.get("truncated")
                    assert cut or nxt["label"] in ("NAME_PERSON", "NAME_ORG"), ex.text
    assert roles == {"care_of", "attention", "on_behalf_of", "further_credit", "trading_as"}
    assert sum("second_party" in ex.meta for ex in examples) > 600
