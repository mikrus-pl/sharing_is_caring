from pathlib import Path

import pytest
import torch

from party_tagger.labels import LABEL2ID, LABELS
from party_tagger.routing import calibrate_thresholds, decide, routing_metrics
from party_tagger.swiftgen import load_markup_file, parse_markup
from tests.test_decode import MODEL, perfect_output

ROOT = Path(__file__).parents[1]
pytestmark = pytest.mark.skipif(not (MODEL / "tokenizer.json").exists(), reason="tokenizer not downloaded")


@pytest.fixture(scope="module")
def tokenizer():
    from party_tagger.backbone import load_tokenizer

    return load_tokenizer(MODEL)


def test_perfect_predictions_route_every_part_to_the_right_agent(tokenizer):
    examples = load_markup_file(ROOT / "data" / "handcrafted.txt")
    outputs = [perfect_output(ex, tokenizer) for ex in examples]
    m = routing_metrics(examples, outputs)
    assert m["fields_lossless"] == 1.0 and m["fields_perfect"] == 1.0
    first = outputs[0]["routing"]
    assert first["name_agent"]["text"] == "JAN KOWALSKI TRADING SP. Z O.O. ATTN ACCOUNTS DEPT"
    assert first["name_agent"]["entities"] == [
        {"value": "JAN KOWALSKI TRADING SP. Z O.O.", "type": "organization", "role": "party"},
        {"value": "ACCOUNTS DEPT", "type": "organization", "role": "attention", "marker": "ATTN"}]
    assert first["name_agent"]["party_type"] == "organization"
    assert first["geo_agent"]["text"] == "UL. MARSZALKOWSKA 142 5 00-061 WARSZAWA POLAND"
    assert [p["value"] for p in first["ignored"]] == ["/PL61109010140000071219812874"]
    assert first["geo_agent"]["iso20022_hint"]["TwnNm"] == "WARSZAWA"


def test_uncertain_word_goes_to_both_agents(tokenizer):
    from party_tagger.data import encode_example
    from party_tagger.infer import decode

    ex = parse_markup("{PER|GEORGE WASHINGTON}\n{TOWN|WASHINGTON} {REG|DC}")
    enc = encode_example(ex, tokenizer)
    probs = torch.zeros(len(enc.input_ids), len(LABELS))
    for k, lbl in enumerate(enc.labels):
        probs[k, LABEL2ID["O"] if lbl < 0 else lbl] = 1.0
    # make the first WASHINGTON uncertain between a surname and a town
    s = ex.text.index("WASHINGTON")
    for k, (a, b) in enumerate(enc.offsets):
        if a <= s < b or s <= a < s + len("WASHINGTON"):
            probs[k] = 0
            probs[k, LABEL2ID["NAME_PERSON"]] = 0.55
            probs[k, LABEL2ID["TOWN"]] = 0.45
    joins = torch.zeros(len(enc.input_ids), 2)
    joins[:, 0] = 1
    thresholds = {"noise": 0.5, "name": 0.8, "address": 0.8}  # 55% vs 45%: neither side sure enough
    out = decode(ex.text, enc.offsets, probs, joins, LABELS, thresholds)
    word = next(u for u in out["units"] if u["start"] == s)
    assert word["send_to"] == ["name", "geo"]
    assert "WASHINGTON" in out["routing"]["name_agent"]["text"] and out["routing"]["ambiguous"]
    argmax = decode(ex.text, enc.offsets, probs, joins, LABELS, None)
    assert next(u for u in argmax["units"] if u["start"] == s)["send_to"] == ["name"]


def test_calibrated_thresholds_keep_the_promised_share():
    import random

    rng = random.Random(0)
    units = []
    for _ in range(2000):
        gold = rng.choice(["NAME", "ADDRESS", "NOISE"])
        sure = rng.betavariate(8, 1)  # mostly confident, sometimes not
        rest = (1 - sure) / 2
        p = {g: (sure if g == gold else rest) for g in ("NAME", "ADDRESS", "NOISE")}
        units.append(({"p": p}, gold))
    t = calibrate_thresholds(units, alpha=0.05)
    name_units = [u for u, g in units if g == "NAME"]
    reached = sum(decide(u["p"], t)[0] for u in name_units) / len(name_units)
    assert reached >= 0.94
    assert t["noise"] >= 0.5


def test_iban_validator():
    from party_tagger.routing import valid_iban

    assert valid_iban("/PL61109010140000071219812874")
    assert valid_iban("IBAN PL61 1090 1014 0000 0712 1981 2874")
    assert valid_iban("/DE89370400440532013000")
    assert not valid_iban("/PL61109010140000071219812875")  # wrong check digit
    assert not valid_iban("JAN KOWALSKI TRADING")


def test_clopper_pearson_certified_threshold():
    from party_tagger.metrics import certified_threshold, clopper_pearson_upper

    # 0 errors in 299 decisions is the smallest sample that certifies 1% at 95% confidence
    assert clopper_pearson_upper(0, 299) <= 0.0100 < clopper_pearson_upper(0, 298)
    conf = [1 - i / 1000 for i in range(1000)]
    correct = [i < 600 or i % 3 for i in range(1000)]  # the 600 most confident are all right
    t = certified_threshold(conf, correct, 0.01)
    accepted = [ok for c, ok in zip(conf, correct) if c >= t]
    assert len(accepted) >= 600
    assert clopper_pearson_upper(accepted.count(False), len(accepted)) <= 0.01
    assert certified_threshold(conf[:40], correct[:40], 0.05) is None  # fewer than 50 accepted


def _field(src: str):
    ex = parse_markup(src)
    return ex


def _probs(ex, tokenizer, relabel=None):
    """Token probabilities of a model that answers the gold label, or relabel(gold label) when given."""
    from party_tagger.data import IGNORE, encode_example

    enc = encode_example(ex, tokenizer)
    probs = torch.zeros(len(enc.input_ids), len(LABELS))
    for k, lbl in enumerate(enc.labels):
        name = "O" if lbl == IGNORE else LABELS[lbl]
        probs[k, LABEL2ID[relabel(name) if relabel else name]] = 1.0
    joins = torch.zeros(len(enc.input_ids), 2)
    joins[:, 0] = 1
    return enc, probs, joins


def test_guard_never_drops_a_real_word(tokenizer):
    """User rule: noise is rare. Even when the model calls everything noise, words with letters or digits reach the agents."""
    from party_tagger.infer import decode

    ex = _field("{ORG|BALTIC TIMBER TRADING LTD}\n{INTRO|C/O} {ORG|ALPHA CORPORATE SERVICES LTD}\n{NOISE|%@#$^$#} {NOISE|NOTPROVIDED}")
    enc, probs, joins = _probs(ex, tokenizer, lambda lbl: "O" if lbl == "O" else "NOISE")
    out = decode(ex.text, enc.offsets, probs, joins, LABELS, {"noise": 0.5, "name": 0.9, "address": 0.9})
    by_text = {u["text"]: u for u in out["units"]}
    for word in ("BALTIC", "ALPHA", "CORPORATE", "LTD"):
        assert by_text[word]["send_to"] == ["name", "geo"] and "kept_by_guard" in by_text[word]["flags"], word
    assert by_text["%@#$^$#"]["send_to"] == [] and by_text["NOTPROVIDED"]["send_to"] == []


def test_care_of_party_goes_to_both_agents(tokenizer):
    examples = {ex.text.split("\n")[1]: ex for ex in load_markup_file(ROOT / "data" / "handcrafted.txt")}
    out = perfect_output(examples["C/O ALPHA CORPORATE SERVICES LTD"], tokenizer)["routing"]
    assert out["name_agent"]["entities"] == [
        {"value": "BALTIC TIMBER TRADING LTD", "type": "organization", "role": "party"},
        {"value": "ALPHA CORPORATE SERVICES LTD", "type": "organization", "role": "care_of", "marker": "C/O"}]
    assert out["geo_agent"]["care_of"] == ["C/O ALPHA CORPORATE SERVICES LTD"]
    assert out["geo_agent"]["iso20022_hint"]["TwnNm"] == "NICOSIA" and not out["ambiguous"]


def test_line_code_glued_to_care_of_is_split(tokenizer):
    examples = {ex.text.split("\n")[1]: ex for ex in load_markup_file(ROOT / "data" / "handcrafted.txt")}
    out = perfect_output(examples["2/C/O OOO VEKTOR LOGISTIK"], tokenizer)
    units = {u["text"]: u for u in out["units"]}
    assert units["C/O"]["send_to"] == ["name", "geo"]
    assert [p["value"] for p in out["routing"]["ignored"]] == ["1/", "2/", "2/", "3/"]
    assert out["routing"]["name_agent"]["entities"][1] == {
        "value": "OOO VEKTOR LOGISTIK", "type": "organization", "role": "care_of", "marker": "C/O"}


def test_markers():
    from party_tagger.routing import find_markers

    text = "ACME LTD FOR FURTHER CREDIT TO JOHN DOE C / O HOTEL ROYAL T/A BEST SHOES"
    units = []
    for m in __import__("re").finditer(r"[A-Z0-9.]+(?: ?/ ?[A-Z0-9]+)?", text):
        units.append({"start": m.start(), "end": m.end()})
    roles = [(text[units[i]["start"]:units[j - 1]["end"]], r) for i, j, r in find_markers(units, text)]
    assert roles == [("FOR FURTHER CREDIT TO", "further_credit"), ("C / O", "care_of"), ("T/A", "trading_as")]
