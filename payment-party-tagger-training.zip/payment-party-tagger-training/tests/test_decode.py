"""Post-processing check with perfect token predictions: decoding must reproduce the gold segmentation."""

from pathlib import Path

import pytest
import torch

from party_tagger.data import IGNORE, encode_example
from party_tagger.infer import decode
from party_tagger.labels import LABEL2ID, LABELS
from party_tagger.metrics import field_correct
from party_tagger.swiftgen import TRAIN_LOCALES, generate, load_markup_file

ROOT = Path(__file__).parents[1]
# tokenizer of a downloaded Gemma 4 base, E4B first (E2B is assumed to share it; not checked yet)
MODEL = next((p for p in (ROOT / "models" / "gemma-4-E4B-it", ROOT / "models" / "gemma-4-E2B-it") if (p / "tokenizer.json").exists()),
             ROOT / "models" / "gemma-4-E4B-it")

pytestmark = pytest.mark.skipif(not (MODEL / "tokenizer.json").exists(), reason="tokenizer not downloaded")


@pytest.fixture(scope="module")
def tokenizer():
    from party_tagger.backbone import load_tokenizer

    return load_tokenizer(MODEL)


def perfect_output(ex, tokenizer):
    enc = encode_example(ex, tokenizer)
    token_probs = torch.zeros(len(enc.input_ids), len(LABELS))
    for k, lbl in enumerate(enc.labels):
        token_probs[k, LABEL2ID["O"] if lbl == IGNORE else lbl] = 1.0
    join_probs = torch.zeros(len(enc.input_ids), 2)
    for k, j in enumerate(enc.joins):
        join_probs[k, 1 if j == 1 else 0] = 1.0
    return decode(ex.text, enc.offsets, token_probs, join_probs, LABELS)


def test_handcrafted_round_trip(tokenizer):
    for ex in load_markup_file(ROOT / "data" / "handcrafted.txt"):
        out = perfect_output(ex, tokenizer)
        assert field_correct(ex, out["char_labels"], coarse=False), ex.text
        assert {j["pos"]: j["word_continues"] for j in out["joins"]} == dict(ex.joins)


def test_generated_round_trip(tokenizer):
    examples = generate(300, seed=5, locales=TRAIN_LOCALES)
    bad = [ex.text for ex in examples if not field_correct(ex, perfect_output(ex, tokenizer)["char_labels"], coarse=False)]
    # a token can straddle two components (e.g. "O." of "SP. Z O.O." next to a separator); allow a tiny residue
    assert len(bad) <= 3, bad[:3]


def test_result_of_first_handcrafted_example(tokenizer):
    ex = load_markup_file(ROOT / "data" / "handcrafted.txt")[0]
    r = perfect_output(ex, tokenizer)["result"]
    assert r["name"] == "JAN KOWALSKI TRADING SP. Z O.O. ACCOUNTS DEPT"
    assert r["party_details"] == ["ATTN"]
    assert r["iso20022"] == {"StrtNm": "UL. MARSZALKOWSKA", "BldgNb": "142", "Room": "5", "PstCd": "00-061",
                             "TwnNm": "WARSZAWA", "Ctry": "PL", "Ctry_written": "POLAND"}
    assert r["noise"] == ["/PL61109010140000071219812874"]
    assert r["hybrid_address_ready"]
