import importlib.util
from pathlib import Path

import torch
import torch.nn.functional as F

spec = importlib.util.spec_from_file_location("train_script", Path(__file__).parents[1] / "scripts" / "train.py")
train_script = importlib.util.module_from_spec(spec)
spec.loader.exec_module(train_script)


def test_distillation_uses_teacher_only_where_it_is_right():
    torch.manual_seed(0)
    logits = torch.randn(1, 3, 4)
    gold = torch.tensor([[0, 1, -100]])
    teacher = torch.tensor([[[0.7, 0.1, 0.1, 0.1],     # top = 0 = gold -> distil
                             [0.6, 0.2, 0.1, 0.1],     # top = 0 != gold 1 -> CE only
                             [0.25, 0.25, 0.25, 0.25]]])
    alpha = 0.5
    got = train_script.distilled(logits, gold, teacher, alpha)
    logp = logits.log_softmax(-1)
    ce0, ce1 = -logp[0, 0, 0], -logp[0, 1, 1]
    kl0 = (teacher[0, 0] * (teacher[0, 0].log() - logp[0, 0])).sum()
    expected = ((1 - alpha) * ce0 + alpha * kl0 + ce1) / 2
    assert torch.allclose(got, expected, atol=1e-5)


def test_without_teacher_it_is_plain_cross_entropy():
    logits = torch.randn(2, 5, 3)
    gold = torch.randint(0, 3, (2, 5))
    got = train_script.distilled(logits, gold, None, 0.5)
    assert torch.allclose(got, F.cross_entropy(logits.flatten(0, 1), gold.flatten()), atol=1e-5)
