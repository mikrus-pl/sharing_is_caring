# Routing do agentów: v3

Progi Mondrian conformal (per grupa) z plików: calib_big.jsonl.

Reguła: słowo pomijamy, gdy P(szum) > próg szumu; treść idzie do agenta nazw, gdy P(nazwa | treść) ≥ próg nazwy,
do agenta geo, gdy P(adres | treść) ≥ próg adresu; gdy żadna strona nie jest pewna (albo obie są) — do obu.

| polityka | próg SZUM (pomiń, gdy P >) | próg NAZWA | próg ADRES |
|---|---|---|---|
| argmax | – | – | – |
| gwarancja 99% | 0.9500 | 0.9942 | 0.9945 |
| gwarancja 99.5% | 0.9500 | 0.9837 | 0.9814 |
| gwarancja 99.9% | 0.9500 | 0.7352 | 0.5663 |

Domyślna polityka zapisana w modelu: **gwarancja 99.5%**.

## test

| metryka (litery i cyfry) | argmax | gwarancja 99% | gwarancja 99.5% | gwarancja 99.9% |
|---|---|---|---|---|
| Słowa nazwy, które dotarły do agenta nazw | 99.99% | 100.00% | 100.00% | 99.99% |
| Słowa adresu, które dotarły do agenta geo | 99.99% | 100.00% | 100.00% | 100.00% |
| Czystość wejścia agenta nazw | 99.89% | 99.56% | 99.76% | 99.89% |
| Czystość wejścia agenta geo | 94.27% | 93.90% | 94.09% | 94.21% |
| Treść wysłana do obu agentów | 0.03% | 0.42% | 0.21% | 0.08% |
| Treść zgubiona (nigdzie nie wysłana) | 0.00% | 0.00% | 0.00% | 0.00% |
| Szum wysłany do agentów | 0.22% | 0.22% | 0.22% | 0.22% |
| Pola bez zgubionej treści | 99.80% | 100.00% | 100.00% | 99.90% |
| Pola idealne (wszystko tylko tam, gdzie trzeba) | 99.40% | 96.90% | 98.10% | 99.20% |
| Pola z niejednoznacznością | 0.30% | 3.00% | 1.80% | 0.60% |

## test_heldout

| metryka (litery i cyfry) | argmax | gwarancja 99% | gwarancja 99.5% | gwarancja 99.9% |
|---|---|---|---|---|
| Słowa nazwy, które dotarły do agenta nazw | 99.79% | 100.00% | 100.00% | 99.84% |
| Słowa adresu, które dotarły do agenta geo | 99.75% | 99.98% | 99.98% | 99.87% |
| Czystość wejścia agenta nazw | 99.55% | 96.43% | 97.75% | 99.52% |
| Czystość wejścia agenta geo | 95.43% | 93.15% | 94.45% | 95.35% |
| Treść wysłana do obu agentów | 0.01% | 3.06% | 1.61% | 0.17% |
| Treść zgubiona (nigdzie nie wysłana) | 0.00% | 0.00% | 0.00% | 0.00% |
| Szum wysłany do agentów | 0.07% | 0.07% | 0.07% | 0.07% |
| Pola bez zgubionej treści | 97.70% | 99.90% | 99.70% | 98.10% |
| Pola idealne (wszystko tylko tam, gdzie trzeba) | 97.50% | 79.00% | 87.10% | 96.10% |
| Pola z niejednoznacznością | 0.10% | 20.90% | 12.80% | 2.30% |

## handcrafted

| metryka (litery i cyfry) | argmax | gwarancja 99% | gwarancja 99.5% | gwarancja 99.9% |
|---|---|---|---|---|
| Słowa nazwy, które dotarły do agenta nazw | 100.00% | 100.00% | 100.00% | 100.00% |
| Słowa adresu, które dotarły do agenta geo | 100.00% | 100.00% | 100.00% | 100.00% |
| Czystość wejścia agenta nazw | 100.00% | 98.29% | 100.00% | 100.00% |
| Czystość wejścia agenta geo | 93.22% | 91.67% | 93.22% | 93.22% |
| Treść wysłana do obu agentów | 0.00% | 1.78% | 0.00% | 0.00% |
| Treść zgubiona (nigdzie nie wysłana) | 0.00% | 0.00% | 0.00% | 0.00% |
| Szum wysłany do agentów | 0.00% | 0.00% | 0.00% | 0.00% |
| Pola bez zgubionej treści | 100.00% | 100.00% | 100.00% | 100.00% |
| Pola idealne (wszystko tylko tam, gdzie trzeba) | 100.00% | 86.67% | 100.00% | 100.00% |
| Pola z niejednoznacznością | 0.00% | 13.33% | 0.00% | 0.00% |

## test_hard

| metryka (litery i cyfry) | argmax | gwarancja 99% | gwarancja 99.5% | gwarancja 99.9% |
|---|---|---|---|---|
| Słowa nazwy, które dotarły do agenta nazw | 99.91% | 99.99% | 99.99% | 99.91% |
| Słowa adresu, które dotarły do agenta geo | 99.92% | 99.99% | 99.98% | 99.98% |
| Czystość wejścia agenta nazw | 97.80% | 96.53% | 97.28% | 97.78% |
| Czystość wejścia agenta geo | 91.99% | 90.88% | 91.43% | 91.92% |
| Treść wysłana do obu agentów | 0.30% | 1.69% | 0.95% | 0.38% |
| Treść zgubiona (nigdzie nie wysłana) | 0.01% | 0.01% | 0.01% | 0.01% |
| Szum wysłany do agentów | 6.00% | 6.00% | 6.00% | 6.00% |
| Pola bez zgubionej treści | 98.50% | 99.80% | 99.60% | 98.90% |
| Pola idealne (wszystko tylko tam, gdzie trzeba) | 88.60% | 79.60% | 84.30% | 88.20% |
| Pola z niejednoznacznością | 7.70% | 18.10% | 13.40% | 8.50% |

## test_hard_heldout

| metryka (litery i cyfry) | argmax | gwarancja 99% | gwarancja 99.5% | gwarancja 99.9% |
|---|---|---|---|---|
| Słowa nazwy, które dotarły do agenta nazw | 99.83% | 100.00% | 100.00% | 99.87% |
| Słowa adresu, które dotarły do agenta geo | 99.54% | 99.99% | 99.97% | 99.71% |
| Czystość wejścia agenta nazw | 96.61% | 93.03% | 94.37% | 96.59% |
| Czystość wejścia agenta geo | 91.09% | 88.97% | 89.98% | 91.03% |
| Treść wysłana do obu agentów | 0.23% | 3.82% | 2.43% | 0.39% |
| Treść zgubiona (nigdzie nie wysłana) | 0.00% | 0.00% | 0.00% | 0.00% |
| Szum wysłany do agentów | 7.62% | 7.68% | 7.68% | 7.68% |
| Pola bez zgubionej treści | 96.30% | 99.80% | 99.70% | 97.60% |
| Pola idealne (wszystko tylko tam, gdzie trzeba) | 87.60% | 69.20% | 75.60% | 86.70% |
| Pola z niejednoznacznością | 7.80% | 30.10% | 23.40% | 10.00% |
