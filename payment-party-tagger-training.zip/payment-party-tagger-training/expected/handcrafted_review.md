# Przegląd: ręcznie napisane przypadki

## #0 — ✅ nazwa/adres/szum, ✅ szczegółowe etykiety, pewność 0.9866
```
/PL61109010140000071219812874
JAN KOWALSKI TRADING SP. Z O.O.
UL. MARSZALKOWSKA 142/5 00-061 WARS
ZAWA POLAND ATTN ACCOUNTS DEPT
```
| | etykieta | tekst |
|---|---|---|
| ✅ | ACCOUNT | `/PL61109010140000071219812874` |
| ✅ | NAME_ORG | `JAN KOWALSKI TRADING SP. Z O.O.` |
| ✅ | STREET | `UL. MARSZALKOWSKA` |
| ✅ | BUILDING | `142` |
| ✅ | UNIT | `5` |
| ✅ | POSTCODE | `00-061` |
| ✅ | TOWN | `WARS⏎ZAWA` |
| ✅ | COUNTRY | `POLAND` |
| ✅ | PARTY_INTRO | `ATTN` |
| ✅ | NAME_ORG | `ACCOUNTS DEPT` |

**Nazwa:** JAN KOWALSKI TRADING SP. Z O.O. ACCOUNTS DEPT  
**Adres:** UL. MARSZALKOWSKA 142 5 00-061 WARSZAWA POLAND  
**Szum:** ['/PL61109010140000071219812874']  
**ISO 20022:** `{"StrtNm": "UL. MARSZALKOWSKA", "BldgNb": "142", "Room": "5", "PstCd": "00-061", "TwnNm": "WARSZAWA", "Ctry": "PL", "Ctry_written": "POLAND"}`

## #1 — ✅ nazwa/adres/szum, ✅ szczegółowe etykiety, pewność 0.9994
```
/021000021123456789
ACME GLOBAL LOGISTICS INC. 1 PARK A
VE SUITE 400 NEW YORK NY 10017 US
```
| | etykieta | tekst |
|---|---|---|
| ✅ | ACCOUNT | `/021000021123456789` |
| ✅ | BUILDING | `1` |
| ✅ | NAME_ORG | `ACME GLOBAL LOGISTICS INC.` |
| ✅ | STREET | `PARK A⏎VE` |
| ✅ | UNIT | `SUITE 400` |
| ✅ | TOWN | `NEW YORK` |
| ✅ | REGION | `NY` |
| ✅ | POSTCODE | `10017` |
| ✅ | COUNTRY | `US` |

**Nazwa:** ACME GLOBAL LOGISTICS INC.  
**Adres:** 1 PARK AVE SUITE 400 NEW YORK NY 10017 US  
**Szum:** ['/021000021123456789']  
**ISO 20022:** `{"BldgNb": "1", "StrtNm": "PARK AVE", "Room": "SUITE 400", "TwnNm": "NEW YORK", "CtrySubDvsn": "NY", "PstCd": "10017", "Ctry": "US"}`

## #2 — ✅ nazwa/adres/szum, ✅ szczegółowe etykiety, pewność 0.9986
```
HANS-PETER MUELLER
HAUPTSTRASSE 12A
80331 MUENCHEN
DE
```
| | etykieta | tekst |
|---|---|---|
| ✅ | NAME_PERSON | `HANS-PETER MUELLER` |
| ✅ | STREET | `HAUPTSTRASSE` |
| ✅ | BUILDING | `12A` |
| ✅ | POSTCODE | `80331` |
| ✅ | TOWN | `MUENCHEN` |
| ✅ | COUNTRY | `DE` |

**Nazwa:** HANS-PETER MUELLER  
**Adres:** HAUPTSTRASSE 12A 80331 MUENCHEN DE  
**Szum:** []  
**ISO 20022:** `{"StrtNm": "HAUPTSTRASSE", "BldgNb": "12A", "PstCd": "80331", "TwnNm": "MUENCHEN", "Ctry": "DE"}`

## #3 — ✅ nazwa/adres/szum, ✅ szczegółowe etykiety, pewność 0.9988
```
THAMES VALLEY ENGINEERING LTD
45 HIGH STREET
READING RG1 2AB
UNITED KINGDOM
```
| | etykieta | tekst |
|---|---|---|
| ✅ | NAME_ORG | `THAMES VALLEY ENGINEERING LTD` |
| ✅ | BUILDING | `45` |
| ✅ | STREET | `HIGH STREET` |
| ✅ | TOWN | `READING` |
| ✅ | POSTCODE | `RG1 2AB` |
| ✅ | COUNTRY | `UNITED KINGDOM` |

**Nazwa:** THAMES VALLEY ENGINEERING LTD  
**Adres:** 45 HIGH STREET READING RG1 2AB UNITED KINGDOM  
**Szum:** []  
**ISO 20022:** `{"BldgNb": "45", "StrtNm": "HIGH STREET", "TwnNm": "READING", "PstCd": "RG1 2AB", "Ctry": "GB", "Ctry_written": "UNITED KINGDOM"}`

## #4 — ✅ nazwa/adres/szum, ✅ szczegółowe etykiety, pewność 0.9937
```
LONDON METAL TRADERS LIMITED
10 LOMBARD STREET LONDON EC3V 9AA
```
| | etykieta | tekst |
|---|---|---|
| ✅ | TOWN | `LONDON` |
| ✅ | NAME_ORG | `LONDON METAL TRADERS LIMITED` |
| ✅ | BUILDING | `10` |
| ✅ | STREET | `LOMBARD STREET` |
| ✅ | POSTCODE | `EC3V 9AA` |

**Nazwa:** LONDON METAL TRADERS LIMITED  
**Adres:** 10 LOMBARD STREET LONDON EC3V 9AA  
**Szum:** []  
**ISO 20022:** `{"BldgNb": "10", "StrtNm": "LOMBARD STREET", "TwnNm": "LONDON", "PstCd": "EC3V 9AA"}`

## #5 — ✅ nazwa/adres/szum, ✅ szczegółowe etykiety, pewność 0.9786
```
GEORGE WASHINGTON
1600 WASHINGTON AVENUE
WASHINGTON DC 20001
USA
```
| | etykieta | tekst |
|---|---|---|
| ✅ | NAME_PERSON | `GEORGE WASHINGTON` |
| ✅ | TOWN | `WASHINGTON` |
| ✅ | BUILDING | `1600` |
| ✅ | STREET | `WASHINGTON AVENUE` |
| ✅ | REGION | `DC` |
| ✅ | POSTCODE | `20001` |
| ✅ | COUNTRY | `USA` |

**Nazwa:** GEORGE WASHINGTON  
**Adres:** 1600 WASHINGTON AVENUE WASHINGTON DC 20001 USA  
**Szum:** []  
**ISO 20022:** `{"BldgNb": "1600", "StrtNm": "WASHINGTON AVENUE", "TwnNm": "WASHINGTON", "CtrySubDvsn": "DC", "PstCd": "20001", "Ctry": "US", "Ctry_written": "USA"}`

## #6 — ✅ nazwa/adres/szum, ✅ szczegółowe etykiety, pewność 0.9998
```
/DE89370400440532013000
1/SCHMIDT, ANNA
2/BAHNHOFSTRASSE 7
3/DE/BERLIN 10115
```
| | etykieta | tekst |
|---|---|---|
| ✅ | ACCOUNT | `/DE89370400440532013000` |
| ✅ | COUNTRY | `DE` |
| ✅ | BUILDING | `7` |
| ✅ | LINE_PREFIX | `1/` |
| ✅ | NAME_PERSON | `SCHMIDT, ANNA` |
| ✅ | LINE_PREFIX | `2/` |
| ✅ | STREET | `BAHNHOFSTRASSE` |
| ✅ | LINE_PREFIX | `3/` |
| ✅ | TOWN | `BERLIN` |
| ✅ | POSTCODE | `10115` |

**Nazwa:** SCHMIDT, ANNA  
**Adres:** BAHNHOFSTRASSE 7 DE BERLIN 10115  
**Szum:** ['/DE89370400440532013000', '1/', '2/', '3/']  
**ISO 20022:** `{"StrtNm": "BAHNHOFSTRASSE", "BldgNb": "7", "Ctry": "DE", "TwnNm": "BERLIN", "PstCd": "10115"}`

## #7 — ✅ nazwa/adres/szum, ✅ szczegółowe etykiety, pewność 0.9987
```
1/INTERNATIONAL BUSINESS MACHINES
1/CORPORATION
2/1 NEW ORCHARD ROAD
3/US/ARMONK NY
```
| | etykieta | tekst |
|---|---|---|
| ✅ | BUILDING | `1` |
| ✅ | LINE_PREFIX | `1/` |
| ✅ | NAME_ORG | `INTERNATIONAL BUSINESS MACHINES` |
| ✅ | COUNTRY | `US` |
| ✅ | NAME_ORG | `CORPORATION` |
| ✅ | LINE_PREFIX | `2/` |
| ✅ | STREET | `NEW ORCHARD ROAD` |
| ✅ | LINE_PREFIX | `3/` |
| ✅ | TOWN | `ARMONK` |
| ✅ | REGION | `NY` |

**Nazwa:** INTERNATIONAL BUSINESS MACHINES CORPORATION  
**Adres:** 1 NEW ORCHARD ROAD US ARMONK NY  
**Szum:** ['1/', '1/', '2/', '3/']  
**ISO 20022:** `{"BldgNb": "1", "StrtNm": "NEW ORCHARD ROAD", "Ctry": "US", "TwnNm": "ARMONK", "CtrySubDvsn": "NY"}`

## #8 — ✅ nazwa/adres/szum, ✅ szczegółowe etykiety, pewność 0.9998
```
FERRARI COSTRUZIONI S.R.L., VIA ROM
A, 21, 20121, MILANO, NOTPROVIDED
```
| | etykieta | tekst |
|---|---|---|
| ✅ | NAME_ORG | `FERRARI COSTRUZIONI S.R.L.` |
| ✅ | STREET | `VIA ROM⏎A` |
| ✅ | BUILDING | `21` |
| ✅ | POSTCODE | `20121` |
| ✅ | TOWN | `MILANO` |
| ✅ | NOISE | `NOTPROVIDED` |

**Nazwa:** FERRARI COSTRUZIONI S.R.L.  
**Adres:** VIA ROMA 21 20121 MILANO  
**Szum:** ['NOTPROVIDED']  
**ISO 20022:** `{"StrtNm": "VIA ROMA", "BldgNb": "21", "PstCd": "20121", "TwnNm": "MILANO"}`

## #9 — ✅ nazwa/adres/szum, ✅ szczegółowe etykiety, pewność 0.9998
```
/NL91ABNA0417164300
STICHTING DE ZONNEBLOEM
KEIZERSGRACHT 174 1016 DW
AMSTERDAM NETHERLANDS
```
| | etykieta | tekst |
|---|---|---|
| ✅ | ACCOUNT | `/NL91ABNA0417164300` |
| ✅ | NAME_ORG | `STICHTING DE ZONNEBLOEM` |
| ✅ | STREET | `KEIZERSGRACHT` |
| ✅ | BUILDING | `174` |
| ✅ | POSTCODE | `1016 DW` |
| ✅ | TOWN | `AMSTERDAM` |
| ✅ | COUNTRY | `NETHERLANDS` |

**Nazwa:** STICHTING DE ZONNEBLOEM  
**Adres:** KEIZERSGRACHT 174 1016 DW AMSTERDAM NETHERLANDS  
**Szum:** ['/NL91ABNA0417164300']  
**ISO 20022:** `{"StrtNm": "KEIZERSGRACHT", "BldgNb": "174", "PstCd": "1016 DW", "TwnNm": "AMSTERDAM", "Ctry": "NL", "Ctry_written": "NETHERLANDS"}`

## #10 — ✅ nazwa/adres/szum, ❌ szczegółowe etykiety, pewność 0.4464
```
GARCIA LOPEZ MARIA
CALLE DE ALCALA 45 2 IZQ
28014 MADRID ESPANA
TEL 34 915551234
```
| | etykieta | tekst |
|---|---|---|
| ✅ | NAME_PERSON | `GARCIA LOPEZ MARIA` |
| ✅ | STREET | `CALLE DE ALCALA` |
| ➕ model | BUILDING | `45 2` |
| ➖ brak (wzorzec) | BUILDING | `45` |
| ➖ brak (wzorzec) | UNIT | `2 IZQ` |
| ➕ model | STREET | `IZ` |
| ➕ model | UNIT | `Q` |
| ✅ | POSTCODE | `28014` |
| ✅ | TOWN | `MADRID` |
| ✅ | COUNTRY | `ESPANA` |
| ✅ | PARTY_ID | `TEL 34 915551234` |

**Nazwa:** GARCIA LOPEZ MARIA  
**Adres:** CALLE DE ALCALA 45 2 IZ Q 28014 MADRID ESPANA  
**Szum:** []  
**ISO 20022:** `{"StrtNm": "CALLE DE ALCALA IZ", "BldgNb": "45 2", "Room": "Q", "PstCd": "28014", "TwnNm": "MADRID", "Ctry": "ES", "Ctry_written": "ESPANA"}`

## #11 — ✅ nazwa/adres/szum, ✅ szczegółowe etykiety, pewność 0.9992
```
SOCIETE GENERALE DE TRANSPORT SA
29 BOULEVARD HAUSSMANN
75009 PARIS FRANCE
```
| | etykieta | tekst |
|---|---|---|
| ✅ | NAME_ORG | `SOCIETE GENERALE DE TRANSPORT SA` |
| ✅ | BUILDING | `29` |
| ✅ | STREET | `BOULEVARD HAUSSMANN` |
| ✅ | POSTCODE | `75009` |
| ✅ | TOWN | `PARIS` |
| ✅ | COUNTRY | `FRANCE` |

**Nazwa:** SOCIETE GENERALE DE TRANSPORT SA  
**Adres:** 29 BOULEVARD HAUSSMANN 75009 PARIS FRANCE  
**Szum:** []  
**ISO 20022:** `{"BldgNb": "29", "StrtNm": "BOULEVARD HAUSSMANN", "PstCd": "75009", "TwnNm": "PARIS", "Ctry": "FR", "Ctry_written": "FRANCE"}`

## #12 — ✅ nazwa/adres/szum, ✅ szczegółowe etykiety, pewność 0.9994
```
ZURICH VERSICHERUNGS AG
MYTHENQUAI 2
8002 ZURICH
SWITZERLAND
```
| | etykieta | tekst |
|---|---|---|
| ✅ | NAME_ORG | `ZURICH VERSICHERUNGS AG` |
| ✅ | TOWN | `ZURICH` |
| ✅ | STREET | `MYTHENQUAI` |
| ✅ | BUILDING | `2` |
| ✅ | POSTCODE | `8002` |
| ✅ | COUNTRY | `SWITZERLAND` |

**Nazwa:** ZURICH VERSICHERUNGS AG  
**Adres:** MYTHENQUAI 2 8002 ZURICH SWITZERLAND  
**Szum:** []  
**ISO 20022:** `{"StrtNm": "MYTHENQUAI", "BldgNb": "2", "PstCd": "8002", "TwnNm": "ZURICH", "Ctry": "CH", "Ctry_written": "SWITZERLAND"}`

## #13 — ✅ nazwa/adres/szum, ✅ szczegółowe etykiety, pewność 0.9927
```
REF INV 2026/0412
NORDIC FISH EXPORT AS
BRYGGEN 15 5003 BERGEN
NORWAY
```
| | etykieta | tekst |
|---|---|---|
| ✅ | PARTY_ID | `REF INV 2026/0412` |
| ✅ | NAME_ORG | `NORDIC FISH EXPORT AS` |
| ✅ | STREET | `BRYGGEN` |
| ✅ | BUILDING | `15` |
| ✅ | POSTCODE | `5003` |
| ✅ | TOWN | `BERGEN` |
| ✅ | COUNTRY | `NORWAY` |

**Nazwa:** NORDIC FISH EXPORT AS  
**Adres:** BRYGGEN 15 5003 BERGEN NORWAY  
**Szum:** []  
**ISO 20022:** `{"StrtNm": "BRYGGEN", "BldgNb": "15", "PstCd": "5003", "TwnNm": "BERGEN", "Ctry": "NO", "Ctry_written": "NORWAY"}`

## #14 — ✅ nazwa/adres/szum, ✅ szczegółowe etykiety, pewność 0.9999
```
ANNA NOWAK UL KWIATOWA 5 31-542 KRA
KOW POLSKA
```
| | etykieta | tekst |
|---|---|---|
| ✅ | NAME_PERSON | `ANNA NOWAK` |
| ✅ | STREET | `UL KWIATOWA` |
| ✅ | BUILDING | `5` |
| ✅ | POSTCODE | `31-542` |
| ✅ | TOWN | `KRA⏎KOW` |
| ✅ | COUNTRY | `POLSKA` |

**Nazwa:** ANNA NOWAK  
**Adres:** UL KWIATOWA 5 31-542 KRAKOW POLSKA  
**Szum:** []  
**ISO 20022:** `{"StrtNm": "UL KWIATOWA", "BldgNb": "5", "PstCd": "31-542", "TwnNm": "KRAKOW", "Ctry": "PL", "Ctry_written": "POLSKA"}`

## #15 — ✅ nazwa/adres/szum, ❌ szczegółowe etykiety, pewność 0.5556
```
GOLDEN DRAGON TRADING CO LTD
FLAT B 12/F 88 NATHAN ROAD
TSIM SHA TSUI KOWLOON
HONG KONG
```
| | etykieta | tekst |
|---|---|---|
| ✅ | NAME_ORG | `GOLDEN DRAGON TRADING CO LTD` |
| ➖ brak (wzorzec) | UNIT | `FLAT B 12/F` |
| ➕ model | UNIT | `FLAT B` |
| ➕ model | BUILDING | `12` |
| ➕ model | UNIT | `F 88` |
| ➖ brak (wzorzec) | BUILDING | `88` |
| ✅ | STREET | `NATHAN ROAD` |
| ➕ model | TOWN | `TSIM SHA TSUI KOWLOON` |
| ➖ brak (wzorzec) | TOWN | `TSIM SHA TSUI` |
| ➖ brak (wzorzec) | REGION | `KOWLOON` |
| ✅ | COUNTRY | `HONG KONG` |

**Nazwa:** GOLDEN DRAGON TRADING CO LTD  
**Adres:** FLAT B 12 F 88 NATHAN ROAD TSIM SHA TSUI KOWLOON HONG KONG  
**Szum:** []  
**ISO 20022:** `{"Room": "FLAT B F 88", "BldgNb": "12", "StrtNm": "NATHAN ROAD", "TwnNm": "TSIM SHA TSUI KOWLOON", "Ctry": "HK", "Ctry_written": "HONG KONG"}`

## #16 — ✅ nazwa/adres/szum, ✅ szczegółowe etykiety, pewność 0.9995
```
ANADOLU TEKSTIL SANAYI VE TICARET
A.S. ATATURK CADDESI 45
34349 ISTANBUL TURKIYE
```
| | etykieta | tekst |
|---|---|---|
| ✅ | NAME_ORG | `ANADOLU TEKSTIL SANAYI VE TICARET⏎A.S.` |
| ✅ | STREET | `ATATURK CADDESI` |
| ✅ | BUILDING | `45` |
| ✅ | POSTCODE | `34349` |
| ✅ | TOWN | `ISTANBUL` |
| ✅ | COUNTRY | `TURKIYE` |

**Nazwa:** ANADOLU TEKSTIL SANAYI VE TICARET A.S.  
**Adres:** ATATURK CADDESI 45 34349 ISTANBUL TURKIYE  
**Szum:** []  
**ISO 20022:** `{"StrtNm": "ATATURK CADDESI", "BldgNb": "45", "PstCd": "34349", "TwnNm": "ISTANBUL", "Ctry": "TR", "Ctry_written": "TURKIYE"}`

## #17 — ✅ nazwa/adres/szum, ✅ szczegółowe etykiety, pewność 0.9946
```
JOHN SMITH
NOTPROVIDED
NOTPROVIDED
```
| | etykieta | tekst |
|---|---|---|
| ✅ | NAME_PERSON | `JOHN SMITH` |
| ➖ brak (wzorzec) | NOISE | `NOTPROVIDED` |
| ➕ model | NOISE | `NOTPROVIDED⏎NOTPROVIDED` |

**Nazwa:** JOHN SMITH  
**Adres:**   
**Szum:** ['NOTPROVIDED NOTPROVIDED']  
**ISO 20022:** `{}`

## #18 — ✅ nazwa/adres/szum, ✅ szczegółowe etykiety, pewność 0.9997
```
/GB29NWBK60161331926819
MR DAVID O'CONNOR
DUBLIN IRELAND
```
| | etykieta | tekst |
|---|---|---|
| ✅ | ACCOUNT | `/GB29NWBK60161331926819` |
| ✅ | NAME_PERSON | `MR DAVID O'CONNOR` |
| ✅ | TOWN | `DUBLIN` |
| ✅ | COUNTRY | `IRELAND` |

**Nazwa:** MR DAVID O'CONNOR  
**Adres:** DUBLIN IRELAND  
**Szum:** ['/GB29NWBK60161331926819']  
**ISO 20022:** `{"TwnNm": "DUBLIN", "Ctry": "IE", "Ctry_written": "IRELAND"}`

## #19 — ✅ nazwa/adres/szum, ✅ szczegółowe etykiety, pewność 0.9996
```
BALTIC SHIPPING SP. Z O.O.
ATTN PIOTR ZIELINSKI
UL. HESTII 1 81-731 SOPOT
```
| | etykieta | tekst |
|---|---|---|
| ✅ | NAME_ORG | `BALTIC SHIPPING SP. Z O.O.` |
| ✅ | PARTY_INTRO | `ATTN` |
| ✅ | NAME_PERSON | `PIOTR ZIELINSKI` |
| ✅ | STREET | `UL. HESTII` |
| ✅ | BUILDING | `1` |
| ✅ | POSTCODE | `81-731` |
| ✅ | TOWN | `SOPOT` |

**Nazwa:** BALTIC SHIPPING SP. Z O.O. PIOTR ZIELINSKI  
**Adres:** UL. HESTII 1 81-731 SOPOT  
**Szum:** []  
**ISO 20022:** `{"StrtNm": "UL. HESTII", "BldgNb": "1", "PstCd": "81-731", "TwnNm": "SOPOT"}`

## #20 — ✅ nazwa/adres/szum, ✅ szczegółowe etykiety, pewność 0.9998
```
WIEN 1010 AUSTRIA
DONAU HANDELS GMBH
KAERNTNER STRASSE 21-23
```
| | etykieta | tekst |
|---|---|---|
| ✅ | TOWN | `WIEN` |
| ✅ | POSTCODE | `1010` |
| ✅ | COUNTRY | `AUSTRIA` |
| ✅ | NAME_ORG | `DONAU HANDELS GMBH` |
| ✅ | STREET | `KAERNTNER STRASSE` |
| ✅ | BUILDING | `21-23` |

**Nazwa:** DONAU HANDELS GMBH  
**Adres:** WIEN 1010 AUSTRIA KAERNTNER STRASSE 21-23  
**Szum:** []  
**ISO 20022:** `{"TwnNm": "WIEN", "PstCd": "1010", "Ctry": "AT", "StrtNm": "KAERNTNER STRASSE", "BldgNb": "21-23", "Ctry_written": "AUSTRIA"}`

## #21 — ✅ nazwa/adres/szum, ✅ szczegółowe etykiety, pewność 0.9997
```
JAN KOWALSKI I MARIA KOWALSKA
OS. SLONECZNE 12/34
60-123 POZNAN
```
| | etykieta | tekst |
|---|---|---|
| ✅ | NAME_PERSON | `JAN KOWALSKI I MARIA KOWALSKA` |
| ✅ | STREET | `OS. SLONECZNE` |
| ✅ | BUILDING | `12` |
| ✅ | UNIT | `34` |
| ✅ | POSTCODE | `60-123` |
| ✅ | TOWN | `POZNAN` |

**Nazwa:** JAN KOWALSKI I MARIA KOWALSKA  
**Adres:** OS. SLONECZNE 12 34 60-123 POZNAN  
**Szum:** []  
**ISO 20022:** `{"StrtNm": "OS. SLONECZNE", "BldgNb": "12", "Room": "34", "PstCd": "60-123", "TwnNm": "POZNAN"}`

## #22 — ✅ nazwa/adres/szum, ✅ szczegółowe etykiety, pewność 0.852
```
TECHNO SOLUTIONS GMBH/LINDENSTR./5/
10969/BERLIN/GERMANY
```
| | etykieta | tekst |
|---|---|---|
| ✅ | NAME_ORG | `TECHNO SOLUTIONS GMBH` |
| ✅ | STREET | `LINDENSTR.` |
| ✅ | BUILDING | `5` |
| ✅ | POSTCODE | `10969` |
| ✅ | TOWN | `BERLIN` |
| ✅ | COUNTRY | `GERMANY` |

**Nazwa:** TECHNO SOLUTIONS GMBH  
**Adres:** LINDENSTR. 5 10969 BERLIN GERMANY  
**Szum:** []  
**ISO 20022:** `{"StrtNm": "LINDENSTR.", "BldgNb": "5", "PstCd": "10969", "TwnNm": "BERLIN", "Ctry": "DE", "Ctry_written": "GERMANY"}`

## #23 — ✅ nazwa/adres/szum, ✅ szczegółowe etykiety, pewność 0.7054
```
PRAZSKE STROJIRNY A.S.
NA PORICI 1079/3A
110 00 PRAHA 1
CZECH REPUBLIC
```
| | etykieta | tekst |
|---|---|---|
| ✅ | NAME_ORG | `PRAZSKE STROJIRNY A.S.` |
| ✅ | STREET | `NA PORICI` |
| ✅ | BUILDING | `1079/3A` |
| ✅ | POSTCODE | `110 00` |
| ✅ | TOWN | `PRAHA 1` |
| ✅ | COUNTRY | `CZECH REPUBLIC` |

**Nazwa:** PRAZSKE STROJIRNY A.S.  
**Adres:** NA PORICI 1079/3A 110 00 PRAHA 1 CZECH REPUBLIC  
**Szum:** []  
**ISO 20022:** `{"StrtNm": "NA PORICI", "BldgNb": "1079/3A", "PstCd": "110 00", "TwnNm": "PRAHA 1", "Ctry": "CZ", "Ctry_written": "CZECH REPUBLIC"}`

## #24 — ✅ nazwa/adres/szum, ✅ szczegółowe etykiety, pewność 0.9793
```
KANCELARIA PRAWNA NOWAK I WSPOLNICY
UL. NOWY SWIAT 142/144 00-372
WARSZAWA PL
```
| | etykieta | tekst |
|---|---|---|
| ✅ | NAME_ORG | `KANCELARIA PRAWNA NOWAK I WSPOLNICY` |
| ✅ | STREET | `UL. NOWY SWIAT` |
| ✅ | BUILDING | `142/144` |
| ✅ | POSTCODE | `00-372` |
| ✅ | TOWN | `WARSZAWA` |
| ✅ | COUNTRY | `PL` |

**Nazwa:** KANCELARIA PRAWNA NOWAK I WSPOLNICY  
**Adres:** UL. NOWY SWIAT 142/144 00-372 WARSZAWA PL  
**Szum:** []  
**ISO 20022:** `{"StrtNm": "UL. NOWY SWIAT", "BldgNb": "142/144", "PstCd": "00-372", "TwnNm": "WARSZAWA", "Ctry": "PL"}`

## #25 — ✅ nazwa/adres/szum, ✅ szczegółowe etykiety, pewność 0.9996
```
/GB33BUKB20201555555555
MARIA PETROVA
C/O GRAND HOTEL EUROPA
45 NEVSKY PROSPEKT
ST PETERSBURG RU
```
| | etykieta | tekst |
|---|---|---|
| ✅ | ACCOUNT | `/GB33BUKB20201555555555` |
| ✅ | NAME_PERSON | `MARIA PETROVA` |
| ✅ | PARTY_INTRO | `C/O` |
| ✅ | NAME_ORG | `GRAND HOTEL EUROPA` |
| ✅ | BUILDING | `45` |
| ✅ | STREET | `NEVSKY PROSPEKT` |
| ✅ | TOWN | `ST PETERSBURG` |
| ✅ | COUNTRY | `RU` |

**Nazwa:** MARIA PETROVA GRAND HOTEL EUROPA  
**Adres:** 45 NEVSKY PROSPEKT ST PETERSBURG RU  
**Szum:** ['/GB33BUKB20201555555555']  
**ISO 20022:** `{"BldgNb": "45", "StrtNm": "NEVSKY PROSPEKT", "TwnNm": "ST PETERSBURG", "Ctry": "RU"}`

## #26 — ✅ nazwa/adres/szum, ✅ szczegółowe etykiety, pewność 0.5884
```
BALTIC TIMBER TRADING LTD
C/O ALPHA CORPORATE SERVICES LTD
2 ARCH MAKARIOS III AVE
1065 NICOSIA CYPRUS
```
| | etykieta | tekst |
|---|---|---|
| ✅ | NAME_ORG | `BALTIC TIMBER TRADING LTD` |
| ✅ | PARTY_INTRO | `C/O` |
| ✅ | NAME_ORG | `ALPHA CORPORATE SERVICES LTD` |
| ✅ | BUILDING | `2` |
| ✅ | STREET | `ARCH MAKARIOS III AVE` |
| ✅ | POSTCODE | `1065` |
| ✅ | TOWN | `NICOSIA` |
| ✅ | COUNTRY | `CYPRUS` |

**Nazwa:** BALTIC TIMBER TRADING LTD ALPHA CORPORATE SERVICES LTD  
**Adres:** 2 ARCH MAKARIOS III AVE 1065 NICOSIA CYPRUS  
**Szum:** []  
**ISO 20022:** `{"BldgNb": "2", "StrtNm": "ARCH MAKARIOS III AVE", "PstCd": "1065", "TwnNm": "NICOSIA", "Ctry": "CY", "Ctry_written": "CYPRUS"}`

## #27 — ✅ nazwa/adres/szum, ✅ szczegółowe etykiety, pewność 0.9984
```
1/IVAN SOKOLOV
2/C/O OOO VEKTOR LOGISTIK
2/UL TVERSKAYA 7
3/RU/MOSCOW
```
| | etykieta | tekst |
|---|---|---|
| ✅ | LINE_PREFIX | `1/` |
| ✅ | NAME_PERSON | `IVAN SOKOLOV` |
| ✅ | LINE_PREFIX | `2/` |
| ✅ | PARTY_INTRO | `C/O` |
| ✅ | NAME_ORG | `OOO VEKTOR LOGISTIK` |
| ✅ | STREET | `UL TVERSKAYA` |
| ✅ | BUILDING | `7` |
| ✅ | LINE_PREFIX | `3/` |
| ✅ | COUNTRY | `RU` |
| ✅ | TOWN | `MOSCOW` |

**Nazwa:** IVAN SOKOLOV OOO VEKTOR LOGISTIK  
**Adres:** UL TVERSKAYA 7 RU MOSCOW  
**Szum:** ['1/', '2/', '2/', '3/']  
**ISO 20022:** `{"StrtNm": "UL TVERSKAYA", "BldgNb": "7", "Ctry": "RU", "TwnNm": "MOSCOW"}`

## #28 — ✅ nazwa/adres/szum, ✅ szczegółowe etykiety, pewność 0.9997
```
ACME TRADING LTD %@#$^$#
ATTN JOHN SMITH
10 HIGH STREET
LONDON NOTPROVIDED
```
| | etykieta | tekst |
|---|---|---|
| ✅ | NAME_ORG | `ACME TRADING LTD` |
| ✅ | NOISE | `%@#$^$#` |
| ✅ | PARTY_INTRO | `ATTN` |
| ✅ | NAME_PERSON | `JOHN SMITH` |
| ✅ | BUILDING | `10` |
| ✅ | STREET | `HIGH STREET` |
| ✅ | TOWN | `LONDON` |
| ✅ | NOISE | `NOTPROVIDED` |

**Nazwa:** ACME TRADING LTD JOHN SMITH  
**Adres:** 10 HIGH STREET LONDON  
**Szum:** ['%@#$^$#', 'NOTPROVIDED']  
**ISO 20022:** `{"BldgNb": "10", "StrtNm": "HIGH STREET", "TwnNm": "LONDON"}`

## #29 — ✅ nazwa/adres/szum, ✅ szczegółowe etykiety, pewność 0.9993
```
/GB82WEST12345698765432
NORDSEE FISCH GMBH
FFC KLAUS BERGMANN
HAFENSTRASSE 3 20457 HAMBURG
```
| | etykieta | tekst |
|---|---|---|
| ✅ | ACCOUNT | `/GB82WEST12345698765432` |
| ✅ | BUILDING | `3` |
| ✅ | NAME_ORG | `NORDSEE FISCH GMBH` |
| ✅ | PARTY_INTRO | `FFC` |
| ✅ | NAME_PERSON | `KLAUS BERGMANN` |
| ✅ | STREET | `HAFENSTRASSE` |
| ✅ | POSTCODE | `20457` |
| ✅ | TOWN | `HAMBURG` |

**Nazwa:** NORDSEE FISCH GMBH KLAUS BERGMANN  
**Adres:** HAFENSTRASSE 3 20457 HAMBURG  
**Szum:** ['/GB82WEST12345698765432']  
**ISO 20022:** `{"StrtNm": "HAFENSTRASSE", "BldgNb": "3", "PstCd": "20457", "TwnNm": "HAMBURG"}`
