# Raport: v3

Model: `models/gemma-4-E4B-it` + LoRA r=32, atencja dwukierunkowa: True, trening: 100000 przykładów, 3125 kroków, 112.6 min.
Temperatury kalibracji: token 1.086, łamanie linii 0.915.

| Metryka | test | test_heldout | handcrafted | test_hard | test_hard_heldout |
|---|---|---|---|---|---|
| Pole w 100% poprawne: nazwa/adres/szum (litery i cyfry) | 99.6% | 96.5% | 100.0% | 98.0% | 95.6% |
| Pole w 100% poprawne: szczegółowe etykiety (każdy znak) | 98.8% | 88.9% | 93.3% | 91.8% | 87.1% |
| Nazwa dokładnie | 99.6% | 96.5% | 100.0% | 98.4% | 95.7% |
| Adres dokładnie | 99.6% | 96.5% | 100.0% | 98.1% | 95.7% |
| Szum dokładnie | 100.0% | 100.0% | 100.0% | 99.5% | 99.8% |
| Trafność znaków (szczegółowe) | 99.9% | 98.7% | 99.2% | 99.7% | 99.0% |
| Sklejanie łamanych słów | 99.9% | 99.6% | 100.0% | 99.7% | 99.5% |
| Heurystyka: pole w 100% poprawne | 26.8% | 29.2% | 40.0% | 12.2% | 15.4% |
| Automat przy celu 1% błędu: pokrycie / błąd | 99% / 0.002 | 92% / 0.013 | 93% / 0.0 | 97% / 0.0113 | 93% / 0.0205 |
| Automat przy celu 5% błędu: pokrycie / błąd | 100% / 0.004 | 99% / 0.0312 | 100% / 0.0 | 100% / 0.02 | 100% / 0.0431 |

**Certyfikowane progi** (jednostronny 95% Clopper–Pearson na FIT = 3509 pól kalibracyjnych): cel 1% → 0.5682, cel 5% → 0.3215.
Sprawdzenie na CERT (1491 pól, nieużytych do dopasowania): cel 1% → pokrycie 98%, błąd 0.0082; cel 5% → pokrycie 100%, błąd 0.0107.
Kalibracja na kraju wyłączonym z dopasowania (ECE tokenów): średnio 0.0015, najgorzej 0.0058 (lt_LT).

Czas: pojedyncze pole p50 **81.8 ms**, paczka 32 pól: **54.5 pól/s** (RTX 4080, PyTorch eager).

Szczegóły per etykieta: `metrics.json`. Przegląd ręcznych przypadków: `handcrafted_review.md`.