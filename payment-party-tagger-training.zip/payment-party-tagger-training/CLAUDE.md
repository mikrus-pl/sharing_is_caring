# Claude Code guide for this package

The rules and the map of documents for every agent are in `AGENTS.md` (one source of truth, imported below).
Read it before doing anything; then the document it points to (`CLOUD_GPU.md`, `MLX_MIGRATION.md` or `README.md`).

@AGENTS.md
