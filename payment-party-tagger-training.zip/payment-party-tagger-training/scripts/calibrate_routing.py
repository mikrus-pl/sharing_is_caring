"""Calibrate the name/geo routing (class-conditional conformal thresholds) and compare routing policies.

Usage: .venv/Scripts/python scripts/calibrate_routing.py --run runs/v1
Stores the chosen thresholds in <run>/meta.json ("routing") and writes <run>/routing_report.md.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from party_tagger.data import load_jsonl
from party_tagger.infer import Predictor, decode
from party_tagger.routing import calibrate_thresholds, routing_metrics, unit_gold

POLICIES = {  # name: alpha (None = plain argmax)
    "argmax": None,
    "gwarancja 99%": 0.01,
    "gwarancja 99.5%": 0.005,
    "gwarancja 99.9%": 0.001,
}
DEFAULT_POLICY = "gwarancja 99.5%"


def raw_outputs(pred: Predictor, examples):
    t_tok, t_join = pred.meta["temperature"]["token"], pred.meta["temperature"]["join"]
    out = []
    for i in range(0, len(examples), 32):
        chunk = examples[i:i + 32]
        for ex, (offsets, tl, jl) in zip(chunk, pred.raw([e.text for e in chunk])):
            out.append((ex, offsets, (tl / t_tok).softmax(-1), (jl / t_join).softmax(-1)))
    return out


def decode_all(raws, labels, thresholds):
    return [decode(ex.text, off, tp, jp, labels, thresholds) for ex, off, tp, jp in raws]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", default="runs/v1")
    ap.add_argument("--data", default="data/generated")
    ap.add_argument("--calib-files", nargs="+", default=["calib.jsonl", "calib_hard.jsonl"])
    ap.add_argument("--sets", nargs="+", default=["test", "test_heldout", "handcrafted", "test_hard", "test_hard_heldout"])
    args = ap.parse_args()
    run, data = Path(args.run), Path(args.data)
    pred = Predictor(run)
    labels = pred.labels

    calib = [ex for name in args.calib_files for ex in load_jsonl(data / name)]
    units_with_gold = []
    for out, ex in zip(decode_all(raw_outputs(pred, calib), labels, None), calib):
        for u in out["units"]:
            g = unit_gold(u, ex.char_labels, ex.text)
            if g:
                units_with_gold.append((u, g))
    thresholds = {name: (calibrate_thresholds(units_with_gold, alpha) if alpha else None) for name, alpha in POLICIES.items()}

    meta_path = run / "meta.json"
    meta = json.loads(meta_path.read_text(encoding="utf-8"))
    counts = {g: sum(1 for _, gold in units_with_gold if gold == g) for g in ("NAME", "ADDRESS", "NOISE")}
    meta["routing"] = {"policy": DEFAULT_POLICY, "alpha": POLICIES[DEFAULT_POLICY], "thresholds": thresholds[DEFAULT_POLICY],
                       "calibration_units": counts}
    meta_path.write_text(json.dumps(meta, indent=2), encoding="utf-8")

    results = {}
    for name in args.sets:
        raws = raw_outputs(pred, load_jsonl(data / f"{name}.jsonl"))
        results[name] = {pol: routing_metrics([r[0] for r in raws], decode_all(raws, labels, thresholds[pol])) for pol in POLICIES}

    rows = [("Słowa nazwy, które dotarły do agenta nazw", "name_recall"), ("Słowa adresu, które dotarły do agenta geo", "address_recall"),
            ("Czystość wejścia agenta nazw", "name_agent_purity"), ("Czystość wejścia agenta geo", "geo_agent_purity"),
            ("Treść wysłana do obu agentów", "content_sent_to_both"), ("Treść zgubiona (nigdzie nie wysłana)", "content_dropped"),
            ("Szum wysłany do agentów", "noise_sent_to_agents"), ("Pola bez zgubionej treści", "fields_lossless"),
            ("Pola idealne (wszystko tylko tam, gdzie trzeba)", "fields_perfect"), ("Pola z niejednoznacznością", "fields_with_ambiguity")]
    md = [f"# Routing do agentów: {run.name}", "",
          "Progi Mondrian conformal (per grupa) z plików: " + ", ".join(args.calib_files) + ".", "",
          "Reguła: słowo pomijamy, gdy P(szum) > próg szumu; treść idzie do agenta nazw, gdy P(nazwa | treść) ≥ próg nazwy,",
          "do agenta geo, gdy P(adres | treść) ≥ próg adresu; gdy żadna strona nie jest pewna (albo obie są) — do obu.", "",
          "| polityka | próg SZUM (pomiń, gdy P >) | próg NAZWA | próg ADRES |", "|---|---|---|---|"]
    for pol, t in thresholds.items():
        md.append(f"| {pol} | " + (" | ".join(f"{t[k]:.4f}" for k in ("noise", "name", "address")) if t else "– | – | –") + " |")
    md += ["", f"Domyślna polityka zapisana w modelu: **{DEFAULT_POLICY}**.", ""]
    for name in args.sets:
        md += [f"## {name}", "", "| metryka (litery i cyfry) | " + " | ".join(POLICIES) + " |", "|---|" + "---|" * len(POLICIES)]
        for title, key in rows:
            md.append(f"| {title} | " + " | ".join(f"{results[name][pol][key]:.2%}" for pol in POLICIES) + " |")
        md.append("")
    (run / "routing_report.md").write_text("\n".join(md), encoding="utf-8")
    (run / "routing_metrics.json").write_text(json.dumps({"thresholds": thresholds, "results": results}, indent=2, ensure_ascii=False), encoding="utf-8")
    print("\n".join(md))


if __name__ == "__main__":
    main()
