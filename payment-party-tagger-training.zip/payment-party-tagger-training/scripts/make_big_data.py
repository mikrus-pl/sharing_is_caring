"""Large training and calibration sets for the distillation round (v3).

  train_big   100 000 fields: 40 000 normal (14 countries) + 60 000 hard and damaged (32 countries)
  calib_big     5 000 fields:  2 000 normal + 3 000 hard and damaged (fit / certify split is done by group later)
Test sets stay the ones from make_data.py / make_hard_data.py, so results stay comparable with v0-v2.
"""

from __future__ import annotations

import argparse
import json
import random
from collections import Counter
from pathlib import Path

from party_tagger.corrupt import corrupt
from party_tagger.swiftgen import EXTRA_LOCALES, TRAIN_LOCALES, ensure_hash_seed, generate

PARTS = {  # split: [(seed, locales, hard, size argument)]
    "train_big": [(31, TRAIN_LOCALES, False, "normal"), (32, TRAIN_LOCALES + EXTRA_LOCALES, True, "hard")],
    "calib_big": [(33, TRAIN_LOCALES, False, "calib_normal"), (34, TRAIN_LOCALES + EXTRA_LOCALES, True, "calib_hard")],
}


def main():
    ensure_hash_seed()
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="data/generated")
    ap.add_argument("--normal", type=int, default=40_000)
    ap.add_argument("--hard", type=int, default=60_000)
    ap.add_argument("--calib-normal", type=int, default=2_000)
    ap.add_argument("--calib-hard", type=int, default=3_000)
    args = ap.parse_args()
    out = Path(args.out)
    sizes = {"normal": args.normal, "hard": args.hard, "calib_normal": args.calib_normal, "calib_hard": args.calib_hard}
    tests = set()
    for name in ("test", "test_heldout", "test_hard", "test_hard_heldout"):
        with open(out / f"{name}.jsonl", encoding="utf-8") as f:
            tests |= {json.loads(line)["text"] for line in f}

    for split, parts in PARTS.items():
        examples = []
        for seed, locales, hard, size in parts:
            rng = random.Random(seed * 7)
            base = generate(sizes[size], seed=seed, locales=locales, hard=hard)
            for ex in base:
                if hard:
                    ex = corrupt(ex, rng, rng.choices([0, 1, 2, 3], weights=[0.15, 0.35, 0.30, 0.20])[0])
                ex.meta["source"] = "hard" if hard else "normal"
                examples.append(ex)
        random.Random(41 if split == "train_big" else 42).shuffle(examples)
        before = len(examples)
        examples = [ex for ex in examples if ex.text not in tests]
        for i, ex in enumerate(examples):
            ex.meta["uid"] = f"{split}-{i}"
            ex.meta["group"] = ex.meta["locale"]  # calibration families: country
        with open(out / f"{split}.jsonl", "w", encoding="utf-8", newline="\n") as f:
            for ex in examples:
                f.write(ex.to_json() + "\n")
        print(f"{split:10s} {len(examples):7d} fields (removed {before - len(examples)} identical to test fields), "
              f"countries {len({ex.meta['locale'] for ex in examples})}, "
              f"sources {dict(Counter(ex.meta['source'] for ex in examples))}")


if __name__ == "__main__":
    main()
