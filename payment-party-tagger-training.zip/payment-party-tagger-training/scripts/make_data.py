"""Generate the synthetic SWIFT field dataset and convert the hand-written examples.

Splits: train / dev / calib / test come from the training countries with different seeds;
test_heldout uses countries never seen in training (Portugal, Romania).
"""

from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path

from party_tagger.swiftgen import HELDOUT_LOCALES, TRAIN_LOCALES, ensure_hash_seed, generate, load_markup_file

SPLITS = {  # name: (seed, locales)
    "train": (11, TRAIN_LOCALES),
    "dev": (12, TRAIN_LOCALES),
    "calib": (13, TRAIN_LOCALES),
    "test": (14, TRAIN_LOCALES),
    "test_heldout": (15, HELDOUT_LOCALES),
}


def main():
    ensure_hash_seed()
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="data/generated")
    ap.add_argument("--train", type=int, default=8000)
    ap.add_argument("--eval", type=int, default=1000, help="size of calib / test / test_heldout")
    ap.add_argument("--dev", type=int, default=300)
    args = ap.parse_args()
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    sizes = {"train": args.train, "dev": args.dev, "calib": args.eval, "test": args.eval, "test_heldout": args.eval}
    for name, (seed, locales) in SPLITS.items():
        examples = generate(sizes[name], seed=seed, locales=locales)
        with open(out / f"{name}.jsonl", "w", encoding="utf-8", newline="\n") as f:
            for ex in examples:
                f.write(ex.to_json() + "\n")
        styles = Counter(ex.meta["style"] for ex in examples)
        print(f"{name:13s} {len(examples):6d}  styles={dict(styles)}")
    hand = load_markup_file("data/handcrafted.txt")
    with open(out / "handcrafted.jsonl", "w", encoding="utf-8", newline="\n") as f:
        for ex in hand:
            f.write(ex.to_json() + "\n")
    print(f"handcrafted   {len(hand):6d}")
    texts = {name: {json.loads(line)["text"] for line in open(out / f"{name}.jsonl", encoding="utf-8")} for name in SPLITS}
    print("identical texts train/test:", len(texts["train"] & texts["test"]))


if __name__ == "__main__":
    main()
