"""Release gate: is a run good enough to publish? Criteria agreed with the user on 2026-10-21 ("relatively good").

    python scripts/check_release.py --run runs/v3 --export publish/payment-party-tagger-gemma4-e4b
"""

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FIELD_EXACT = {"test": 0.99, "test_heldout": 0.95, "test_hard": 0.95, "test_hard_heldout": 0.92}
HANDCRAFTED_MAX_WRONG = 1
MAX_DROPPED = 0.002
CARE_OF = {"ALPHA CORPORATE SERVICES LTD", "OOO VEKTOR LOGISTIK"}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", default="runs/v3")
    ap.add_argument("--export", default="publish/payment-party-tagger-gemma4-e4b")
    args = ap.parse_args()
    run = ROOT / args.run
    metrics = json.loads((run / "metrics.json").read_text(encoding="utf-8"))
    meta = json.loads((run / "meta.json").read_text(encoding="utf-8"))
    routing = json.loads((run / "routing_metrics.json").read_text(encoding="utf-8"))
    policy = meta["routing"]["policy"]
    rows, ok = [], True

    def check(name, value, limit, good):
        nonlocal ok
        passed = good(value, limit)
        ok &= passed
        rows.append(f"{'PASS' if passed else 'FAIL'}  {name:<55} {value}  (limit {limit})")

    for key, limit in FIELD_EXACT.items():
        check(f"field exact name/address/noise: {key}", metrics["sets"][key]["field_exact_coarse"], limit, lambda v, l: v >= l)
    hc = metrics["sets"]["handcrafted"]
    wrong = round(hc["fields"] * (1 - hc["field_exact_coarse"]))
    check(f"handcrafted fields wrong (of {hc['fields']})", wrong, HANDCRAFTED_MAX_WRONG, lambda v, l: v <= l)
    for key, res in routing["results"].items():
        check(f"content dropped by routing: {key}", res[policy]["content_dropped"], MAX_DROPPED, lambda v, l: v <= l)

    examples = json.loads((ROOT / args.export / "example_output.json").read_text(encoding="utf-8"))
    found = {}
    for ex in examples:
        units = ex["output"]["units"]
        for e in ex["output"]["routing"]["name_agent"]["entities"]:
            if e["role"] == "care_of":
                words = [u for u in units if u["value"] in e["value"].split()]
                found[e["value"]] = min(u["p"]["NAME"] for u in words) if words else 0.0
    for name in sorted(CARE_OF):
        # the model itself must call the C/O party a name (not only the guard keeping it)
        check(f"C/O party is a name for the model: {name}", found.get(name, 0.0), 0.5, lambda v, l: v >= l)

    print("\n".join(rows))
    print("RELEASE: OK" if ok else "RELEASE: NOT OK")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
