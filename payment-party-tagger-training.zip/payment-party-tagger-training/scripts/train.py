"""Train the SWIFT field tagger: frozen Gemma + LoRA + token heads.

Usage: .venv/Scripts/python scripts/train.py --out runs/v0
Distillation (basal recipe): --teacher data/teacher/train_big.teacher.npz --distill-alpha 0.5
  on tokens where the teacher's top label equals the gold label: (1 - a) * CE(gold) + a * KL(teacher || student)
  elsewhere: CE(gold) only
"""

from __future__ import annotations

import argparse
import json
import math
import random
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

from party_tagger.backbone import load_tokenizer
from party_tagger.data import IGNORE, collate, encode_example, load_jsonl
from party_tagger.device import DEVICE, autocast, device_name, peak_memory_gib
from party_tagger.labels import LABELS
from party_tagger.tagger import LORA_TARGETS, build_for_training, save_run


def add_teacher(batch: dict, rows: list[tuple[np.ndarray, np.ndarray]]) -> None:
    """Pad the teacher's token and line-break probabilities to the batch width."""
    b, width = batch["input_ids"].shape
    tok = torch.zeros(b, width, len(LABELS), device=DEVICE)
    join = torch.full((b, width), -1.0, device=DEVICE)
    for i, (t, j) in enumerate(rows):
        n = len(t)
        tok[i, :n] = torch.from_numpy(t.astype(np.float32))
        join[i, :n] = torch.from_numpy(j.astype(np.float32))
    batch["teacher"], batch["teacher_join"] = tok, join


def distilled(logits: torch.Tensor, gold: torch.Tensor, teacher: torch.Tensor | None, alpha: float) -> torch.Tensor:
    """Mean per-token loss; KL to the teacher only where the teacher's top answer is the gold one."""
    valid = gold != IGNORE
    if not valid.any():
        return logits.new_zeros(())
    logp = logits.float().log_softmax(-1)
    ce = -logp.gather(-1, gold.clamp_min(0).unsqueeze(-1)).squeeze(-1)
    if teacher is None or alpha <= 0:
        return ce[valid].mean()
    agree = valid & (teacher.argmax(-1) == gold)
    kl = (teacher * (teacher.clamp_min(1e-8).log() - logp)).sum(-1)
    loss = torch.where(agree, (1 - alpha) * ce + alpha * kl, ce)
    return loss[valid].mean()


def losses(model, batch, join_weight: float, alpha: float = 0.0):
    with autocast():
        token_logits, join_logits = model(batch["input_ids"], batch["attention_mask"])
    teacher = batch.get("teacher")
    token_loss = distilled(token_logits, batch["labels"], teacher, alpha)
    teacher_join = None
    if teacher is not None:
        p = batch["teacher_join"].clamp(0, 1)
        teacher_join = torch.stack([1 - p, p], -1)
    join_loss = distilled(join_logits, batch["joins"], teacher_join, alpha)
    return token_loss + join_weight * join_loss, token_loss, join_loss, token_logits


@torch.no_grad()
def token_accuracy(model, data, pad_id, bs=32):
    model.eval()
    correct = total = 0
    for i in range(0, len(data), bs):
        batch = collate(data[i:i + bs], pad_id)
        with autocast():
            logits, _ = model(batch["input_ids"], batch["attention_mask"])
        mask = batch["labels"] != IGNORE
        correct += (logits.argmax(-1)[mask] == batch["labels"][mask]).sum().item()
        total += mask.sum().item()
    model.train()
    return correct / max(total, 1)


def load_teacher(path: str, n: int) -> list[tuple[np.ndarray, np.ndarray]]:
    t = np.load(path)
    starts, tokens, joins = t["starts"], t["tokens"], t["joins"]
    names = list(t["labels"])
    if names != LABELS:  # older teacher (fewer labels): its columns move to the student's order, new labels get 0
        unknown = [n for n in names if n not in LABELS]
        if unknown:
            raise ValueError(f"teacher labels unknown to the student: {unknown}")
        mapped = np.zeros((len(tokens), len(LABELS)), dtype=tokens.dtype)
        mapped[:, [LABELS.index(n) for n in names]] = tokens
        tokens = mapped
        print(f"teacher has {len(names)} labels, student {len(LABELS)}: new labels only learn from the gold data")
    if len(starts) - 1 < n:
        raise ValueError(f"teacher has {len(starts) - 1} examples, training uses {n}")
    return [(tokens[starts[i]:starts[i + 1]], joins[starts[i]:starts[i + 1]]) for i in range(n)]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default="models/gemma-4-E4B-it")
    ap.add_argument("--data", default="data/generated")
    ap.add_argument("--train-files", nargs="+", default=["train.jsonl"], help="files in --data mixed for training")
    ap.add_argument("--out", default="runs/v0")
    ap.add_argument("--epochs", type=float, default=1.0)
    ap.add_argument("--bs", type=int, default=8)
    ap.add_argument("--grad-accum", type=int, default=1, help="micro-batches per optimizer step (effective batch = bs * grad-accum)")
    ap.add_argument("--lr", type=float, default=1e-4, help="LoRA learning rate")
    ap.add_argument("--head-lr", type=float, default=1e-3)
    ap.add_argument("--lora-r", type=int, default=16)
    ap.add_argument("--join-weight", type=float, default=0.5)
    ap.add_argument("--teacher", default=None, help="teacher probabilities (.npz from scripts/teacher_label.py), aligned with --train-files")
    ap.add_argument("--distill-alpha", type=float, default=0.5)
    ap.add_argument("--causal", action="store_true", help="keep the causal mask (ablation)")
    ap.add_argument("--no-grad-ckpt", action="store_true")
    ap.add_argument("--quant4", action="store_true", help="QLoRA: frozen backbone in 4-bit NF4 (for 12B on 16 GB)")
    ap.add_argument("--max-train", type=int, default=None)
    ap.add_argument("--max-steps", type=int, default=None)
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()

    random.seed(args.seed)
    torch.manual_seed(args.seed)
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)

    tok = load_tokenizer(args.model)
    train = [encode_example(ex, tok) for name in args.train_files for ex in load_jsonl(Path(args.data) / name, args.max_train)]
    dev = [encode_example(ex, tok) for ex in load_jsonl(Path(args.data) / "dev.jsonl")]
    teacher = load_teacher(args.teacher, len(train)) if args.teacher else None
    if teacher:
        bad = sum(len(t) != len(e.input_ids) for (t, _), e in zip(teacher, train))
        if bad:
            raise ValueError(f"{bad} examples: teacher and student token counts differ")
        agree = [float((t.astype(np.float32).argmax(-1)[np.array(e.labels) != IGNORE] == np.array(e.labels)[np.array(e.labels) != IGNORE]).mean())
                 for (t, _), e in zip(teacher[:2000], train[:2000])]
        print(f"teacher loaded: top label = gold on {np.mean(agree):.2%} of tokens (first 2000 fields)")
    lengths = sorted(len(e.input_ids) for e in train)
    print(f"train {len(train)} examples, tokens/example median {lengths[len(lengths) // 2]}, max {lengths[-1]}")

    model = build_for_training(args.model, bidirectional=not args.causal, lora_r=args.lora_r,
                               grad_ckpt=not args.no_grad_ckpt, quant4=args.quant4)
    lora_params = [p for n, p in model.backbone.named_parameters() if p.requires_grad]
    head_params = list(model.token_head.parameters()) + list(model.join_head.parameters())
    print(f"trainable: LoRA {sum(p.numel() for p in lora_params) / 1e6:.1f}M, heads {sum(p.numel() for p in head_params) / 1e3:.1f}K")
    opt = torch.optim.AdamW([
        {"params": lora_params, "lr": args.lr},
        {"params": head_params, "lr": args.head_lr},
    ], weight_decay=0.0)

    per_step = args.bs * args.grad_accum
    steps_per_epoch = math.ceil(len(train) / per_step)
    total_steps = args.max_steps or int(steps_per_epoch * args.epochs)
    warmup = max(1, int(0.05 * total_steps))
    sched = torch.optim.lr_scheduler.LambdaLR(
        opt, lambda s: min(1.0, (s + 1) / warmup) * max(0.0, (total_steps - s) / max(1, total_steps - warmup))
    )

    log = open(out / "train_log.jsonl", "w", encoding="utf-8")
    model.train()
    step, t0 = 0, time.perf_counter()
    order = []
    while step < total_steps:
        for _ in range(args.grad_accum):
            if not order:
                order = list(range(len(train)))
                random.shuffle(order)
            idx, order = order[: args.bs], order[args.bs:]
            batch = collate([train[i] for i in idx], tok.pad_token_id)
            if teacher:
                add_teacher(batch, [teacher[i] for i in idx])
            loss, tl, jl, _ = losses(model, batch, args.join_weight, args.distill_alpha if teacher else 0.0)
            (loss / args.grad_accum).backward()
        torch.nn.utils.clip_grad_norm_(lora_params + head_params, 1.0)
        opt.step()
        sched.step()
        opt.zero_grad(set_to_none=True)
        step += 1
        if step % 25 == 0 or step == total_steps:
            elapsed = time.perf_counter() - t0
            rec = {"step": step, "loss": round(loss.item(), 4), "token_loss": round(tl.item(), 4),
                   "join_loss": round(jl.item(), 4), "lr": sched.get_last_lr()[0], "elapsed_s": round(elapsed, 1),
                   "eta_s": round(elapsed / step * (total_steps - step), 1)}
            if step % 250 == 0 or step == total_steps:
                rec["dev_token_acc"] = round(token_accuracy(model, dev, tok.pad_token_id), 4)
            rec["gpu_gib"] = peak_memory_gib()
            print(json.dumps(rec), flush=True)
            log.write(json.dumps(rec) + "\n")
            log.flush()

    meta = {
        "base_model": args.model,
        "bidirectional": not args.causal,
        "quant4": args.quant4,
        "labels": LABELS,
        "lora": {"r": args.lora_r, "alpha": 2 * args.lora_r, "targets": LORA_TARGETS},
        "train": {"files": args.train_files, "examples": len(train), "steps": total_steps, "bs": args.bs, "grad_accum": args.grad_accum,
                  "lr": args.lr, "head_lr": args.head_lr, "join_weight": args.join_weight,
                  "teacher": args.teacher, "distill_alpha": args.distill_alpha if teacher else None,
                  "minutes": round((time.perf_counter() - t0) / 60, 1), "device": device_name(), "seed": args.seed,
                  "grad_ckpt": not args.no_grad_ckpt},
        "temperature": {"token": 1.0, "join": 1.0},
    }
    save_run(model, out, meta)
    print(f"saved to {out}")


if __name__ == "__main__":
    main()
