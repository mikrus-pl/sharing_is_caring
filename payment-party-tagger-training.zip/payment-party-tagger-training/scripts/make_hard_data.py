"""Hard, damaged training and test data: more countries and conventions, more noise, twins, and 0-3 corruptions per field.

  train_hard          training countries + 18 extra countries, hard generation, damaged
  test_hard           same countries, different seed
  test_hard_heldout   Portugal and Romania (never in training), hard generation, damaged
"""

from __future__ import annotations

import argparse
import random
from collections import Counter
from pathlib import Path

from party_tagger.corrupt import corrupt
from party_tagger.swiftgen import EXTRA_LOCALES, HELDOUT_LOCALES, TRAIN_LOCALES, ensure_hash_seed, generate

SPLITS = {  # name: (seed, locales, size argument)
    "train_hard": (21, TRAIN_LOCALES + EXTRA_LOCALES, "train"),
    "calib_hard": (23, TRAIN_LOCALES + EXTRA_LOCALES, "eval"),
    "test_hard": (24, TRAIN_LOCALES + EXTRA_LOCALES, "eval"),
    "test_hard_heldout": (25, HELDOUT_LOCALES, "eval"),
}


def main():
    ensure_hash_seed()
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="data/generated")
    ap.add_argument("--train", type=int, default=8000)
    ap.add_argument("--eval", type=int, default=1000)
    args = ap.parse_args()
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    for name, (seed, locales, size) in SPLITS.items():
        rng = random.Random(seed * 7)
        base = generate(getattr(args, size), seed=seed, locales=locales, hard=True)
        examples = [corrupt(ex, rng, rng.choices([0, 1, 2, 3], weights=[0.15, 0.35, 0.30, 0.20])[0]) for ex in base]
        with open(out / f"{name}.jsonl", "w", encoding="utf-8", newline="\n") as f:
            for ex in examples:
                f.write(ex.to_json() + "\n")
        ops = Counter(op for ex in examples for op in ex.meta["corruptions"])
        too_long = sum(any(len(line) > 35 for line in ex.text.split("\n")) for ex in examples)
        print(f"{name:18s} {len(examples):5d}  lines>35: {too_long}  countries: {len(set(ex.meta['locale'] for ex in examples))}")
        print("   damage:", dict(ops.most_common()))


if __name__ == "__main__":
    main()
