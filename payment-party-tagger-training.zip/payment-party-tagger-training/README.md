# Paczka treningowa: payment-party-tagger v3

Ta paczka pozwala **od zera wytrenować** model `msw1410/payment-party-tagger-gemma4-e4b` (wersja v3) na innym komputerze
i sprawdzić, że wyszło to samo. Zawiera kod, dane, dokładne ustawienia, wzorcowe wyniki i jeden skrypt, który prowadzi
przez cały proces.

- **Co robi model:** dzieli zawartość pola strony z wiadomości SWIFT MT (`50K`, `59`, `50F`, `59F`) na nazwę strony („kto”),
  adres („gdzie”) i szum. Szczegóły: [ARCHITECTURE.md](ARCHITECTURE.md).
- **Skąd dane:** w 100% syntetyczne, z generatora w paczce. Nie ma tu prawdziwych wiadomości ani danych osobowych.
  Szczegóły: [DATA.md](DATA.md).
- **Czego paczka nie zawiera:** modelu bazowego (Gemma 4 E4B: 16 GB; opcjonalnie E2B: 10,3 GB). Skrypt pobierze go sam z Hugging Face.

## Najprościej: niech zrobi to agent
Otwórz ten folder w agencie (np. Claude Code na Macu) i napisz, czego chcesz, np. „wytrenuj model w chmurze” albo
„przyspiesz go na moim Macu”. Agent przeczyta `AGENTS.md` (Claude Code: `CLAUDE.md`, który go importuje) i właściwy dokument:
- **`CLOUD_GPU.md`:** trening w chmurze. Zalecany Hugging Face Jobs (bez klikania, płatne za minutę, ok. 2–4 USD za
  pełny trening), albo Google Colab sterowany przez agenta.
- **`MLX_MIGRATION.md`:** dopisanie silnika MLX, żeby trening i uruchamianie szły szybko na karcie graficznej Maca.

Ty tylko logujesz się, gdy agent poprosi, płacisz i zatwierdzasz koszt przed uruchomieniem.

## Zawartość

| Ścieżka | Co to jest |
|---|---|
| `reproduce.py` | **jeden skrypt do wszystkiego**: kroki od sprawdzenia środowiska do porównania z wzorcem |
| `recipe_v3.json` | dokładne ustawienia treningu v3 i dwa modele bazowe do wyboru: `e4b` (wzorzec) i `e2b` (mniejszy, opcja) |
| `AGENTS.md` | przewodnik dla każdego agenta (Codex, Cursor, Claude Code): zasady, który dokument do czego |
| `CLAUDE.md` | to samo dla Claude Code (importuje `AGENTS.md`) |
| `CLOUD_GPU.md` | instrukcja dla agenta: trening w chmurze (Hugging Face Jobs albo Colab przez serwer MCP) |
| `MLX_MIGRATION.md` | instrukcja dla agenta: silnik MLX na Maca, krok po kroku z testami zgodności |
| `cloud/hf_job.sh` | skrypt uruchamiany w chmurze przez Hugging Face Jobs |
| `colab_v3.ipynb` | notatnik do Google Colab (A100 albo L4) |
| `src/party_tagger/` | kod modelu: wczytanie Gemmy, głowice, dekodowanie, routing, generator danych |
| `scripts/` | kroki procesu: dane, trening, ocena, kalibracja, eksport, bramka jakości |
| `data/generated/*.jsonl.gz` | dane treningowe i testowe (ok. 20 MB po kompresji), `data/SHA256SUMS` = sumy kontrolne |
| `data/handcrafted.txt` | 30 pól napisanych ręcznie (trudne przypadki) |
| `expected/` | wyniki wzorcowego v3: `metrics.json`, `routing_metrics.json`, `meta.json`, raporty, dziennik treningu |
| `tests/` | testy kodu (`pytest`) |

## Proces w 9 krokach (wszystkie robi `reproduce.py`)

| Krok | Co się dzieje | Czas (A100) |
|---|---|---|
| `env` | wersje Pythona i bibliotek, jaka karta, ile pamięci | sekundy |
| `model` | pobranie modelu bazowego do `models/` (E4B 16 GB, E2B 10,3 GB) | 3–10 min |
| `data` | rozpakowanie danych i sprawdzenie sum kontrolnych (albo `--regenerate-data`: zbudowanie od nowa generatorem) | < 1 min (generator: ok. 1 min) |
| `train` | trening LoRA + głowic, 3125 kroków | ok. 40–70 min (szacunek) |
| `evaluate` | kalibracja temperatury, progi z gwarancją, wyniki na 5 zbiorach testowych | 3–5 min |
| `calibrate` | progi routingu (agent nazw, agent geo, szum) | 2–4 min |
| `export` | folder gotowy do wysłania na Hugging Face (nic nie jest wysyłane) | 1 min |
| `gate` | bramka jakości: 12 kryteriów, które przeszedł wzorcowy v3 | sekundy |
| `compare` | tabela: wzorcowy v3 kontra ten trening, zapis w `runs/v3_repro/compare.md` | sekundy |

Każdy krok, który już ma wynik, jest pomijany. Po zerwaniu sesji wystarczy uruchomić skrypt jeszcze raz.

## A. Google Colab (A100 albo L4), ręcznie

Gdy pracuje za Ciebie agent, prowadzi go `CLOUD_GPU.md`. Poniżej wersja do samodzielnego klikania.

1. Wgraj `payment-party-tagger-training.zip` na swój Dysk Google (np. do `MyDrive/`).
2. Otwórz w Colab plik `colab_v3.ipynb` (Plik → Prześlij notatnik) i wybierz środowisko **GPU A100**
   (Środowisko wykonawcze → Zmień typ środowiska).
3. Uruchamiaj komórki po kolei. Notatnik:
   - podłącza Dysk, żeby wyniki przetrwały rozłączenie sesji;
   - rozpakowuje paczkę i instaluje biblioteki (torch w Colab już jest);
   - uruchamia `reproduce.py --profile fast` i pokazuje porównanie z wzorcem;
   - model bazowy i profil wybierasz na górze notatnika: `BASE = 'e4b'` albo `'e2b'`, `PROFILE = 'fast'` (A100) albo
     `'v3'` (L4). Karta T4 z darmowego Colab się nie nadaje (brak sprzętowej obsługi bf16).
4. Model bazowy jest na licencji Apache 2.0 i nie wymaga logowania. Logowanie (`hf auth login`) jest potrzebne dopiero
   do wysyłki wyniku na Hugging Face.

Profil `fast` daje tę samą efektywną paczkę (32 pola na krok), ale liczy ją w jednym przebiegu i bez oszczędzania pamięci.
Na A100 to wyraźnie szybsze. Wynik jest równoważny, choć nie identyczny bit w bit (punkt „Czego się spodziewać”).

## B. MacBook Pro (Apple silicon, M5)

Wymagania: macOS 14 lub nowszy, **co najmniej 32 GB pamięci zunifikowanej** (24 GB może nie wystarczyć, 16 GB na pewno
nie wystarczy), ok. 40 GB wolnego dysku. Przy mniejszej pamięci: mniejszy model, punkt D (`--model e2b`).

```bash
cd payment-party-tagger-training
python3.12 -m venv .venv && source .venv/bin/activate
pip install torch
pip install -r requirements.txt
python reproduce.py --smoke      # najpierw szybki test całego procesu (wyniki bez znaczenia)
python reproduce.py              # pełny trening
```

- Model liczy na karcie graficznej Maca (MPS). Skrypt sam to wykrywa i ustawia `PYTORCH_ENABLE_MPS_FALLBACK=1`.
- Trening na Macu będzie **kilka razy wolniejszy** niż na A100. Nie mierzyłem tego; licz się z kilkoma godzinami.
  Mac dobrze nadaje się do uruchamiania gotowego modelu i testów, a do treningu lepszy jest Colab.
- Ścieżka bez CUDA jest sprawdzona na procesorze (trening, ocena, kalibracja, predykcja na małym modelu testowym).
  Na prawdziwym Macu nie była uruchamiana, więc zacznij od `--smoke`.

## C. Linux lub Windows z kartą NVIDIA

```bash
python -m venv .venv
# Linux: source .venv/bin/activate      Windows: .venv\Scripts\activate
pip install torch --index-url https://download.pytorch.org/whl/cu130   # dobierz do sterownika: https://pytorch.org
pip install -r requirements.txt
python reproduce.py                      # karta 16 GB (jak RTX 4080): profil v3
python reproduce.py --profile fast       # karta 40 GB i więcej
```

## D. Mniejszy model: Gemma 4 E2B (opcja, jeszcze nietrenowana)

Ten sam przepis można uruchomić na mniejszej siostrze E4B, czyli `google/gemma-4-E2B-it`:
ok. 2,3 mld parametrów efektywnie, 5,1 mld z osadzeniami warstwowymi, 10,3 GB do pobrania, Apache 2.0, bez logowania.

```bash
python reproduce.py --model e2b --dry-run    # co by się stało, bez pobierania i liczenia
python reproduce.py --model e2b --smoke      # szybki test całego procesu (pobiera E2B, 10,3 GB)
python reproduce.py --model e2b              # pełny trening
```

| | E4B (wzorzec v3) | E2B |
|---|---|---|
| Model bazowy | `models/gemma-4-E4B-it` (16 GB) | `models/gemma-4-E2B-it` (10,3 GB) |
| Wyniki | `runs/v3_repro/` | `runs/e2b_repro/` |
| Eksport | `publish/payment-party-tagger-gemma4-e4b/` | `publish/payment-party-tagger-gemma4-e2b/` |
| Pamięć do treningu (Mac) | ok. 32 GB | ok. 20–24 GB (szacunek) |
| Pamięć do uruchamiania | ok. 10 GB | ok. 6 GB (szacunek) |
| Jakość | znana (tabela niżej) | **nieznana**; prawdopodobnie niższa, zwłaszcza dla krajów spoza treningu |

- **Ustawienia treningu są te same co dla E4B.** Rozmiar głowic kod odczytuje z modelu, więc nic nie trzeba zmieniać.
  To rozsądny punkt startu, ale nie były dobierane pod E2B.
- **Porównanie (`compare`)** pokazuje różnicę względem wzorcowego E4B tylko orientacyjnie, bo E2B nie ma jeszcze własnego wzorca.
  O tym, czy model jest dość dobry, decyduje bramka jakości (`gate`) z tymi samymi 12 kryteriami.
- **Status:** opcja dodana 2026-10-26 bez pobierania E2B; sprawdzone tylko `--dry-run`. Pierwsze prawdziwe uruchomienie
  zacznij od `--smoke`.

## Przydatne opcje

```bash
python reproduce.py --dry-run                   # plan wszystkich kroków bez pobierania i liczenia
python reproduce.py --model e2b                 # mniejszy model bazowy (punkt D)
python reproduce.py --steps env,model,data      # tylko przygotowanie
python reproduce.py --steps train --force       # trening od nowa
python reproduce.py --regenerate-data           # dane z generatora zamiast z paczki (sprawdzi, czy wyszły identyczne)
python reproduce.py --run runs/moj_trening      # inny folder wyników
python -m pytest -q                             # testy kodu (potrzebny pobrany model bazowy: używają jego tokenizera)
```

Wybór urządzenia można wymusić zmienną środowiskową `TAGGER_DEVICE=cuda|mps|cpu`.

## Czego się spodziewać

Wyniki wzorcowego v3 (RTX 4080, 2026-10-21):

| Zbiór | Pól | Pole w 100% poprawne (nazwa/adres/szum) | Wszystkie etykiety poprawne | Treść zgubiona przez routing |
|---|---|---|---|---|
| zwykłe, kraje treningowe | 1000 | 99.6% | 98.8% | 0.00% |
| kraje spoza treningu (PT, RO) | 1000 | 96.5% | 88.9% | 0.00% |
| trudne + uszkodzone | 1000 | 98.0% | 91.8% | 0.01% |
| trudne, kraje spoza treningu | 1000 | 95.6% | 87.1% | 0.00% |
| ręczne (30 pól) | 30 | 100.0% | 93.3% | 0.00% |

- **Kryterium sukcesu** (`compare`): na każdym dużym zbiorze testowym wynik „pole w 100% poprawne (nazwa/adres/szum)”
  nie gorszy od wzorca o więcej niż 1 punkt procentowy, a bramka jakości (`gate`) przechodzi.
- **Dlaczego nie bit w bit:** inne karty i biblioteki liczą sumy zmiennoprzecinkowe w innej kolejności. Po 3125 krokach
  daje to różnice rzędu dziesiątych części punktu procentowego. Dane i ustawienia są natomiast identyczne (sumy kontrolne).

## Publikacja wyniku (opcjonalnie)

Krok `export` tworzy `publish/payment-party-tagger-gemma4-e4b/`, ale niczego nie wysyła. Wysyłka do prywatnego repozytorium:

```bash
hf auth login
hf upload msw1410/payment-party-tagger-gemma4-e4b publish/payment-party-tagger-gemma4-e4b .
```

Uwaga: to nadpisze pliki w istniejącym repozytorium modelu. Do porównań lepiej użyć nowego repozytorium,
np. `hf repos create msw1410/payment-party-tagger-gemma4-e4b-repro --private`.

## Gdy coś nie działa

| Objaw | Co zrobić |
|---|---|
| `CUDA out of memory` na karcie 16 GB | profil `v3` (nie `fast`); zamknij inne programy korzystające z karty |
| Mac: brak pamięci albo bardzo wolno | sprawdź, ile masz pamięci (`env` to pokazuje); przy 24 GB i mniej użyj Colab albo `--model e2b` |
| `data does not match SHA256SUMS` | uruchom bez `--regenerate-data` (dane z paczki); sprawdź wersję `faker` |
| Colab rozłączył sesję | uruchom komórkę z `reproduce.py` jeszcze raz: gotowe kroki zostaną pominięte. Trening przerwany w połowie zaczyna się od nowa |
| Błąd przy wczytaniu Gemmy | sprawdź `transformers==5.19.0` (`pip install -r requirements.txt`) |
