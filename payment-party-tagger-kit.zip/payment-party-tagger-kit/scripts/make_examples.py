"""Write request/response example pairs for the training package from a real run (nothing is typed by hand).

    python scripts/make_examples.py --run runs/v3      # -> packaging/kit/examples/

request_<name>.json: what a caller sends (only the field text; the tag is optional and not used by the model).
response_<name>.json: exactly what Predictor.predict() returns for that text (char_labels left out: spans hold the same).
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from party_tagger.infer import Predictor  # noqa: E402

FIELDS = {
    "50K_care_of": ("50K", "BALTIC TIMBER TRADING LTD\nC/O ALPHA CORPORATE SERVICES LTD\n2 ARCH MAKARIOS III AVE\n1065 NICOSIA CYPRUS"),
    "59F_line_codes": ("59F", "1/IVAN SOKOLOV\n2/C/O OOO VEKTOR LOGISTIK\n2/UL TVERSKAYA 7\n3/RU/MOSCOW"),
    "59_account_attn_split_word": ("59", "/PL61109010140000071219812874\nJAN KOWALSKI TRADING SP. Z O.O.\n"
                                         "UL. MARSZALKOWSKA 142/5 00-061 WARS\nZAWA POLAND ATTN ACCOUNTS DEPT"),
    "50K_garbage_placeholder": ("50K", "ACME TRADING LTD %@#$^$#\nATTN JOHN SMITH\n10 HIGH STREET\nLONDON NOTPROVIDED"),
}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", default="runs/v3")
    ap.add_argument("--out", default="examples")
    args = ap.parse_args()
    out = ROOT / args.out
    out.mkdir(parents=True, exist_ok=True)
    pred = Predictor(ROOT / args.run)
    pred.predict("WARM UP\nLONDON")  # the first call pays for kernel set-up; keep it out of latency_ms
    for name, (tag, text) in FIELDS.items():
        response = pred.predict(text)
        response.pop("char_labels", None)
        (out / f"request_{name}.json").write_text(json.dumps({"tag": tag, "text": text}, indent=2, ensure_ascii=False) + "\n",
                                                  encoding="utf-8", newline="\n")
        (out / f"response_{name}.json").write_text(json.dumps(response, indent=2, ensure_ascii=False) + "\n",
                                                   encoding="utf-8", newline="\n")
        print(f"{name}: {response['latency_ms']} ms, review={response['routing']['review']}")


if __name__ == "__main__":
    main()
