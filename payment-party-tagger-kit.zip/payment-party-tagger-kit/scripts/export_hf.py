"""Build a folder ready for the Hugging Face Hub from a training run. Nothing is uploaded here.

    python scripts/export_hf.py --run runs/v3 --repo msw1410/payment-party-tagger-gemma4-e4b

publish/<name>/ gets: model card (README.md), LoRA adapter, heads (safetensors, no pickle), meta.json pointing at the
base model on the Hub, the Python package (as party_tagger), predict.py, requirements.txt, LICENSE, NOTICE and example
outputs produced by the exported folder itself (so the card shows what the published files really do).
"""

from __future__ import annotations

import argparse
import importlib.metadata
import json
import re
import shutil
import sys
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from party_tagger.labels import COARSE, ISO_ELEMENT  # noqa: E402

PACKAGE = "party_tagger"
BASE_ON_HUB = {"gemma-4-E4B-it": "google/gemma-4-E4B-it", "gemma-4-E2B-it": "google/gemma-4-E2B-it",
               "gemma-4-12B-it": "google/gemma-4-12B-it"}
# memory needed to run the model: measured for E4B, estimated for the others
RUN_MEMORY = {"google/gemma-4-E4B-it": "about 10 GB", "google/gemma-4-E2B-it": "roughly 6 GB (estimate)",
              "google/gemma-4-12B-it": "about 10 GB in 4-bit (estimate)"}
EXAMPLES = [
    "BALTIC TIMBER TRADING LTD\nC/O ALPHA CORPORATE SERVICES LTD\n2 ARCH MAKARIOS III AVE\n1065 NICOSIA CYPRUS",
    "1/IVAN SOKOLOV\n2/C/O OOO VEKTOR LOGISTIK\n2/UL TVERSKAYA 7\n3/RU/MOSCOW",
    "/PL61109010140000071219812874\nJAN KOWALSKI TRADING SP. Z O.O.\nUL. MARSZALKOWSKA 142/5 00-061 WARS\nZAWA POLAND ATTN ACCOUNTS DEPT",
]
SETS = {
    "test": "Synthetic, training countries",
    "test_heldout": "Synthetic, countries never seen in training (PT, RO)",
    "test_hard": "Synthetic, harder layouts + damage (typos, junk, missing spaces)",
    "test_hard_heldout": "Hard + damage, unseen countries",
    "handcrafted": "Hand-written fields",
}
DESCRIPTION = {
    "NAME_PERSON": "name of a person",
    "NAME_ORG": "name of an organisation, legal form included (also a department after ATTN)",
    "PARTY_INTRO": "word that introduces a party or contact: C/O, ATTN, OBO, FFC, T/A, BENEFICIARY",
    "PARTY_ID": "identifier or contact detail of the party: TEL, VAT, BIC, date of birth, passport, reference",
    "STREET": "street name",
    "BUILDING": "building number, also ranges such as 142/144",
    "UNIT": "flat, suite, floor, room",
    "POSTCODE": "postal code",
    "TOWN": "town or city",
    "REGION": "state, province, region",
    "COUNTRY": "country name or code",
    "PO_BOX": "post office box",
    "ACCOUNT": "account line (IBAN, domestic number, //FW...)",
    "LINE_PREFIX": "50F/59F line codes 1/ 2/ 3/ ...",
    "NOISE": "garbage and placeholders only (%@#$, ===, NOTPROVIDED, N/A)",
}
ISO = dict(ISO_ELEMENT, NAME_PERSON="Nm", NAME_ORG="Nm", PARTY_ID="Id / CtctDtls")
GROUP = {"NAME": "who: name agent", "ADDRESS": "where: geo agent", "NOISE": "ignored"}


def pct(x) -> str:
    return "–" if x is None else f"{100 * x:.1f}%"


def copy_package(out: Path) -> None:
    dst = out / PACKAGE
    dst.mkdir(parents=True)
    for src in sorted((ROOT / "src" / "party_tagger").glob("*.py")):
        code = src.read_text(encoding="utf-8")
        code = re.sub(r"\bfrom party_tagger\b", f"from {PACKAGE}", code)
        code = re.sub(r"\bimport party_tagger\b", f"import {PACKAGE}", code)
        if src.name == "__init__.py":
            code = '"""Token tagger that splits a payment party field into name (who) and postal address (where)."""\n'
        (dst / src.name).write_text(code, encoding="utf-8")


def copy_weights(run: Path, out: Path, base_id: str) -> None:
    import torch
    from safetensors.torch import save_file

    shutil.copytree(run / "adapter", out / "adapter", ignore=shutil.ignore_patterns("README.md"))  # PEFT's empty template
    cfg_path = out / "adapter" / "adapter_config.json"
    cfg = json.loads(cfg_path.read_text(encoding="utf-8"))
    cfg["base_model_name_or_path"] = base_id
    cfg_path.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
    if (run / "heads.safetensors").exists():  # a run downloaded from the Hub (reproduce.py --published) has no pickle file
        shutil.copy(run / "heads.safetensors", out / "heads.safetensors")
        return
    heads = torch.load(run / "heads.pt", map_location="cpu")
    flat = {f"{h}.{k}": v.contiguous() for h, sd in heads.items() for k, v in sd.items()}
    save_file(flat, out / "heads.safetensors")


def apache_license() -> str:
    for pkg in ("safetensors", "peft", "accelerate"):
        dist = importlib.metadata.distribution(pkg)
        for f in dist.files or []:
            if f.name == "LICENSE":
                text = Path(dist.locate_file(f)).read_text(encoding="utf-8")
                if "Apache License" in text and "Version 2.0" in text:
                    return text
    raise RuntimeError("no Apache 2.0 license text found in the installed packages")


def run_examples(out: Path, base_local: str | None) -> list[dict]:
    sys.path.insert(0, str(out))
    from party_tagger.infer import Predictor  # the exported copy, not src/party_tagger

    pred = Predictor(out, base_local)
    outs = [pred.predict(t) for t in EXAMPLES]
    for o in outs:
        o.pop("tokens", None)
        o.pop("char_labels", None)
    return outs


def short(o: dict) -> dict:
    r = o["routing"]
    return {
        "name_agent": {"entities": r["name_agent"]["entities"], "identifiers": r["name_agent"]["identifiers"]},
        "geo_agent": {"text": r["geo_agent"]["text"], "iso20022_hint": r["geo_agent"]["iso20022_hint"],
                      "care_of": r["geo_agent"]["care_of"]},
        "ignored": [p["value"] for p in r["ignored"]],
        "review": r["review"],
    }


def model_card(repo: str, meta: dict, metrics: dict, routing: dict | None, examples: list[dict], draft: bool) -> str:
    name = repo.split("/")[-1]
    base = meta["base_model"]
    labels = [lbl for lbl in meta["labels"] if lbl != "O"]
    train = meta.get("train", {})
    th = (meta.get("routing") or {}).get("thresholds") or {}
    lat = metrics.get("latency", {})
    L = []
    add = L.append
    add("---")
    add("license: apache-2.0")
    add(f"base_model: {base}")
    add("base_model_relation: adapter")
    add("library_name: peft")
    add("pipeline_tag: token-classification")
    add("language:\n- en")
    add("tags:\n- token-classification\n- payments\n- swift\n- iso20022\n- cbpr-plus\n- name-address-splitting\n"
        "- sanctions-screening\n- lora\n- gemma4")
    add("---\n")
    add(f"# {name}\n")
    if draft:
        add("> **DRAFT** – generated from an internal run for review; numbers below are not final.\n")
    add("Splits the content of **one party field of a payment message** (SWIFT MT `50K`, `59`, `50F`, `59F`) into "
        "**who** (the party's name) and **where** (its postal address), word by word, in **one forward pass**, with "
        "calibrated probabilities and a routing decision for every word.\n")
    add("It is a discriminative tagger (no text generation): a Gemma 4 backbone with bidirectional attention, a LoRA "
        "adapter and two small classification heads.\n")
    add("> Trained on **synthetic data only**. This is a pre-processing component for name screening and "
        "geographic screening, **not** a sanctions screening system.\n")

    add("## Why\n")
    add("Many systems flatten structured names and addresses into free text lines (4 × 35 characters in MT messages). "
        "Under CBPR+ (from November 2026) payment messages need structured or hybrid postal addresses (at least town and "
        "country), and screening works best when names and addresses are checked separately. The model reverses the "
        "flattening without assuming any order: the name may come after the address, lines may be cut in the middle of a "
        "word, separators may be missing.\n")

    add("## Example\n")
    add("Input (content of `:50K:`; the tag itself is found by a deterministic parser):\n")
    add("```\n" + EXAMPLES[0] + "\n```\n")
    if examples:
        add("Output (shortened; the full JSON also has per-word probabilities, spans and line-break decisions):\n")
        add("```json\n" + json.dumps(short(examples[0]), indent=2, ensure_ascii=False) + "\n```\n")
        add(f"Field `59F` with a line code glued to `C/O` (`2/C/O`):\n\n```\n{EXAMPLES[1]}\n```\n")
        add("```json\n" + json.dumps(short(examples[1]), indent=2, ensure_ascii=False) + "\n```\n")
        add("`example_output.json` in this repository holds the complete outputs for these and one more field.\n")

    add("## Labels\n")
    add("| Label | Group | ISO 20022 | Meaning |")
    add("|---|---|---|---|")
    for lbl in labels:
        add(f"| `{lbl}` | {GROUP[COARSE[lbl]]} | {ISO.get(lbl, '–')} | {DESCRIPTION.get(lbl, '')} |")
    add("")
    add("Principle: everything about the party that is not its postal address (name, identifiers, contact details) is "
        "**who**; the postal address is **where**. Noise is reserved for garbage and placeholders.\n")

    add("## How a word is routed\n")
    add("1. **Model**: one forward pass gives each token a probability for every label (temperature-calibrated on "
        "held-out data) and, at each line break, the probability that a word continues on the next line.")
    add(f"2. **Noise or content**: a word is dropped only if P(noise) > {max(0.95, th.get('noise', 0.95)):.2f} **and** it "
        "has no letter or digit, is a placeholder (NOTPROVIDED, N/A, NONE, TBC), or is structure recognised by rules "
        "(account line, IBAN with a valid mod-97 checksum, `1/`–`8/` line codes). Any other word reaches an agent, even "
        "when the model calls it noise (flag `kept_by_guard`).")
    if th:
        add(f"3. **Name or address**: P(name | content) ≥ {th['name']:.3f} → name agent, P(address | content) ≥ "
            f"{th['address']:.3f} → geo agent; when neither or both pass, the word goes to **both** agents (flag "
            "`ambiguous`). Thresholds are class-conditional conformal quantiles from calibration data "
            f"(policy: {meta['routing']['alpha'] * 100:.1f}% allowed miss rate per class).")
    else:
        add("3. **Name or address**: the most probable group; uncertain words go to both agents.")
    add("4. **Rules**: C/O, ATTN, OBO, FFC and T/A are recognised as markers; the party after `C/O` is sent to "
        "**both** agents (flag `care_of`), because a screening hit may concern the party or the place. The name agent "
        "receives separate `entities` with roles (`party`, `care_of`, `attention`, `on_behalf_of`, `further_credit`, "
        "`trading_as`).")
    add("5. **Review**: fields with words that are both doubtful content and of unclear owner, or with field confidence "
        "below the automation threshold, get `review: true` and `review_reasons`.\n")

    add("## Usage\n")
    add(f"Runs on an NVIDIA GPU (CUDA), Apple silicon (MPS) or, slowly, on the CPU; needs {RUN_MEMORY.get(base, 'a GPU')} "
        "of GPU memory and Python 3.11+.\n")
    add("```bash\npip install torch   # with CUDA: see pytorch.org\npip install -r requirements.txt\n```\n")
    add("```python\nimport sys\nfrom huggingface_hub import snapshot_download\n\n"
        f'path = snapshot_download("{repo}")\nsys.path.insert(0, path)\n'
        f"from {PACKAGE}.infer import Predictor\n\n"
        f"tagger = Predictor(path)  # downloads {base} on first use\n"
        'out = tagger.predict("BALTIC TIMBER TRADING LTD\\nC/O ALPHA CORPORATE SERVICES LTD\\n'
        '2 ARCH MAKARIOS III AVE\\n1065 NICOSIA CYPRUS")\n'
        'print(out["routing"]["name_agent"]["entities"])\nprint(out["routing"]["geo_agent"]["iso20022_hint"])\n```\n')
    add("Or from the command line: `python predict.py \"LINE 1|LINE 2|LINE 3\"` (`|` separates lines).\n")

    add("## Training\n")
    add(f"- Base model: [{base}](https://huggingface.co/{base}), causal mask replaced by bidirectional attention "
        "(every token sees the whole field), as in LS-unLLaMA.")
    lora = meta.get("lora", {})
    add(f"- LoRA r={lora.get('r')}, alpha={lora.get('alpha')} on {', '.join(lora.get('targets', []))}; "
        "heads: token label + word-continues-after-line-break.")
    if train:
        add(f"- {train.get('examples', '?'):,} synthetic fields, {train.get('steps', '?'):,} steps, batch {train.get('bs')}"
            + (f" × {train['grad_accum']}" if train.get("grad_accum", 1) > 1 else "")
            + f", learning rate {train.get('lr')}, {train.get('minutes', '?')} min on one {train.get('device', 'RTX 4080 (16 GB)')}.")
    add("- Data (generator included: `party_tagger/swiftgen.py`, `party_tagger/corrupt.py`): fictional names and "
        "addresses from Faker for 32 locales plus hand-written lists (legal forms, street abbreviations, intermediaries "
        "such as corporate service providers, hotels and law firms); 5 layouts (natural lines, hard 35-character wrap "
        "with words cut at line ends, glued text, F-format with `1/ 2/ 3/` codes, name line + glued address); second "
        "parties after C/O, ATTN, OBO, FFC, T/A; identifiers; garbage; 13 kinds of damage (typos, missing spaces, junk "
        "inside names, duplicates, truncation...). Labels are computed by the generator, so they are exact. "
        "**No real payment messages and no real personal data were used.**\n")

    add("## Evaluation\n")
    add("All numbers are on synthetic or hand-written data; expect lower accuracy on real traffic and evaluate on "
        "your own data before use.\n")
    add("| Set | Fields | Name / address / noise right in the whole field | Every label right in the whole field | "
        "Characters right | Line-break joins right |")
    add("|---|---|---|---|---|---|")
    for key, title in SETS.items():
        m = metrics["sets"].get(key)
        if m:
            add(f"| {title} | {m['fields']} | {pct(m.get('field_exact_coarse'))} | {pct(m.get('field_exact_fine'))} | "
                f"{pct(m.get('char_accuracy_fine'))} | {pct(m.get('join_accuracy'))} |")
    add("")
    policy = (meta.get("routing") or {}).get("policy")
    if routing and policy:
        add(f"Routing with the default policy (letters and digits; a word sent to both agents counts as received by both):\n")
        add("| Set | Name words reaching the name agent | Address words reaching the geo agent | Content sent to both "
            "| Content dropped | Fields with nothing lost |")
        add("|---|---|---|---|---|---|")
        for key, title in SETS.items():
            r = (routing.get("results", {}).get(key) or {}).get(policy)
            if r:
                add(f"| {title} | {pct(r['name_recall'])} | {pct(r['address_recall'])} | {pct(r['content_sent_to_both'])} | "
                    f"{pct(r['content_dropped'])} | {pct(r['fields_lossless'])} |")
        add("")
    if lat:
        add(f"Speed on one {lat.get('device', 'RTX 4080')}: {lat.get('single_p50_ms')} ms per field (median, one at a time), "
            f"{lat.get('batch32_fields_per_s')} fields/s in batches of 32.\n")

    add("## Conventions worth knowing\n")
    add("- `ATTN JOHN SMITH` and `ATTN ACCOUNTS DEPT` are on the name side. ISO 20022 keeps a contact person in "
        "`CtctDtls/Nm` and a department in `PstlAdr/Dept`; this split is about who vs where, not the final ISO mapping.")
    add("- `C/O <party>`: marker and party go to both agents. CBPR+ has no CareOf element; in a hybrid address it would "
        "be an address line.")
    add("- `142/5` = building 142, flat 5; `142/144` or `142/144/146` (ascending, at most 6 apart) = one building "
        "spanning several numbers; Czech/Slovak `1079/3A` = building number.")
    add("- 50F lines `4/`–`7/` (date and place of birth, customer and national ids) are identifiers, so they are on the "
        "name side even when they contain a town.\n")

    add("## Limitations\n")
    add("- Synthetic training data; real fields contain formats the generator does not know.")
    add("- Latin script and the SWIFT X character set (upper case); one field at a time, up to 4 lines (5 with the account).")
    add("- Calibration and thresholds were fitted on synthetic data; their guarantees hold only for data like it.")
    add("- The output is an input to screening and to address structuring; decisions about people must not rest on it "
        "alone.\n")

    add("## License and credits\n")
    add(f"Adapter, heads and code: Apache 2.0. Base model: [{base}](https://huggingface.co/{base}) by Google, "
        "Apache 2.0 ([Gemma 4 license](https://ai.google.dev/gemma/docs/gemma_4_license)); its weights are not included "
        "here.\n")
    add("- Z. Li et al., *Label Supervised LLaMA Finetuning* (LS-LLaMA / LS-unLLaMA), arXiv:2310.01208: removing the "
        "causal mask for token classification.")
    add("- [basal](https://github.com/rkinas/basal) by Remigiusz Kinas: discriminative decision models on top of an LLM, "
        "calibrated outputs, distillation recipe.")
    add("- [Faker](https://github.com/joke2k/faker) for fictional names and addresses.\n")
    return "\n".join(L)


FORBIDDEN = re.compile(r"(?<![A-Za-z])[A-Za-z]:\\[A-Za-z]|/User[s]/|\bhf_[A-Za-z0-9]{20,}|@gmail\.com", re.I)  # project name, local paths (drive letter + backslash + name), tokens, e-mail


def check_clean(out: Path, pattern: re.Pattern = FORBIDDEN) -> None:
    """Refuse to leave a folder that leaks the internal project name, local paths, tokens or an e-mail address."""
    bad = []
    for f in out.rglob("*"):
        if f.is_file() and f.suffix in (".py", ".json", ".md", ".txt", "") and f.stat().st_size < 5_000_000:
            for n, line in enumerate(f.read_text(encoding="utf-8", errors="ignore").splitlines(), 1):
                if pattern.search(line):
                    bad.append(f"{f.relative_to(out)}:{n}: {line.strip()[:100]}")
    if bad:
        raise SystemExit("not clean for publishing:\n" + "\n".join(bad))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", required=True)
    ap.add_argument("--repo", default="msw1410/payment-party-tagger-gemma4-e4b")
    ap.add_argument("--out", default=None, help="default: publish/<repo name>")
    ap.add_argument("--base-local", default=None, help="local copy of the base model for the example run (default: from meta)")
    ap.add_argument("--no-examples", action="store_true", help="skip the GPU run that produces the example outputs")
    ap.add_argument("--draft", action="store_true", help="mark the model card as a draft")
    args = ap.parse_args()

    run = ROOT / args.run
    meta = json.loads((run / "meta.json").read_text(encoding="utf-8"))
    metrics = json.loads((run / "metrics.json").read_text(encoding="utf-8"))
    routing = json.loads((run / "routing_metrics.json").read_text(encoding="utf-8")) if (run / "routing_metrics.json").exists() else None
    local_base = meta["base_model"]
    base_id = BASE_ON_HUB.get(Path(local_base).name, local_base)
    out = ROOT / (args.out or f"publish/{args.repo.split('/')[-1]}")
    if out.exists():
        shutil.rmtree(out)
    out.mkdir(parents=True)

    copy_package(out)
    copy_weights(run, out, base_id)
    meta_out = dict(meta, base_model=base_id, export={"repo": args.repo, "date": date.today().isoformat(), "run": run.name})
    (out / "meta.json").write_text(json.dumps(meta_out, indent=2), encoding="utf-8")
    (out / "requirements.txt").write_text(
        "torch>=2.6  # CUDA build, see https://pytorch.org\ntransformers>=5.19\npeft>=0.21\naccelerate>=1.15\n"
        "safetensors>=0.5\nnumpy\nfaker  # used by the data generator, imported by the country list\nhuggingface_hub\n",
        encoding="utf-8")
    (out / "predict.py").write_text(
        '"""Example: python predict.py "BALTIC TIMBER TRADING LTD|C/O ALPHA CORPORATE SERVICES LTD|NICOSIA CYPRUS"'
        ' (| separates lines)."""\n\nimport json\nimport sys\nfrom pathlib import Path\n\n'
        "HERE = Path(__file__).parent\nsys.path.insert(0, str(HERE))\n\n"
        f"from {PACKAGE}.infer import Predictor  # noqa: E402\n\n"
        'text = (sys.argv[1] if len(sys.argv) > 1 else "ACME TRADING LTD|ATTN JOHN SMITH|10 HIGH STREET|LONDON GB").replace("|", "\\n")\n'
        'out = Predictor(HERE).predict(text)\nprint(json.dumps(out["routing"], indent=2, ensure_ascii=False))\n',
        encoding="utf-8")
    (out / "LICENSE").write_text(apache_license(), encoding="utf-8")
    (out / "NOTICE").write_text(
        f"{args.repo.split('/')[-1]}\nCopyright {date.today().year} {args.repo.split('/')[0]}\n\n"
        f"This repository contains a LoRA adapter, classification heads and code for {base_id} (Google),\n"
        "which is licensed under the Apache License, Version 2.0 (https://ai.google.dev/gemma/docs/gemma_4_license).\n"
        f"The base model weights are not included; they are downloaded from https://huggingface.co/{base_id}.\n",
        encoding="utf-8")

    examples = [] if args.no_examples else run_examples(out, args.base_local or str(ROOT / local_base))
    if examples:
        (out / "example_output.json").write_text(json.dumps(
            [{"input": t, "output": o} for t, o in zip(EXAMPLES, examples)], indent=2, ensure_ascii=False), encoding="utf-8")
    (out / "README.md").write_text(model_card(args.repo, meta_out, metrics, routing, examples, args.draft), encoding="utf-8")

    check_clean(out)
    size = sum(f.stat().st_size for f in out.rglob("*") if f.is_file())
    print(f"{out}  ({size / 2**20:.0f} MB)")
    for f in sorted(out.rglob("*")):
        if f.is_file():
            print(f"  {f.relative_to(out)}  {f.stat().st_size / 1024:.0f} KB")


if __name__ == "__main__":
    main()
