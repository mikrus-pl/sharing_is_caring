"""Calibrate and evaluate a trained run; writes report.md, metrics.json and handcrafted_review.md into the run.

Usage: .venv/Scripts/python scripts/evaluate.py --run runs/v0
"""

from __future__ import annotations

import argparse
import json
import statistics
import time
from datetime import date
from pathlib import Path

import torch
import torch.nn.functional as F

from party_tagger.device import DEVICE, ENGINE, PRECISION, device_name, synchronize
from party_tagger.data import IGNORE, encode_example, load_jsonl
from party_tagger.infer import Predictor
from party_tagger.labels import COARSE
from party_tagger.metrics import certified_threshold, coverage, evaluate, field_correct, split_fit_cert

EVAL_SETS = {
    "test": "syntetyczny test (kraje z treningu)",
    "test_heldout": "syntetyczny test (kraje spoza treningu: PT, RO)",
    "handcrafted": "ręcznie napisane trudne przypadki",
    "test_hard": "trudne i uszkodzone (kraje z treningu + dodatkowe)",
    "test_hard_heldout": "trudne i uszkodzone (PT, RO)",
}


def fit_temperature(logits: torch.Tensor, targets: torch.Tensor) -> float:
    log_t = torch.zeros((), requires_grad=True)
    opt = torch.optim.LBFGS([log_t], lr=0.1, max_iter=200)

    def closure():
        opt.zero_grad()
        loss = F.cross_entropy(logits / log_t.exp(), targets)
        loss.backward()
        return loss

    opt.step(closure)
    return float(log_t.detach().exp())


def token_logits_by_example(pred: Predictor, examples):
    tl, tt, jl, jt = [], [], [], []
    for i in range(0, len(examples), 32):
        chunk = examples[i:i + 32]
        raws = pred.raw([ex.text for ex in chunk], temperature={"token": 1.0, "join": 1.0})
        for ex, (_, token_logits, join_logits) in zip(chunk, raws):
            enc = encode_example(ex, pred.tokenizer)
            labels, joins = torch.tensor(enc.labels), torch.tensor(enc.joins)
            tl.append(token_logits[labels != IGNORE]); tt.append(labels[labels != IGNORE])
            jl.append(join_logits[joins != IGNORE]); jt.append(joins[joins != IGNORE])
    return tl, tt, jl, jt


def calibrate(pred: Predictor, examples) -> dict:
    tl, tt, jl, jt = token_logits_by_example(pred, examples)
    return {"token": fit_temperature(torch.cat(tl), torch.cat(tt)), "join": fit_temperature(torch.cat(jl), torch.cat(jt))}


def ece(probs: torch.Tensor, targets: torch.Tensor, bins: int = 10) -> float:
    conf, guess = probs.max(-1)
    correct = (guess == targets).float()
    total = 0.0
    for b in range(bins):
        mask = (conf > b / bins) & (conf <= (b + 1) / bins)
        if mask.any():
            total += mask.float().mean().item() * abs(conf[mask].mean().item() - correct[mask].mean().item())
    return total


def leave_one_country_out(pred: Predictor, examples) -> dict:
    """Token calibration error on each country, with the temperature fitted on the other countries only."""
    tl, tt, _, _ = token_logits_by_example(pred, examples)
    countries = [ex.meta.get("group") or ex.meta.get("locale", "?") for ex in examples]
    out = {}
    for c in sorted(set(countries)):
        own = [i for i, k in enumerate(countries) if k == c]
        rest = [i for i, k in enumerate(countries) if k != c]
        if len(own) < 30 or not rest:
            continue
        t = fit_temperature(torch.cat([tl[i] for i in rest]), torch.cat([tt[i] for i in rest]))
        logits, targets = torch.cat([tl[i] for i in own]), torch.cat([tt[i] for i in own])
        out[c] = round(ece((logits / t).softmax(-1), targets), 4)
    worst = max(out, key=out.get) if out else None
    return {"per_country": out, "mean": round(sum(out.values()) / max(len(out), 1), 4), "max": out.get(worst), "worst": worst}


def heuristic(ex) -> dict:
    """Baseline: account line = noise, first other line = name, everything else = address."""
    chars = [None] * len(ex.text)
    pos, first_content = 0, True
    for k, line in enumerate(ex.text.split("\n")):
        label = "ACCOUNT" if k == 0 and line.startswith("/") else ("NAME_ORG" if first_content else "STREET")
        if label != "ACCOUNT":
            first_content = False
        for i in range(pos, pos + len(line)):
            if not ex.text[i].isspace():
                chars[i] = label
        pos += len(line) + 1
    return {"char_labels": chars, "joins": []}


def latency(pred: Predictor, text: str) -> dict:
    for _ in range(5):
        pred.predict(text)
    single = [pred.predict(text)["latency_ms"] for _ in range(30)]
    texts = [text] * 32
    synchronize()
    t = time.perf_counter()
    for _ in range(5):
        pred.predict_many(texts)
    synchronize()
    per_batch = (time.perf_counter() - t) / 5
    return {"single_p50_ms": round(statistics.median(single), 1), "batch32_fields_per_s": round(32 / per_batch, 1),
            "device": device_name()}


def review(examples, outputs) -> str:
    lines = ["# Przegląd: ręcznie napisane przypadki", ""]
    for ex, out in zip(examples, outputs):
        ok = field_correct(ex, out["char_labels"], coarse=True)
        okf = field_correct(ex, out["char_labels"], coarse=False)
        lines.append(f"## #{ex.meta.get('id')} — {'✅' if ok else '❌'} nazwa/adres/szum, {'✅' if okf else '❌'} szczegółowe etykiety, pewność {out['confidence']}")
        lines += ["```", ex.text, "```", "| | etykieta | tekst |", "|---|---|---|"]
        gold = {(s["label"], s["text"].replace(chr(10), "⏎")) for s in ex.spans()}
        got = {(s["label"], s["text"].replace(chr(10), "⏎")) for s in out["spans"]}
        for lbl, txt in sorted(gold | got, key=lambda x: ex.text.find(x[1].replace("⏎", chr(10)))):
            mark = "✅" if (lbl, txt) in gold and (lbl, txt) in got else ("➖ brak (wzorzec)" if (lbl, txt) in gold else "➕ model")
            lines.append(f"| {mark} | {lbl} | `{txt}` |")
        r = out["result"]
        lines += ["", f"**Nazwa:** {r['name']}  ", f"**Adres:** {r['address']}  ", f"**Szum:** {r['noise']}  ",
                  f"**ISO 20022:** `{json.dumps(r['iso20022'], ensure_ascii=False)}`", ""]
    return "\n".join(lines)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", default="runs/v0")
    ap.add_argument("--data", default="data/generated")
    ap.add_argument("--calib-files", nargs="+", default=["calib.jsonl"])
    ap.add_argument("--sets", nargs="+", default=["test", "test_heldout", "handcrafted"])
    args = ap.parse_args()
    run, data = Path(args.run), Path(args.data)
    sets = {name: EVAL_SETS[name] for name in args.sets}

    pred = Predictor(run)
    calib = [ex for name in args.calib_files for ex in load_jsonl(data / name)]
    # FIT fits temperatures and certifies thresholds; CERT only reports (split by a stable hash, basal recipe)
    is_fit = split_fit_cert([ex.meta.get("uid") or ex.text for ex in calib])
    fit = [ex for ex, f in zip(calib, is_fit) if f]
    cert = [ex for ex, f in zip(calib, is_fit) if not f]
    temps = calibrate(pred, fit)
    pred.meta["temperature"] = temps
    meta_path = run / "meta.json"
    meta = json.loads(meta_path.read_text(encoding="utf-8"))
    meta["temperature"] = temps
    # calibration belongs to one engine, device type and precision; Predictor flags other machines as "unvalidated"
    meta["calibrated_on"] = {"engine": ENGINE, "backend": DEVICE, "device": device_name(), "precision": PRECISION,
                             "date": date.today().isoformat()}

    def conf_ok(examples):
        outs = pred.predict_many([ex.text for ex in examples])
        return [o["confidence"] for o in outs], [field_correct(ex, o["char_labels"], coarse=True) for ex, o in zip(examples, outs)]

    fit_conf, fit_ok = conf_ok(fit)
    thresholds = {t: certified_threshold(fit_conf, fit_ok, t) for t in (0.01, 0.05)}
    meta["thresholds"] = {"field_error_1pct": thresholds[0.01], "field_error_5pct": thresholds[0.05],
                          "method": "one-sided 95% Clopper-Pearson on FIT (70% of calibration fields); None = not certifiable"}
    meta_path.write_text(json.dumps(meta, indent=2), encoding="utf-8")
    cert_conf, cert_ok = conf_ok(cert)
    certification = {t: coverage(cert_conf, cert_ok, thresholds[t] if thresholds[t] is not None else 1.01) for t in (0.01, 0.05)}
    lofo = leave_one_country_out(pred, cert) if any(ex.meta.get("locale") for ex in cert) else None

    results = {"temperature": temps, "thresholds": meta["thresholds"], "calibration_split": {"fit": len(fit), "cert": len(cert)},
               "cert_check": {f"{int(t * 100)}pct": v for t, v in certification.items()}, "leave_one_country_out_ece": lofo, "sets": {}}
    for name in sets:
        examples = load_jsonl(data / f"{name}.jsonl")
        outputs = pred.predict_many([ex.text for ex in examples])
        m = evaluate(examples, outputs)
        conf = [o["confidence"] for o in outputs]
        ok = [field_correct(ex, o["char_labels"], coarse=True) for ex, o in zip(examples, outputs)]
        m["coverage_1pct"] = coverage(conf, ok, thresholds[0.01] if thresholds[0.01] is not None else 1.01)
        m["coverage_5pct"] = coverage(conf, ok, thresholds[0.05] if thresholds[0.05] is not None else 1.01)
        m["baseline_heuristic"] = {k: v for k, v in evaluate(examples, [heuristic(ex) for ex in examples]).items()
                                   if k in ("field_exact_coarse", "name_exact", "address_exact", "noise_exact")}
        results["sets"][name] = m
        if name == "handcrafted":
            (run / "handcrafted_review.md").write_text(review(examples, outputs), encoding="utf-8")
    results["latency"] = latency(pred, load_jsonl(data / "handcrafted.jsonl")[0].text)
    (run / "metrics.json").write_text(json.dumps(results, indent=2, ensure_ascii=False), encoding="utf-8")

    rep = [f"# Raport: {run.name}", "",
           f"Model: `{meta['base_model']}` + LoRA r={meta['lora']['r']}, atencja dwukierunkowa: {meta['bidirectional']}, "
           f"trening: {meta['train']['examples']} przykładów, {meta['train']['steps']} kroków, {meta['train']['minutes']} min.",
           f"Temperatury kalibracji: token {temps['token']:.3f}, łamanie linii {temps['join']:.3f}.", "",
           "| Metryka | " + " | ".join(sets) + " |", "|---|" + "---|" * len(sets)]
    rows = [("Pole w 100% poprawne: nazwa/adres/szum (litery i cyfry)", "field_exact_coarse"), ("Pole w 100% poprawne: szczegółowe etykiety (każdy znak)", "field_exact_fine"),
            ("Nazwa dokładnie", "name_exact"), ("Adres dokładnie", "address_exact"), ("Szum dokładnie", "noise_exact"),
            ("Trafność znaków (szczegółowe)", "char_accuracy_fine"), ("Sklejanie łamanych słów", "join_accuracy")]
    for title, key in rows:
        rep.append(f"| {title} | " + " | ".join(f"{results['sets'][s][key]:.1%}" for s in sets) + " |")
    rep.append("| Heurystyka: pole w 100% poprawne | " + " | ".join(f"{results['sets'][s]['baseline_heuristic']['field_exact_coarse']:.1%}" for s in sets) + " |")
    for t, key in (("1%", "coverage_1pct"), ("5%", "coverage_5pct")):
        rep.append(f"| Automat przy celu {t} błędu: pokrycie / błąd | " + " | ".join(
            f"{results['sets'][s][key]['coverage']:.0%} / {results['sets'][s][key]['error_among_accepted'] if results['sets'][s][key]['error_among_accepted'] is not None else '-'}"
            for s in sets) + " |")
    def fmt(t):
        return f"{t:.4f}" if t is not None else "brak certyfikatu (wszystko do człowieka)"

    cc = results["cert_check"]
    rep += ["", f"**Certyfikowane progi** (jednostronny 95% Clopper–Pearson na FIT = {len(fit)} pól kalibracyjnych): "
                f"cel 1% → {fmt(thresholds[0.01])}, cel 5% → {fmt(thresholds[0.05])}.",
            f"Sprawdzenie na CERT ({len(cert)} pól, nieużytych do dopasowania): cel 1% → pokrycie {cc['1pct']['coverage']:.0%}, "
            f"błąd {cc['1pct']['error_among_accepted']}; cel 5% → pokrycie {cc['5pct']['coverage']:.0%}, błąd {cc['5pct']['error_among_accepted']}."]
    if lofo:
        rep.append(f"Kalibracja na kraju wyłączonym z dopasowania (ECE tokenów): średnio {lofo['mean']}, najgorzej {lofo['max']} ({lofo['worst']}).")
    lat = results["latency"]
    rep += ["", f"Czas: pojedyncze pole p50 **{lat['single_p50_ms']} ms**, paczka 32 pól: **{lat['batch32_fields_per_s']} pól/s** ({lat.get('device', 'RTX 4080')}, PyTorch eager).",
            "", "Szczegóły per etykieta: `metrics.json`. Przegląd ręcznych przypadków: `handcrafted_review.md`."]
    (run / "report.md").write_text("\n".join(rep), encoding="utf-8")
    print("\n".join(rep))


if __name__ == "__main__":
    main()
