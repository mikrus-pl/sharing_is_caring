"""Routing of a field to the name agent and the geo agent, with ambiguity sent to both.

Units: words of the field (a word broken by a line break stays one word). A word is split into pieces only where the
model is confident that two different groups meet inside it (e.g. KOWALSKIUL. with the space missing); an uncertain
word stays whole.

Every unit gets probabilities P(NAME), P(ADDRESS), P(NOISE) and two decisions (see decide()):
  1. noise or content: dropped only when P(NOISE) is above a threshold that keeps the share of dropped content <= alpha
  2. which content: name agent and/or geo agent from P(NAME | content) and P(ADDRESS | content) with class-conditional
     (Mondrian) conformal thresholds; a word that is not clearly one or the other goes to BOTH agents.
The thresholds are calibrated on held-out data, so the guarantees hold for data like the calibration data.
"""

from __future__ import annotations

import math
import re

import torch

from party_tagger.labels import COARSE, ISO_ELEMENT

GROUPS = ["NAME", "ADDRESS", "NOISE"]
SPLIT_CONFIDENCE = 0.8  # both sides of a split inside one word must be at least this sure


def _token_rows(text, offsets, token_probs, labels):
    o = labels.index("O")
    index = {g: [i for i, lbl in enumerate(labels) if COARSE[lbl] == g] for g in GROUPS}
    rows = []
    for k, (s, e) in enumerate(offsets):
        if k == 0 or s == e:
            continue
        p = token_probs[k]
        gp = torch.stack([p[index[g]].sum() for g in GROUPS])
        gp = gp / gp.sum().clamp_min(1e-9)
        top = labels[int(p.argmax())]
        rows.append({"k": k, "s": s, "e": e, "piece": text[s:e], "gp": gp, "p": p,
                     "group": "O" if top == "O" else COARSE[top], "sep_prob": float(p[o])})
    return rows


def build_units(text: str, offsets, token_probs: torch.Tensor, labels: list[str], continues: dict[int, bool]) -> list[dict]:
    rows = _token_rows(text, offsets, token_probs, labels)
    units: list[dict] = []
    cur: dict | None = None
    glue = False
    for r in rows:
        piece = r["piece"]
        if piece.isspace():
            nl = s = r["s"] + piece.find("\n") if "\n" in piece else None
            glue = nl is not None and continues.get(nl, False)
            if not glue:
                cur = None
            continue
        has_alnum = any(c.isalnum() for c in piece)
        if r["group"] == "O" and not has_alnum:
            cur = None  # separator such as "," or "/"
            glue = False
            continue
        new_word = piece[0].isspace() and not glue
        glue = False
        if cur is not None and not new_word:
            prev = cur["_rows"][-1]
            confident_change = (r["group"] != prev["group"] and r["group"] != "O" and prev["group"] != "O"
                                and float(prev["gp"].max()) >= SPLIT_CONFIDENCE and float(r["gp"].max()) >= SPLIT_CONFIDENCE)
            if not confident_change:
                cur["_rows"].append(r)
                continue
        cur = {"_rows": [r]}
        units.append(cur)

    out = []
    for u in units:
        rs = u.pop("_rows")
        start = min(r["s"] + (len(r["piece"]) - len(r["piece"].lstrip())) for r in rs)
        end = max(r["e"] for r in rs)
        weights = torch.tensor([max(1, sum(c.isalnum() for c in r["piece"])) for r in rs], dtype=torch.float)
        gp = (torch.stack([r["gp"] for r in rs]) * weights[:, None]).sum(0) / weights.sum()
        fine = (torch.stack([r["p"] for r in rs]) * weights[:, None]).sum(0) / weights.sum()
        value = "".join("" if ch == "\n" and continues.get(start + i, False) else (" " if ch == "\n" else ch)
                        for i, ch in enumerate(text[start:end]))
        out.append({
            "text": text[start:end], "value": re.sub(r" {2,}", " ", value).strip(), "start": start, "end": end,
            "p": {g: round(float(gp[i]), 4) for i, g in enumerate(GROUPS)},
            "_fine": fine,
        })
    return out


_IBAN = re.compile(r"[A-Z]{2}\d{2}[A-Z0-9]{10,30}")
_ACCOUNT_PREFIX = re.compile(r"^(?:/+|IBAN:?|ACC(?:OUNT)?(?: NO)?:?|A/C)\s*", re.I)


def valid_iban(candidate: str) -> bool:
    """ISO 13616 check digits (mod 97)."""
    s = re.sub(r"\s", "", _ACCOUNT_PREFIX.sub("", candidate.strip())).upper()
    if not _IBAN.fullmatch(s):
        return False
    digits = "".join(str(int(c, 36)) for c in s[4:] + s[:4])
    return int(digits) % 97 == 1


_F_CODE = re.compile(r"[1-8]/")


def split_line_codes(units: list[dict], text: str) -> None:
    """50F/59F: a line code glued to the word after it ("2/C/O") becomes its own unit; the code is structure, not content."""
    lines = text.split("\n")
    if sum(bool(_F_CODE.match(line)) for line in lines) < 2:
        return
    line_starts = {0} | {i + 1 for i, ch in enumerate(text) if ch == "\n"}
    out = []
    for u in units:
        if u["start"] in line_starts and _F_CODE.match(text, u["start"]):
            cut = u["start"] + 2
            out.append(dict(u, text=text[u["start"]:cut], value=text[u["start"]:cut], end=cut,
                            p={"NAME": 0.0, "ADDRESS": 0.0, "NOISE": 1.0}, validated="LINE_CODE"))
            if u["end"] > cut:
                out.append(dict(u, text=text[cut:u["end"]], value=u["value"][2:].strip(), start=cut))
        else:
            out.append(u)
    units[:] = out


def apply_validators(units: list[dict], text: str) -> None:
    """Deterministic facts override the model: a line that is a valid IBAN, or the account line at the top of 50K/59
    ("/1234..." without spaces), is an account (ignored by both agents)."""
    pos = 0
    for n, line in enumerate(text.split("\n")):
        start, end = pos, pos + len(line)
        kind = "IBAN" if valid_iban(line) else "ACCOUNT_LINE" if n == 0 and line.startswith("/") and " " not in line.strip() else None
        if kind:
            for u in units:
                if start <= u["start"] and u["end"] <= end:
                    u["p"] = {"NAME": 0.0, "ADDRESS": 0.0, "NOISE": 1.0}
                    u["validated"] = kind
        pos = end + 1


# ---------------------------------------------------------------- user rules applied after the model (2026-10-18)

# Noise is rare: only garbage and placeholders may be dropped. A word with letters or digits is never lost because the
# model called it noise; it goes to both agents instead (flag "kept_by_guard").
_PLACEHOLDER = re.compile(r"(?<![A-Z0-9])(?:NOT ?PROVIDED|N/A|UNKNOWN|NONE|NIL|TBC|SEE ABOVE)(?![A-Z0-9])")
_REPEATED = re.compile(r"(.)\1{2,}")  # XXX, 0000, ----, ===


def droppable(u: dict, text: str) -> bool:
    if u.get("validated"):
        return True
    value = u["value"]
    if not any(ch.isalnum() for ch in value) or _REPEATED.fullmatch(value.replace(" ", "")) or _PLACEHOLDER.fullmatch(value):
        return True  # value: a placeholder split by a line break ("TB" + "C") is joined here
    return any(m.start() <= u["start"] and u["end"] <= m.end() for m in _PLACEHOLDER.finditer(text))


# Words that introduce another party or a contact. The marker and the party after it are "who" -> name agent.
MARKERS = [
    ("care_of", re.compile(r"C ?/ ?O[.:]?|C\.O\.?|CARE OF:?")),
    ("attention", re.compile(r"ATTN[.:]?|ATTENTION:?|FAO:?")),
    ("on_behalf_of", re.compile(r"OBO|O\.B\.O\.?|ON BEHALF OF:?")),
    ("further_credit", re.compile(r"FFC[.:]?|F\.F\.C\.?|FOR FURTHER CREDIT(?: (?:TO|OF))?:?")),
    ("trading_as", re.compile(r"T/A|TRADING AS:?|DBA|D/B/A|D\.B\.A\.?")),
]
CARE_OF_TO_GEO = True  # user rule: after C/O we do not know whether a sanctions hit was on the party or on the place


def find_markers(units: list[dict], text: str) -> list[tuple[int, int, str]]:
    """(first unit, end unit, role) for every marker; the longest match wins ("FOR FURTHER CREDIT TO" over "FOR")."""
    found, i = [], 0
    while i < len(units):
        for k in (4, 3, 2, 1):
            if i + k > len(units):
                continue
            phrase = re.sub(r"\s+", " ", text[units[i]["start"]:units[i + k - 1]["end"]]).strip().upper()
            role = next((r for r, rx in MARKERS if rx.fullmatch(phrase)), None)
            if role:
                found.append((i, i + k, role))
                i += k
                break
        else:
            i += 1
    return found


def _best_fine(fine: torch.Tensor, labels: list[str], group: str) -> str:
    idx = [i for i, lbl in enumerate(labels) if COARSE[lbl] == group]
    return labels[max(idx, key=lambda i: float(fine[i]))]


def _merge(parts: list[dict], text: str, group: str) -> list[dict]:
    """Neighbouring words with the same label, flags and role become one phrase (e.g. ACCOUNTS DEPT)."""
    out: list[dict] = []
    for p in parts:
        prev = out[-1] if out else None
        if (prev and prev["label"] == p["label"] and prev["flags"] == p["flags"] and prev.get("role") == p.get("role")
                and text[prev["end"]:p["start"]].isspace()):
            prev["end"] = p["end"]
            prev["text"] = text[prev["start"]:prev["end"]]
            prev["value"] = f"{prev['value']} {p['value']}"
            prev["confidence"] = min(prev["confidence"], p["p"][group])
            prev["words"] += 1
        else:
            out.append({"text": p["text"], "value": p["value"], "start": p["start"], "end": p["end"], "label": p["label"],
                        "confidence": p["p"][group], "flags": p["flags"], "words": 1,
                        **({"role": p["role"]} if p.get("role") else {})})
    return out


def _runs(parts: list[dict], text: str, label: str) -> list[str]:
    """Values of neighbouring parts with this label joined into phrases, whatever their flags."""
    runs, end = [], None
    for p in parts:
        if p["label"] != label:
            end = None
            continue
        if end is not None and text[end:p["start"]].isspace():
            runs[-1] += f" {p['value']}"
        else:
            runs.append(p["value"])
        end = p["end"]
    return runs


def _entities(name_parts: list[dict], text: str) -> list[dict]:
    """Separate parties for the name agent: the field's own party, and parties introduced by C/O, ATTN, OBO, FFC, T/A."""
    entities, role, marker = [], None, None
    for p in name_parts:
        if p["label"] == "PARTY_INTRO":
            if p.get("role"):  # C/O, ATTN, ...; a role word such as BENEFICIARY does not start another party
                role, marker = p["role"], p["value"]
        elif p["label"] in ("NAME_PERSON", "NAME_ORG"):
            prev = entities[-1] if entities else None
            if prev and role is None and prev["type"] == p["label"] and text[prev["_end"]:p["start"]].isspace():
                prev["value"] += f" {p['value']}"  # same party split only by flags
                prev["_end"] = p["end"]
                continue
            entities.append({"value": p["value"], "type": p["label"], "role": role or "party",
                             **({"marker": marker} if marker else {}), "_end": p["end"]})
            role = marker = None
    for e in entities:
        e.pop("_end")
        e["type"] = "person" if e["type"] == "NAME_PERSON" else "organization"
    return entities


MAYBE_NOISE = 0.2  # sent words with at least this P(NOISE) carry a "maybe_noise" flag
NOISE_DROP_MIN = 0.95  # user rule: a word is dropped as noise only when the model is very sure; otherwise it goes to an agent


def decide(p: dict[str, float], thresholds: dict[str, float] | None, can_drop: bool = True) -> tuple[bool, bool]:
    """(to name agent, to geo agent) for one word.

    1. Noise or content: the word is dropped only when P(NOISE) > thresholds["noise"] (never below NOISE_DROP_MIN = 0.95)
       and the word may be dropped at all (see droppable(): garbage, placeholders, account line, line codes). A word the
       model calls noise but that may not be dropped goes to both agents.
    2. Which content: P(NAME | content) >= thresholds["name"] -> name agent, P(ADDRESS | content) >= thresholds["address"]
       -> geo agent; when neither side is sure enough, or both are, the word goes to both agents.
    """
    if not thresholds:  # plain argmax
        best = max(GROUPS, key=lambda g: p[g])
        if best == "NOISE":
            return (False, False) if can_drop else (True, True)
        return best == "NAME", best == "ADDRESS"
    if p["NOISE"] > max(NOISE_DROP_MIN, thresholds["noise"]):  # floor also covers thresholds saved by older runs
        return (False, False) if can_drop else (True, True)
    content = max(p["NAME"] + p["ADDRESS"], 1e-9)
    to_name = p["NAME"] / content >= thresholds["name"]
    to_geo = p["ADDRESS"] / content >= thresholds["address"]
    if not (to_name or to_geo):
        to_name = to_geo = True
    return to_name, to_geo


def _model_drops(p: dict[str, float], thresholds: dict[str, float] | None) -> bool:
    if not thresholds:
        return max(GROUPS, key=lambda g: p[g]) == "NOISE"
    return p["NOISE"] > max(NOISE_DROP_MIN, thresholds["noise"])


def route_units(units: list[dict], labels: list[str], thresholds: dict[str, float] | None, text: str) -> dict:
    """Destination for every word; agent payloads for the whole field."""
    split_line_codes(units, text)
    apply_validators(units, text)
    fine = [u.pop("_fine") for u in units]
    dest = []
    for u in units:
        can_drop = droppable(u, text)
        dest.append(list(decide(u["p"], thresholds, can_drop)))
        u["flags"] = ["kept_by_guard"] if _model_drops(u["p"], thresholds) and not can_drop else []

    # markers (C/O, ATTN, OBO, FFC, T/A) and the party after them are "who"; after C/O the party also goes to geo
    for i, j, role in find_markers(units, text):
        care_of = role == "care_of" and CARE_OF_TO_GEO
        for k in range(i, j):
            units[k]["role"], units[k]["marker"] = role, True
            dest[k] = [True, care_of]
        k = j
        while care_of and k < len(units):
            if units[k].get("validated") == "LINE_CODE":  # the party's name may continue on the next 2/ line
                k += 1
                continue
            if not dest[k][0] or units[k].get("marker") or units[k].get("validated"):
                break
            dest[k][1] = True
            units[k]["role"] = role
            k += 1

    name_parts, geo_parts, ignored, ambiguous = [], [], [], []
    review = False
    for u, f, (to_name, to_geo) in zip(units, fine, dest):
        care_of = u.get("role") == "care_of"
        u["set"] = ["NAME"] * to_name + ["ADDRESS"] * to_geo or ["NOISE"]
        u["send_to"] = [a for a, flag in (("name", to_name), ("geo", to_geo)) if flag]
        flags = u["flags"]
        if to_name and to_geo and not care_of:
            flags.append("ambiguous")
        if care_of:
            flags.append("care_of")
        if u["send_to"] and u["p"]["NOISE"] >= MAYBE_NOISE:
            flags.append("maybe_noise")
        if to_name:
            u["name_label"] = "PARTY_INTRO" if u.get("marker") else _best_fine(f, labels, "NAME")
            name_parts.append(dict(u, label=u["name_label"]))
        if to_geo:
            u["geo_label"] = "CARE_OF" if care_of else _best_fine(f, labels, "ADDRESS")
            p_geo = u["p"]
            if care_of:  # in the geo payload by rule, so its confidence is P(content), not P(address)
                p_geo = dict(p_geo, ADDRESS=round(p_geo["NAME"] + p_geo["ADDRESS"], 4))
            geo_parts.append(dict(u, label=u["geo_label"], p=p_geo))
        if not u["send_to"]:
            u["noise_label"] = {"IBAN": "ACCOUNT", "ACCOUNT_LINE": "ACCOUNT", "LINE_CODE": "LINE_PREFIX"}.get(
                u.get("validated"), None) or _best_fine(f, labels, "NOISE")
            ignored.append(dict(u, label=u["noise_label"]))
        if to_name and to_geo and not care_of:  # C/O goes to both by rule, not because the model is unsure
            ambiguous.append({k: u[k] for k in ("text", "value", "start", "end", "p", "set")})
        if "ambiguous" in flags and "maybe_noise" in flags:
            review = True  # unsure whether it is content at all and unsure whose it is
        u.pop("marker", None)

    name_parts = _merge(name_parts, text, "NAME")
    geo_parts = _merge(geo_parts, text, "ADDRESS")
    ignored = _merge(ignored, text, "NOISE")
    iso: dict[str, str] = {}
    for p in geo_parts:
        key = ISO_ELEMENT.get(p["label"])
        if key:
            iso[key] = f"{iso[key]} {p['value']}" if key in iso else p["value"]
    entities = _entities(name_parts, text)
    main = [e for e in entities if e["role"] == "party"] or entities
    person = sum(len(e["value"]) for e in main if e["type"] == "person")
    org = sum(len(e["value"]) for e in main if e["type"] == "organization")
    return {
        "name_agent": {"text": " ".join(p["value"] for p in name_parts),
                       "party_type": "person" if person > org else "organization" if org else "unknown",
                       "entities": entities,
                       "identifiers": [p["value"] for p in name_parts if p["label"] == "PARTY_ID"],
                       "parts": name_parts},
        "geo_agent": {"text": " ".join(p["value"] for p in geo_parts), "iso20022_hint": iso,
                      "care_of": _runs(geo_parts, text, "CARE_OF"), "parts": geo_parts},
        "ignored": ignored,
        "ambiguous": ambiguous,
        "review": review,
        "policy": {"thresholds": thresholds} if thresholds else {"thresholds": None, "note": "argmax (no calibration)"},
    }


# ---------------------------------------------------------------- calibration and evaluation

def unit_gold(unit: dict, char_labels: list[str], text: str) -> str | None:
    groups = [COARSE[char_labels[i]] for i in range(unit["start"], unit["end"]) if text[i].isalnum()]
    groups = [g for g in groups if g != "O"]
    return max(set(groups), key=groups.count) if groups else None


def conformal_quantile(scores: list[float], alpha: float) -> float:
    """Split-conformal quantile: a new score from the same distribution is <= it with probability >= 1 - alpha."""
    s = sorted(scores)
    n = len(s)
    if n == 0:
        return 1.0
    rank = math.ceil((n + 1) * (1 - alpha))
    return 1.0 if rank > n else s[rank - 1]


def calibrate_thresholds(units_with_gold: list[tuple[dict, str]], alpha: float) -> dict[str, float]:
    """Class-conditional (Mondrian) thresholds for decide().

    noise:   content words (gold NAME or ADDRESS) are dropped with probability <= alpha
    name:    gold NAME words have P(NAME | content) >= threshold with probability >= 1 - alpha
    address: the same for gold ADDRESS words
    """
    drop, name, address = [], [], []
    for u, gold in units_with_gold:
        p = u["p"]
        content = max(p["NAME"] + p["ADDRESS"], 1e-9)
        if gold in ("NAME", "ADDRESS"):
            drop.append(p["NOISE"])
        if gold == "NAME":
            name.append(1 - p["NAME"] / content)
        elif gold == "ADDRESS":
            address.append(1 - p["ADDRESS"] / content)
    return {
        "noise": round(max(NOISE_DROP_MIN, conformal_quantile(drop, alpha)), 6),
        "name": round(max(0.0, 1 - conformal_quantile(name, alpha)), 6),
        "address": round(max(0.0, 1 - conformal_quantile(address, alpha)), 6),
    }


def gold_care_of(ex) -> set[int]:
    """Characters the user rule sends to both agents: a C/O marker and the party's name right after it."""
    care_of = MARKERS[0][1]
    out: set[int] = set()
    spans = ex.spans()
    for n, sp in enumerate(spans):
        if sp["label"] == "PARTY_INTRO" and care_of.fullmatch(re.sub(r"\s+", " ", sp["text"]).strip()):
            out.update(range(sp["start"], sp["end"]))
            for nxt in spans[n + 1:]:
                if nxt["label"] == "LINE_PREFIX":
                    continue
                if nxt["label"] not in ("NAME_PERSON", "NAME_ORG"):
                    break
                out.update(range(nxt["start"], nxt["end"]))
                break
    return {i for i in out if COARSE[ex.char_labels[i]] == "NAME"}


def routing_metrics(examples, outputs) -> dict:
    """Character-level view (letters and digits) of what each agent receives. Content of a C/O party is expected at both
    agents (user rule) and is not counted as ambiguity."""
    tot = {"NAME": 0, "ADDRESS": 0, "NOISE": 0}
    to_name = {"NAME": 0, "ADDRESS": 0, "NOISE": 0}
    to_geo = {"NAME": 0, "ADDRESS": 0, "NOISE": 0}
    both = dropped = noise_sent = 0
    lossless = clean = review = ambiguous_fields = 0
    for ex, out in zip(examples, outputs):
        sent = {}
        for u in out["units"]:
            for i in range(u["start"], u["end"]):
                sent[i] = set(u["send_to"])
        ok_loss = ok_clean = True
        care = gold_care_of(ex)
        for i, ch in enumerate(ex.text):
            if not ch.isalnum():
                continue
            g = COARSE[ex.char_labels[i]]
            if g == "O":
                continue
            s = sent.get(i, set())
            tot[g] += 1
            to_name[g] += "name" in s
            to_geo[g] += "geo" in s
            if g != "NOISE":
                both += s == {"name", "geo"} and i not in care
                dropped += not s
            else:
                noise_sent += bool(s)
            if (g == "NAME" and "name" not in s) or (g == "ADDRESS" and "geo" not in s):
                ok_loss = False
            expected = {"name", "geo"} if i in care else {"name"} if g == "NAME" else {"geo"} if g == "ADDRESS" else set()
            if s != expected:
                ok_clean = False
        lossless += ok_loss
        clean += ok_clean
        review += out["routing"]["review"]
        ambiguous_fields += bool(out["routing"]["ambiguous"])
    n = len(examples)
    content = tot["NAME"] + tot["ADDRESS"]
    name_recv = sum(to_name.values())
    geo_recv = sum(to_geo.values())
    return {
        "name_recall": round(to_name["NAME"] / max(tot["NAME"], 1), 4),
        "address_recall": round(to_geo["ADDRESS"] / max(tot["ADDRESS"], 1), 4),
        "name_agent_purity": round(to_name["NAME"] / max(name_recv, 1), 4),
        "geo_agent_purity": round(to_geo["ADDRESS"] / max(geo_recv, 1), 4),
        "noise_sent_to_agents": round(noise_sent / max(tot["NOISE"], 1), 4),
        "content_sent_to_both": round(both / max(content, 1), 4),
        "content_dropped": round(dropped / max(content, 1), 4),
        "fields_lossless": round(lossless / n, 4),
        "fields_perfect": round(clean / n, 4),
        "fields_with_ambiguity": round(ambiguous_fields / n, 4),
        "fields_review": round(review / n, 4),
    }
