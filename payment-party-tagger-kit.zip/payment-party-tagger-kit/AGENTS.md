# Agent guide for this package (AGENTS.md; CLAUDE.md imports this file)

This folder is the **kit of payment-party-tagger v3**: everything needed to run the trained model and to train it
again. The model (Gemma 4 E4B + bidirectional attention + LoRA + two small heads) splits a SWIFT MT party field
(50K/59/50F/59F) into name (who), postal address (where) and noise. The trained v3 is **not in this folder**: it is on
Hugging Face, `msw1410/payment-party-tagger-gemma4-e4b` (public), and `reproduce.py --published` downloads it.

## The users
- Speak **Polish**; reply in Polish, **very briefly and concretely**, without jargon. They are not ML specialists:
  you do the technical work, they log in, pay and approve.
- Work on **Macs** (Apple silicon).

## Their three goals, in this order

| | Goal | How | Read |
|---|---|---|---|
| A | run v3 in 16 bits on the Mac | `python reproduce.py --published` (no training; calibrates on this Mac) | `docs/RUN_MAC.md` |
| B | run v3 in 8 bits on the Mac | write the MLX backend and the 8-bit variant (the Mac has no FP8) | `docs/MLX_MIGRATION.md`, section 12 |
| C | train the smaller Gemma 4 E2B on the same data | `python reproduce.py --model e2b` | `docs/TRAIN_SMALLER.md` |

## Rules
- Ask before: downloading anything over ~1 GB (E4B 16 GB, E2B 10.3 GB), any paid cloud run (state hardware, time,
  cost), uploading or publishing anything, and runs longer than ~15 minutes.
- Download only the **official** base models (`google/gemma-4-E4B-it`, `google/gemma-4-E2B-it`). Never third-party
  FP8/4-bit checkpoints: the 8-bit variant is made from the official weights with the v3 adapter merged (section 12).
- **Calibration belongs to one engine + device type + precision.** Every variant gets its own run folder and its own
  `evaluate` + `calibrate`; never copy `meta.json` between variants. `Predictor` reports `calibration.status`.
- Never type passwords, tokens or payment data, never accept consent screens: ask the user and guide them click by click.
- Do not change the recipe, labels, data, routing or release criteria to make a number look better.
- Keep `python -m pytest -q` green. Keep the public name `payment-party-tagger-*`.

## Where things are

| Path | What |
|---|---|
| `README.md` | start page for people (Polish): the three paths, what to download |
| `reproduce.py`, `recipe_v3.json` | the pipeline (steps: env, model, fetch, data, train, evaluate, calibrate, export, gate, compare) and the recipe |
| `docs/RUN_MAC.md` | path A, the calibration rule, troubleshooting |
| `docs/MLX_MIGRATION.md` | path B (section 12) and the MLX backend in general |
| `docs/TRAIN_SMALLER.md` | path C |
| `docs/PIPELINE.md` | every step and option of `reproduce.py`, Colab, Linux/NVIDIA |
| `docs/CLOUD_GPU.md` | training in the cloud (Hugging Face Jobs, Colab through its MCP server) |
| `docs/DESIGN.md` | research (basal), input/output JSON, comparison with basal and plain Gemma |
| `docs/ARCHITECTURE.md`, `docs/DATA.md` | how the model is built and trained; the data |
| `src/party_tagger/` | code; inference entry point `infer.Predictor` (`raw()` is the hook for another backend) |
| `scripts/` | the single steps called by `reproduce.py` |
| `data/` | data (gzip) + `SHA256SUMS`; `handcrafted.txt` = 30 hand-written fields |
| `examples/` | real request/response JSON pairs from v3 |
| `expected/` | reference results of v3 (NVIDIA RTX 4080, PyTorch, bf16) |
| `tests/`, `notebooks/`, `cloud/` | tests; Colab notebook; Hugging Face Jobs script |

## Commands
```bash
python reproduce.py --published --dry-run      # plan for path A, nothing is downloaded or run
python reproduce.py --published                # path A
python reproduce.py --model e2b --smoke        # path C, quick end-to-end check
python reproduce.py --model e2b                # path C, full training
python -m pytest -q                            # tests (tokenizer tests need a downloaded base model)
```
On a Mac the PyTorch path uses the Apple GPU (MPS) automatically; `TAGGER_DEVICE=cpu` forces the CPU.
