# payment-party-tagger v3: paczka do uruchomienia i treningu

Model dzieli pole strony z wiadomości SWIFT MT (`50K`, `59`, `50F`, `59F`) na **nazwę** („kto”), **adres** („gdzie”)
i szum. Wytrenowany model v3 jest na Hugging Face:
[msw1410/payment-party-tagger-gemma4-e4b](https://huggingface.co/msw1410/payment-party-tagger-gemma4-e4b).
Ta paczka ma wszystko inne: kod, dane, przepis, wzorcowe wyniki i instrukcje.

## Trzy ścieżki

| | Cel | Jak | Stan |
|---|---|---|---|
| **A** | v3 w 16 bitach na Macu | `python reproduce.py --published`, opis: [docs/RUN_MAC.md](docs/RUN_MAC.md) | gotowe; sprawdzone na karcie NVIDIA, na Macu jeszcze nie |
| **B** | v3 w 8 bitach na Macu | agent według [docs/MLX_MIGRATION.md](docs/MLX_MIGRATION.md), sekcja 12 | do zrobienia przez agenta na Macu |
| **C** | trening mniejszego modelu (Gemma 4 E2B) na tych samych danych | `python reproduce.py --model e2b`, opis: [docs/TRAIN_SMALLER.md](docs/TRAIN_SMALLER.md) | gotowe, niesprawdzone |

## Co pobrać
- **Tylko oficjalną Gemmę 4 E4B od Google** (`google/gemma-4-E4B-it`, 16 GB, 16 bitów). `reproduce.py` pobiera ją sam.
  Wystarcza do ścieżek A i B.
- **Nie pobierajcie wersji FP8 od osób trzecich.** Mac nie liczy FP8. Wersję 8-bitową robi się z oficjalnej (ścieżka B).
- Do ścieżki C: Gemma 4 E2B (10,3 GB), też pobierana przez skrypt.

## Na początek (raz)
```bash
python3.12 -m venv .venv && source .venv/bin/activate
pip install torch
pip install -r requirements.txt
python reproduce.py --published --dry-run      # plan kroków, nic nie pobiera
```

## Jedna zasada
**Każdy wariant (komputer + precyzja) ma własną kalibrację, liczoną na miejscu.** Kalibracji z innego komputera nie
kopiujemy. Model sam to pilnuje: na niezgodnym sprzęcie zwraca `"calibration": {"status": "unvalidated", ...}` i
kieruje pola do przeglądu.

## Co gdzie jest

| Folder / plik | Co to jest |
|---|---|
| `AGENTS.md`, `CLAUDE.md` | instrukcja dla agenta (Claude Code czyta `CLAUDE.md`) |
| `reproduce.py` | jeden skrypt do wszystkiego: pobranie, dane, trening albo gotowy v3, ocena, kalibracja, bramka, porównanie |
| `recipe_v3.json` | dokładne ustawienia v3 i modele do wyboru (`e4b`, `e2b`) |
| `docs/` | instrukcje: [RUN_MAC](docs/RUN_MAC.md), [TRAIN_SMALLER](docs/TRAIN_SMALLER.md), [MLX_MIGRATION](docs/MLX_MIGRATION.md), [PIPELINE](docs/PIPELINE.md) (wszystkie kroki), [CLOUD_GPU](docs/CLOUD_GPU.md) (chmura), [DESIGN](docs/DESIGN.md) (skąd pomysł, wejście i wyjście), [ARCHITECTURE](docs/ARCHITECTURE.md), [DATA](docs/DATA.md) |
| `src/party_tagger/` | kod modelu |
| `scripts/` | poszczególne kroki (dane, trening, ocena, kalibracja, bramka, eksport, przykłady) |
| `data/` | dane treningowe i testowe (syntetyczne) + sumy kontrolne |
| `examples/` | prawdziwe pary zapytanie/odpowiedź z v3 |
| `expected/` | wzorcowe wyniki v3 (karta NVIDIA), do porównania |
| `tests/` | testy kodu (`python -m pytest -q`) |
| `notebooks/`, `cloud/` | Google Colab i Hugging Face Jobs (trening w chmurze) |
