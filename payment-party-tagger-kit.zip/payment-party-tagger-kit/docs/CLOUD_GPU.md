# Task brief: training in the cloud for the user (Hugging Face Jobs or Google Colab)

**Dla użytkownika (PL):** ten plik jest instrukcją dla agenta. To agent przygotowuje i uruchamia trening w chmurze,
a Ty robisz tylko to, czego agent zrobić nie może i nie powinien:
1. **logujesz się** (do Google albo Hugging Face) w przeglądarce, gdy agent o to poprosi;
2. **dodajesz metodę płatności albo kupujesz kredyty**, jeśli jeszcze ich nie masz;
3. **zatwierdzasz koszt** przed każdym uruchomieniem. Agent poda kwotę, np. „ok. 3 USD za pełny trening E4B”;
4. czasem **klikasz jeden przycisk**, który agent dokładnie opisze (np. „Zezwól” albo wybór karty A100).

Agent nigdy nie wpisuje Twoich haseł ani tokenów i niczego nie publikuje bez pytania.

---

## 0. Rules for the agent

- Talk to the user in **Polish**, simply, step by step; they do not know these tools. For every manual action give
  exact clicks ("kliknij X w prawym górnym rogu").
- **Never type passwords, tokens or payment data**, and never accept OAuth or consent screens for the user: ask them to do it.
- **Before any paid run** state the hardware, expected time and cost, and wait for a clear "tak".
- Always run `--smoke` first (a few minutes, cents), then the full run.
- Nothing becomes public: buckets and repositories are created **private**.
- Results end up on the Mac; report them with `compare.md` and the release-gate result.

## 1. Choose the route

| Route | Manual steps for the user | Cost (full E4B run) | Choose when |
|---|---|---|---|
| **A. Hugging Face Jobs** (recommended) | billing on huggingface.co once; approve the cost | A100 80 GB, $2.50/h → about $2–4 | the user is logged in to `hf` (`hf auth whoami` works); fully scriptable, nothing to click |
| **B. Google Colab through the Colab MCP server** | Google login, GPU choice in the Colab tab, possibly one secret | Colab Pro or compute units; A100 about 15 units/h → about 15–25 units | the user has Colab Pro or units and prefers Google |
| **C. The Mac itself** | none | free | no cloud access: `docs/PIPELINE.md` (point B) now, faster with `MLX_MIGRATION.md` |

Ask the user which accounts they have, recommend A, and say why in one sentence: no clicking, the price is per minute,
and they are already logged in to Hugging Face.

## 2. Route A: Hugging Face Jobs (from the Mac terminal)

What happens: the package zip is mounted into a cloud machine with an A100, the job runs `cloud/hf_job.sh`
(unpack, install, `reproduce.py`), and the results are written to a **private bucket**, which you then sync to the Mac.

1. **Check the login:** `hf auth whoami` (expected: `msw1410`). If it fails, ask the user to run `hf auth login` and
   approve it in the browser.
2. **Billing:** jobs are paid per minute from the account's balance or payment method. If the first submission fails
   with a billing or payment error, ask the user to open
   [huggingface.co/settings/billing](https://huggingface.co/settings/billing) and add a payment method or credits
   (they do it themselves).
3. **A clean upload folder** (only the zip, never the unpacked package with models or `.venv`: a local volume is synced
   to the cloud first, so a 16 GB model folder would be uploaded):
   ```bash
   mkdir -p ~/party-tagger-cloud/upload && cp payment-party-tagger-kit.zip ~/party-tagger-cloud/upload/
   cd ~/party-tagger-cloud
   ```
4. **A private bucket for the results** (once): `hf buckets create msw1410/party-tagger-runs --private --exist-ok`
5. **Dry run** (free, nothing is submitted; check the printed configuration):
   ```bash
   hf jobs run --dry-run --flavor a100-large --timeout 3h --secrets HF_TOKEN \
     -v ./upload:/pkg -v hf://buckets/msw1410/party-tagger-runs:/out \
     pytorch/pytorch:latest \
     bash -c "python -m zipfile -e /pkg/payment-party-tagger-kit.zip /tmp/p && bash /tmp/p/payment-party-tagger-kit/cloud/hf_job.sh e4b fast --smoke"
   ```
   (Verified with `--dry-run` on 2026-10-26. `pytorch/pytorch:latest` is a starting point: if the smoke run fails on
   the torch version, pick a recent `pytorch/pytorch:<version>-cuda12.x-cudnn9-runtime` tag from Docker Hub.)
6. **Smoke run** (ask: "ok. 10–15 min na A100, ok. 0,5–1 USD — uruchomić?"): the same command without `--dry-run`, plus
   `--detach`; it prints a job ID. Follow it with `hf jobs logs <ID>` and `hf jobs ps`; stop it with `hf jobs cancel <ID>`.
7. **Full run** (ask: "ok. 1–1,5 h, ok. 3–4 USD — uruchomić?"): replace `e4b fast --smoke` with `e4b fast`
   (or `e2b fast`). Use `--timeout 4h`.
8. **Results to the Mac:**
   ```bash
   hf buckets sync hf://buckets/msw1410/party-tagger-runs ./results
   ```
   Every job writes its own folder `<model>-<profile>[-smoke]-<date>/` with `runs/` (model, metrics, `compare.md`, logs)
   and `publish/` (ready for the Hub). Show the user `compare.md` and the gate result from `runs/*/reproduce.log`.
9. **Use the trained model on the Mac:** put the run folder into the package's `runs/`, download the base model on the
   Mac (`python reproduce.py --steps model`), then `Predictor('runs/v3_repro', 'models/gemma-4-E4B-it')`. The second
   argument is needed because the job stored its own base-model path in `meta.json`.

## 3. Route B: Google Colab through the Colab MCP server

Google publishes an open-source **Colab MCP server** that lets an agent create, edit and run cells in a Colab notebook
and read their output. It drives a notebook open in the user's browser, so a browser session stays part of the loop.
Repository: [github.com/googlecolab/colab-mcp](https://github.com/googlecolab/colab-mcp).

1. **Install** the MCP server following that README (ask the user before installing anything), register it with the
   agent (for Claude Code: `claude mcp add ...` as the README shows), restart the agent session if required.
2. **Manual moments for the user**, guided by you:
   - log in to Google in the browser and open the Colab tab the MCP server needs;
   - **Środowisko wykonawcze → Zmień typ środowiska wykonawczego → A100 GPU** (or L4) → Zapisz, unless the MCP server can set it;
   - buy Colab Pro or compute units if needed.
3. **Getting the package into Colab** (pick what works, in this order):
   - **Google Drive for desktop** installed on the Mac: copy the zip into the synced "My Drive" folder, then in Colab
     run `drive.mount('/content/drive')` (the user clicks "Zezwól" in the Google consent window);
   - **a private Hugging Face bucket:** `hf buckets cp payment-party-tagger-kit.zip hf://buckets/msw1410/party-tagger-runs/pkg/`,
     and in Colab read it with a token from Colab Secrets. The user adds the secret `HF_TOKEN` themselves: key icon on
     the left → "Dodaj nowy sekret" → name `HF_TOKEN`, value = a Write token from huggingface.co/settings/tokens →
     enable notebook access. Never type the token yourself.
4. **Cells to run** (the same as `notebooks/colab_v3.ipynb`): `nvidia-smi` (must show A100 or L4, not T4) → unpack the package
   to `/content/work` → `pip install -q -r requirements.txt` →
   `python reproduce.py --model e4b --profile fast --smoke --model-dir /content/models/gemma-4-E4B-it` → then the same
   without `--smoke` → copy `runs/` and `publish/` back (to Drive or the bucket) → show `compare.md`.
   On **L4** use `--profile v3`. A **T4** does not work: no hardware bf16.
5. Colab can disconnect an idle or long session. Interrupted training restarts from zero, so save results after every
   finished step and keep the user informed.

## 4. Hardware and profiles

| Hardware | Profile | Notes |
|---|---|---|
| A100 40/80 GB (HF `a100-large` = 80 GB) | `fast` | same effective batch (32), no gradient checkpointing |
| L4 24 GB | `v3` | slower; with less than 24 GB of GPU memory the per-layer embedding table goes to CPU memory automatically |
| T4 16 GB | – | not usable (no hardware bf16) |
| H200 / RTX PRO 6000 (HF Jobs) | `fast` | faster and dearer; only if the user asks |

## 5. Report to the user (in Polish)

Which route, hardware, time and cost; whether the release gate passed; the `compare.md` table in plain words
("wynik zgodny ze wzorcem" or what differs); where the results are on the Mac; what to do next.

Sources: [HF Jobs pricing](https://huggingface.co/docs/hub/jobs-pricing), [HF billing](https://huggingface.co/docs/hub/billing),
[Colab MCP server announcement](https://developers.googleblog.com/announcing-the-colab-mcp-server-connect-any-ai-agent-to-google-colab/),
[Colab GPU rates](https://mccormickml.com/2024/04/23/colab-gpus-features-and-pricing/).
