# Trening mniejszego modelu (Gemma 4 E2B) na tych samych danych

Ten sam przepis i te same dane co v3, tylko mniejszy model bazowy: `google/gemma-4-E2B-it`. Ma ok. 2,3 mld parametrów
efektywnie (5,1 mld z osadzeniami warstwowymi), 10,3 GB do pobrania, licencję Apache 2.0 i nie wymaga logowania.

Najpierw instalacja z [README.md](../README.md) („Na początek”).

```bash
python reproduce.py --model e2b --dry-run    # plan kroków, nic nie pobiera
python reproduce.py --model e2b --smoke      # szybki test całego procesu (pobiera E2B; wyniki bez znaczenia)
python reproduce.py --model e2b              # pełny trening + ocena + kalibracja + bramka + porównanie
```

| | E4B (wzorzec v3) | E2B |
|---|---|---|
| Model bazowy | `models/gemma-4-E4B-it` (16 GB) | `models/gemma-4-E2B-it` (10,3 GB) |
| Wyniki | `runs/v3_repro/` | `runs/e2b_repro/` |
| Pamięć do treningu na Macu | ok. 32 GB | ok. 20–24 GB (szacunek) |
| Pamięć do uruchamiania | ok. 10–15 GB | ok. 6–9 GB (szacunek) |
| Czas treningu | 112,6 min na RTX 4080 | nieznany |
| Jakość | znana (`expected/metrics.json`) | **nieznana**: prawdopodobnie niższa, zwłaszcza dla krajów spoza treningu |

- **Dane są te same:** `data/` (sumy kontrolne w `data/SHA256SUMS`). Nic nie trzeba generować.
- **Ustawienia są te same co dla E4B** (`recipe_v3.json`). Rozmiar głowic kod odczytuje z modelu, więc nic nie trzeba zmieniać.
- **O jakości decyduje bramka** (`gate`, te same 12 kryteriów co dla v3). Porównanie z E4B (`compare`) jest tylko orientacyjne.
- **Trening na Macu w PyTorch będzie wolny** (kilka razy wolniej niż na karcie NVIDIA, nie mierzyliśmy). Szybciej:
  chmura ([CLOUD_GPU.md](CLOUD_GPU.md)) albo silnik MLX ([MLX_MIGRATION.md](MLX_MIGRATION.md), kroki 4–5).
- **Kalibracja należy do komputera, na którym ją liczono.** Wytrenowany E2B skalibruje się sam w kroku `evaluate`
  i `calibrate`; na innym komputerze trzeba to powtórzyć (zasada w [RUN_MAC.md](RUN_MAC.md)).
