# Projekt modelu: skąd się wziął, co przyjmuje, co zwraca i czym różni się od innych

Dokument uzupełnia [ARCHITECTURE.md](ARCHITECTURE.md), który opisuje budowę i trening. Tutaj są: research, z którego
wyszliśmy, dokładny format wejścia i wyjścia (z prawdziwymi JSON-ami z modelu v3) oraz porównanie naszego modelu z basal,
ze zwykłą Gemmą i z Gemmą użytą „w stylu Jev”, ale bez dotrenowania.

Wszystkie JSON-y w tym dokumencie i w folderze [`examples/`](../examples/) wygenerował prawdziwy model v3
(`scripts/make_examples.py`), więc nie ma tu ani jednej ręcznie wpisanej wartości.

---

## 1. W jednym akapicie

Dostajemy **tekst jednego pola strony płatności** SWIFT MT (`50K`, `59`, `50F`, `59F`). Wyjmuje go z wiadomości zwykły
parser, a nie model. Model w **jednym przebiegu** nadaje każdemu tokenowi jedną z 16 ról (osoba, firma, ulica, miasto,
szum…). Na każdym łamaniu linii decyduje też, czy słowo ciągnie się dalej (`WARS⏎ZAWA`). Kod po modelu składa z tego
słowa i frazy. Potem wysyła je do **agenta nazw** („kto”) i **agenta geo** („gdzie”), a pewne śmieci pomija. Model niczego
nie pisze od siebie: każda wartość na wyjściu to fragment wejścia z jego pozycją w tekście.

---

## 2. Skąd pomysł (research)

### 2.1 Jev (TypeSafe AI): idea „System One”
- Zamknięty model z 2026-09. Nie generuje odpowiedzi słowo po słowie. W jednym przebiegu zwraca **skalibrowane
  prawdopodobieństwa** dla odpowiedzi podanych z góry: „pięciosekundowa ocena eksperta w skali maszyny”.
- Kontrakt API `POST /v1/systemone`:
  - na wejściu `state` (tekst) i `questions`, gdzie każde pytanie ma `type`, `instructions` (treść pytania) i `criteria` (opcje);
  - na wyjściu `answers`, czyli rozkład prawdopodobieństwa po opcjach i pewność.
- Wag ani artykułu nie ma. Przejęliśmy samą ideę: decyzja zamiast generowania, jeden przebieg, skalibrowana pewność.

### 2.2 basal (Remigiusz Kinas): nasz główny wzór
- Otwarta implementacja tego samego kontraktu. basal-1.0 / 1.5 / 2.0 działa na Bieliku, a **basal-omni na Gemmie 4 E4B
  i 12B**, czyli na tej samej bazie co my.
- Jak działa:
  - model instruct z nakładką **LoRA r = 32**;
  - pytanie i opcje `A, B, C…` są w prompcie, a w jednym przebiegu model odczytuje prawdopodobieństwo każdej litery
    opcji (*letter readout*);
  - kalibracja: temperatura, podział kalibracji FIT 70% / CERT 30% i **progi z gwarancją** (górna granica
    Clopper–Pearsona dla błędu);
  - **dane syntetyczne z etykietami liczonymi kodem**;
  - **destylacja tylko tam, gdzie nauczyciel ma rację**;
  - zasada: „liczenie i reguły robi kod, model robi rozumienie”.
- Źródła: raport basal-1 (Zenodo, doi 10.5281/zenodo.23022986), github.com/rkinas/basal, karty modeli
  `Remek/basal-omni-1.0-mini` i `-max` na Hugging Face.

### 2.3 LS-unLLaMA
- Z. Li i in., *Label Supervised LLaMA Finetuning*, arXiv:2310.01208. Pokazali, że duży model językowy z **wyłączoną
  maską przyczynową** świetnie klasyfikuje tokeny. Przejęliśmy to: każdy token widzi całe pole, także to, co jest za nim.

### 2.4 Co przejęliśmy z basal, a czego nie

| Element basal | U nas | Dlaczego |
|---|---|---|
| model instruct + LoRA r = 32 na wszystkich warstwach liniowych | tak (Gemma 4 E4B-it, r = 32) | sprawdzony przepis, ten sam model bazowy co basal-omni-mini |
| dane syntetyczne, etykiety liczone kodem | tak (generator `swiftgen.py` + uszkodzenia `corrupt.py`) | etykiety są dokładne, a prawdziwych pól SWIFT z etykietami nie mamy |
| temperatura po treningu | tak, osobno dla każdej głowicy | prawdopodobieństwo 0,9 ma znaczyć „mylę się w 1 na 10” |
| FIT/CERT + Clopper–Pearson | tak: próg automatu dla całego pola | automat przy celu 1% błędu z gwarancją statystyczną |
| leave-one-family-out ECE | jako *leave-one-country-out* | uczciwa miara kalibracji na kraju, którego nie było w dopasowaniu |
| destylacja tylko na poprawnych | jest w kodzie (`train.py --teacher`), v3 jej nie używa | nauczyciel 12B uczył się starych zasad (C/O, ATTN), więc podpowiadałby źle |
| „reguły robi kod” | tak: IBAN mod 97, kody linii `1/`–`8/`, znaczniki C/O/ATTN/OBO/FFC/T/A, bezpiecznik | rzeczy pewne nie powinny zależeć od modelu |
| **pytania w zapytaniu** (`instructions`, `criteria`) | **nie** | punkt 3 |
| **odczyt liter opcji** z głowicy językowej | **nie**, zamiast tego głowica nad każdym tokenem | punkt 3 |
| maska przyczynowa (token widzi tylko poprzednie) | **nie**, atencja dwukierunkowa | o roli słowa decyduje także to, co stoi po nim |

---

## 3. Najważniejsza różnica: wycinanie zamiast decyzji

**basal i Jev odpowiadają na pytanie zadane z góry o cały tekst**, np. „do którego działu skierować zgłoszenie?”.
Pytanie i opcje są znane, zanim model przeczyta tekst.

**Nasze zadanie jest inne:** nie wiemy z góry, które słowa są nazwą, a które adresem. Właśnie tego chcemy się dowiedzieć.
Pytanie w stylu basal „jaka jest rola `ACME LTD` w tym polu?” wymaga, żeby wywołujący już wiedział, że `ACME LTD` to
osobny fragment i że jest nazwą. To błędne koło. Dlatego:

- **pytanie jest jedno, stałe i wbudowane w model.** Głowica etykiet to pytanie „czym jest ten token?”, zadawane
  **wszystkim tokenom naraz**, w jednym przebiegu;
- **wywołujący wysyła wyłącznie tekst.** Nie ma `instructions`, opcji ani podpowiedzi;
- podobne podejście zaleca sam raport basal: dla niezależnych etykiet, takich jak routing, lepsze są głowice nad
  elementami (*pointer heads*) niż litery opcji.

Styl basal (pytanie + opcje) ma sens **warstwę wyżej, u agentów**, gdy fragmenty są już wycięte. Przykłady: „czy ten
podmiot to bank?”, „czy ten adres leży w regionie objętym sankcjami?”. Tam pytanie i opcje są znane z góry.

---

## 4. Wejście

### 4.1 Wywołanie (tak działa dziś: bez serwera, w procesie Pythona)

```python
from party_tagger.infer import Predictor

tagger = Predictor("runs/v3")      # folder przebiegu albo folder pobrany z Hugging Face
out = tagger.predict("BALTIC TIMBER TRADING LTD\nC/O ALPHA CORPORATE SERVICES LTD\n2 ARCH MAKARIOS III AVE\n1065 NICOSIA CYPRUS")
outs = tagger.predict_many([pole_1, pole_2, pole_3], batch_size=32)   # paczka pól: szybciej na pole
```

Serwera HTTP jeszcze nie ma. Gdy będzie potrzebny, wystarczy cienka warstwa (np. FastAPI), która przyjmie JSON jak niżej
i zwróci wynik `predict()`.

### 4.2 Zapytanie JSON (format plików `examples/request_*.json` i ewentualnego API)

```json
{
  "tag": "50K",
  "text": "BALTIC TIMBER TRADING LTD\nC/O ALPHA CORPORATE SERVICES LTD\n2 ARCH MAKARIOS III AVE\n1065 NICOSIA CYPRUS"
}
```

| Pole | Wymagane | Co to jest | Dlaczego tak |
|---|---|---|---|
| `text` | tak | zawartość **jednego** tagu, bez samego `:50K:`; linie rozdzielone `\n`; do 4 linii po 35 znaków, plus linia konta | dokładnie to dostaje parser z wiadomości MT; model uczył się na brudnych danych, więc tekstu **nie czyścimy** (literówki, brak spacji, ucięte słowa, śmieci zostają) |
| `tag` | nie | `50K`, `59`, `50F`, `59F` | v3 go **nie używa**: format F rozpoznaje sam po kodach `1/ 2/ 3/`. Pole służy do logów i na przyszłość |

**Czego w zapytaniu nie ma, i celowo:**
- pytań i instrukcji: pytanie jest wbudowane w model (punkt 3);
- listy opcji: zbiór 16 ról jest stały (tabela w `ARCHITECTURE.md`);
- informacji, co jest nazwą, a co adresem: to jest wynik, a nie dana wejściowa;
- języka i kraju: model sam rozpoznaje konwencje 32 krajów.

### 4.3 Co model widzi w środku
Token BOS i tokeny tekstu z zapamiętanymi pozycjami znaków. W danych treningowych pole ma mediana 49 tokenów, najwyżej
123. Wszystko liczy się w jednym przebiegu.

---

## 5. Wyjście

Pełne odpowiedzi leżą w `examples/response_*.json`. Poniżej skrócona odpowiedź dla zapytania z punktu 4.2
(`"..."` oznacza pominięte elementy listy):

```json
{
  "input": "BALTIC TIMBER TRADING LTD\nC/O ALPHA CORPORATE SERVICES LTD\n2 ARCH MAKARIOS III AVE\n1065 NICOSIA CYPRUS",
  "routing": {
    "name_agent": {
      "text": "BALTIC TIMBER TRADING LTD C/O ALPHA CORPORATE SERVICES LTD",
      "party_type": "organization",
      "entities": [
        {"value": "BALTIC TIMBER TRADING LTD", "type": "organization", "role": "party"},
        {"value": "ALPHA CORPORATE SERVICES LTD", "type": "organization", "role": "care_of", "marker": "C/O"}
      ],
      "identifiers": [],
      "parts": [
        {"text": "BALTIC TIMBER TRADING LTD", "value": "BALTIC TIMBER TRADING LTD", "start": 0, "end": 25,
         "label": "NAME_ORG", "confidence": 1.0, "flags": [], "words": 4},
        {"text": "C/O", "value": "C/O", "start": 26, "end": 29, "label": "PARTY_INTRO", "confidence": 1.0,
         "flags": ["care_of"], "words": 1, "role": "care_of"},
        "..."
      ]
    },
    "geo_agent": {
      "text": "C/O ALPHA CORPORATE SERVICES LTD 2 ARCH MAKARIOS III AVE 1065 NICOSIA CYPRUS",
      "iso20022_hint": {"BldgNb": "2", "StrtNm": "ARCH MAKARIOS III AVE", "PstCd": "1065", "TwnNm": "NICOSIA",
                        "Ctry": "CY", "Ctry_written": "CYPRUS"},
      "care_of": ["C/O ALPHA CORPORATE SERVICES LTD"],
      "parts": [
        {"text": "C/O ALPHA CORPORATE SERVICES LTD", "value": "C/O ALPHA CORPORATE SERVICES LTD", "start": 26, "end": 58,
         "label": "CARE_OF", "confidence": 1.0, "flags": ["care_of"], "words": 5, "role": "care_of"},
        {"text": "2", "value": "2", "start": 59, "end": 60, "label": "BUILDING", "confidence": 0.9998, "flags": [], "words": 1},
        "..."
      ]
    },
    "ignored": [],
    "ambiguous": [],
    "review": false,
    "review_reasons": [],
    "policy": {"thresholds": {"noise": 0.95, "name": 0.983687, "address": 0.981374}}
  },
  "units": [
    {"text": "ALPHA", "value": "ALPHA", "start": 30, "end": 35, "p": {"NAME": 1.0, "ADDRESS": 0.0, "NOISE": 0.0},
     "flags": ["care_of"], "role": "care_of", "set": ["NAME", "ADDRESS"], "send_to": ["name", "geo"],
     "name_label": "NAME_ORG", "geo_label": "CARE_OF"},
    {"text": "NICOSIA", "value": "NICOSIA", "start": 88, "end": 95, "p": {"NAME": 0.0, "ADDRESS": 1.0, "NOISE": 0.0},
     "flags": [], "set": ["ADDRESS"], "send_to": ["geo"], "geo_label": "TOWN"},
    "..."
  ],
  "spans": [
    {"label": "NAME_ORG", "start": 0, "end": 25, "coarse": "NAME", "text": "BALTIC TIMBER TRADING LTD",
     "value": "BALTIC TIMBER TRADING LTD", "confidence": 1.0},
    "..."
  ],
  "joins": [
    {"pos": 25, "word_continues": false, "p": 1.0},
    {"pos": 58, "word_continues": false, "p": 1.0},
    {"pos": 82, "word_continues": false, "p": 0.9988}
  ],
  "confidence": 0.602,
  "result": {
    "name": "BALTIC TIMBER TRADING LTD ALPHA CORPORATE SERVICES LTD",
    "party_details": ["C/O"],
    "address": "2 ARCH MAKARIOS III AVE 1065 NICOSIA CYPRUS",
    "noise": [],
    "party_type": "organization",
    "iso20022": {"BldgNb": "2", "StrtNm": "ARCH MAKARIOS III AVE", "PstCd": "1065", "TwnNm": "NICOSIA",
                 "Ctry": "CY", "Ctry_written": "CYPRUS"},
    "hybrid_address_ready": true
  },
  "tokens": [
    {"i": 1, "text": "BAL", "start": 0, "end": 3, "label": "NAME_ORG", "p": 1.0,
     "top": [["NAME_ORG", 1.0], ["NAME_PERSON", 0.0], ["NOISE", 0.0]]},
    "..."
  ],
  "latency_ms": 161.9
}
```

### 5.1 Trzy poziomy szczegółu: od decyzji do surowego wyniku modelu

| Poziom | Klucz | Dla kogo |
|---|---|---|
| 1. Decyzja | `routing` | aplikacja: co dostaje który agent, co pominięto, czy pole idzie do przeglądu |
| 2. Słowa i fragmenty | `units`, `spans`, `joins`, `confidence` | analiza, testy, wyjaśnianie decyzji |
| 3. Surowe wyjście modelu | `tokens` | debugowanie: etykieta każdego tokenu i trzy najlepsze odpowiedzi głowicy |

`result` to płaski skrót dla wygody, opisany w punkcie 5.4.

### 5.2 `routing`: to, czego używa aplikacja

| Klucz | Co zawiera |
|---|---|
| `name_agent.text` | wszystko, co idzie do agenta nazw, jako jeden ciąg (znaczniki i identyfikatory też, żeby nic nie zginęło) |
| `name_agent.entities` | **osobne podmioty** z rolą: `party` (strona pola), `care_of` (po C/O), `attention` (po ATTN), `on_behalf_of` (OBO), `further_credit` (FFC), `trading_as` (T/A); `type` = `person` / `organization`; `marker` = dosłowny znacznik |
| `name_agent.identifiers` | identyfikatory i kontakty strony (TEL, VAT, BIC, data urodzenia…), osobno od nazw |
| `name_agent.party_type` | czy główna strona to osoba, czy organizacja |
| `geo_agent.text` | wszystko, co idzie do agenta geo |
| `geo_agent.iso20022_hint` | podpowiedź pól adresu ISO 20022 (`StrtNm`, `BldgNb`, `Room`, `PstCd`, `TwnNm`, `CtrySubDvsn`, `Ctry`); `Ctry` zamienione na kod ISO, a oryginał w `Ctry_written` |
| `geo_agent.care_of` | fraza C/O, która trafia też do geo |
| `*.parts` | fragmenty po kolei: tekst, pozycja `start`/`end`, szczegółowa etykieta, pewność, flagi |
| `ignored` | co pominięto i dlaczego (`ACCOUNT`, `LINE_PREFIX`, `NOISE`) |
| `ambiguous` | słowa wysłane do obu agentów, bo model nie był pewny, czyje są |
| `review`, `review_reasons` | czy pole idzie do człowieka: `unsure_noise_and_owner` albo `field_confidence_below_automation_threshold` |
| `policy.thresholds` | progi, z którymi podjęto decyzje |

**Flagi** w `parts` i `units`:
- `ambiguous`: niepewne, więc do obu agentów;
- `maybe_noise`: słowo wysłane, choć P(szum) ≥ 0,2;
- `kept_by_guard`: model chciał wyrzucić, ale słowo ma litery lub cyfry, więc bezpiecznik je zatrzymał;
- `care_of`: fraza C/O, do obu agentów z reguły.

**`confidence` w `parts`:** pewność, że fragment należy do swojej grupy. Dla `CARE_OF` u agenta geo to P(treść)
= P(nazwa) + P(adres), bo trafia tam z reguły, a nie dlatego, że jest adresem.

### 5.3 `units`, `spans`, `joins`, `confidence`

| Klucz | Co zawiera |
|---|---|
| `units` | **słowa** (słowo przecięte łamaniem linii jest jednym słowem): `p` = prawdopodobieństwo grup NAZWA / ADRES / SZUM, `set` i `send_to` = decyzja, `name_label` / `geo_label` = szczegółowa etykieta, `flags`, `role` |
| `spans` | ciągłe fragmenty o tej samej szczegółowej etykiecie, prosto z modelu, przed regułami routingu |
| `joins` | każde łamanie linii: pozycja `\n`, czy słowo ciągnie się dalej (`word_continues`) i pewność. W przykładzie `59_account_attn_split_word` łamanie w `WARS⏎ZAWA` ma `word_continues: true`, więc wartość brzmi `WARSZAWA` |
| `confidence` | pewność **całego pola**, czyli pewność najsłabszego tokenu. Tu 0,602: token ` CY` ze słowa `CYPRUS` (kraj 60%, miasto 39%). To nadal adres, więc routing się nie zmienia. 0,602 > 0,568 (certyfikowany próg automatu przy celu 1% błędu), więc pole nie idzie do przeglądu |

### 5.4 `result`: płaski skrót
`name` (same nazwy, bez znaczników), `party_details` (znaczniki i identyfikatory), `address`, `noise`, `party_type`,
`iso20022`, `hybrid_address_ready` (czy jest miasto i kraj, czyli minimum adresu hybrydowego w CBPR+). To prosty widok
dla ludzi i raportów. **Do routingu służy `routing`.**

### 5.5 Dlaczego wyjście wygląda właśnie tak
1. **Dwóch odbiorców, dwie paczki.** Aplikacja ma agenta nazw i agenta geo, więc wynik jest ułożony per agent, a nie per etykieta.
2. **Pozycje `start`/`end` wszędzie.** Każdą wartość da się wskazać w tekście wejściowym. Model niczego nie dopisuje ani
   nie poprawia. Jedyne przekształcenie to sklejenie słowa przeciętego łamaniem linii.
3. **Prawdopodobieństwa zamiast samych etykiet.** Aplikacja może zmienić progi bez ponownego trenowania.
4. **„Do obu” zamiast zgadywania.** W screeningu sankcyjnym zgubione słowo jest dużo gorsze niż słowo nadmiarowe. Dlatego
   niepewne słowa idą do obu agentów, a szum odpada tylko przy pewności > 0,95 i tylko wtedy, gdy słowo w ogóle może być
   szumem (patrz bezpiecznik).
5. **Osobne podmioty z rolami.** `C/O ALPHA…` to inny podmiot niż strona pola. Każdy z nich trzeba sprawdzić osobno.
6. **Podpowiedź ISO 20022.** Od listopada 2026 CBPR+ wymaga adresu strukturalnego albo hybrydowego, więc od razu dajemy
   gotowe pola. To podpowiedź, a nie walidacja adresu.
7. **Przegląd z powodem.** Próg automatu ma gwarancję statystyczną, a `review_reasons` mówi człowiekowi, czemu pole do niego trafiło.

---

## 6. Porównanie: nasz model, basal, zwykła Gemma i Gemma „w stylu Jev” bez dotrenowania

Wszystkie cztery warianty mogą stać na tym samym modelu Gemma 4 E4B. Różnią się tym, co jest trenowane, jak się je wywołuje
i co zwracają.

| | **Zwykła Gemma 4 E4B-it** (czat) | **Gemma „w stylu Jev”, bez dotrenowania** | **basal / basal-omni** | **Nasz model (v3)** |
|---|---|---|---|---|
| Co to jest | model czatu, który pisze odpowiedź | ta sama Gemma, ale zamiast pisać czytamy prawdopodobieństwa liter opcji (A/B/C) w jednym przebiegu | Gemma (omni) lub Bielik, dotrenowane do decyzji z opcjami | Gemma z atencją dwukierunkową, LoRA i dwiema głowicami nad tokenami |
| Wywołanie | prompt z poleceniem, `generate()` | prompt: tekst + pytanie + opcje; jeden przebieg na **pytanie** | `state` + `questions` (`instructions`, `criteria`), `POST /v1/systemone` | **sam tekst pola**, `predict(text)` |
| Wyjście | tekst (np. JSON), który trzeba sparsować | rozkład po opcjach dla jednego pytania | rozkład po opcjach dla każdego pytania + pewność | etykieta i rozkład dla **każdego tokenu** + decyzja o łamaniu linii, potem routing i ISO |
| Atencja | przyczynowa | przyczynowa | przyczynowa | **dwukierunkowa** |
| Co trenowane | nic | nic | LoRA r = 32 (omni: 815 tys. decyzji z wielu dziedzin) | LoRA r = 32 + dwie głowice (100 tys. syntetycznych pól SWIFT) |
| Przebiegi na pole | jeden przebieg na **każdy** pisany token (dziesiątki–setki) | jeden na **każde słowo**, czyli ok. 15–25, i nadal trzeba wiedzieć, o co pytać | jeden na pytanie | **jeden** |
| Kalibracja | brak (tekst nie ma prawdopodobieństw) | brak; raport basal: wrażliwa na kolejność opcji | temperatura + progi z gwarancją per typ pytania | temperatura per głowica + próg pola z gwarancją + progi routingu |
| Wiedza o SWIFT (C/O, `2/`, `142/144`, łamanie co 35 znaków) | ogólna, bez naszych konwencji | jak obok | ogólna | wytrenowana na naszych konwencjach |
| Może coś wymyślić? | **tak**: poprawia pisownię, dopisuje kraj, zmienia słowa | nie (wybiera opcję) | nie (wybiera opcję) | nie (etykietuje istniejące znaki) |
| Format wyniku zawsze poprawny? | nie (zepsuty JSON, pominięte pola) | tak | tak | tak |
| Czas | szacunkowo sekundy na pole (pisanie JSON-a token po tokenie; nie mierzyliśmy) | ~15–25 przebiegów na pole (nie mierzyliśmy) | basal-omni-mini: 61 ms p50 na decyzję (H100, wg karty modelu) | **82 ms p50 na pole** (RTX 4080), 54,5 pola/s w paczkach po 32 |
| Do czego najlepszy | rozmowa, streszczenia, zadania otwarte | szybki prototyp decyzji bez danych treningowych | wiele różnych decyzji z opcjami w jednym modelu | **jedno zadanie**: rozbiór pola strony na „kto” i „gdzie” |
| Czego nie zrobi | gwarancji formatu i pewności | wycinania fragmentów bez wiedzy z góry, co wycinać | wycinania fragmentów (nie do tego służy) | niczego poza tym jednym zadaniem |

**Nasza architektura bez treningu nie działa w ogóle.** Nowe głowice startują z losowymi wagami, a nakładka LoRA startuje od
zera, czyli Gemma bez zmian. Gemma nie była uczona z atencją dwukierunkową, więc samo wyłączenie maski bez treningu
psuje jej reprezentacje. Wynik byłby losowy. Cała wartość modelu pochodzi z treningu na danych syntetycznych.

**Liczby:** nasze wyniki są zmierzone (`expected/metrics.json`). Czas basal pochodzi z karty modelu basal-omni. Dwóch
pierwszych kolumn na naszych danych nie mierzyliśmy, więc ich czasy to szacunki z zasady działania.

---

## 7. Granice modelu (co robi kod albo inny system)
- Wyjęcie tagu z wiadomości MT: parser, przed modelem.
- Sprawdzenie, czy adres istnieje (geokodowanie), tłumaczenie i transliteracja nazw: poza modelem.
- Decyzja sankcyjna: agenci i ludzie, po modelu. Model tylko dzieli tekst i mówi, jak jest pewny.
- Wiele pól naraz: jedno wywołanie = jedno pole; paczki przez `predict_many`.

## 8. Gdzie co jest w kodzie

| Rzecz | Plik |
|---|---|
| wczytanie Gemmy, atencja dwukierunkowa | `src/party_tagger/backbone.py` |
| głowice, wczytanie przebiegu | `src/party_tagger/tagger.py` |
| dekodowanie: tokeny → fragmenty, `result`, ISO | `src/party_tagger/infer.py` |
| routing, bezpiecznik, znaczniki, podmioty, progi | `src/party_tagger/routing.py` |
| etykiety i ich grupy | `src/party_tagger/labels.py` |
| generator danych i uszkodzenia | `src/party_tagger/swiftgen.py`, `src/party_tagger/corrupt.py` |
| przykłady zapytań i odpowiedzi | `examples/` (generuje je `scripts/make_examples.py` z prawdziwego przebiegu) |
