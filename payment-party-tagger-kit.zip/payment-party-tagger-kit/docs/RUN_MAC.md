# Uruchomienie gotowego v3 na Macu

Najpierw instalacja z [README.md](../README.md) („Na początek”).

## Ścieżka A: 16 bitów (PyTorch na karcie Maca)

**Wymagania:** Mac z Apple silicon, macOS 14+, zalecane **24 GB pamięci** (model zajmuje ok. 15 GB; 16 GB to za mało,
szacunek), ok. 25 GB wolnego dysku.

```bash
python reproduce.py --published --dry-run      # plan kroków
python reproduce.py --published                # właściwe uruchomienie
```

Co robi `--published` (bez treningu):
1. pobiera oficjalną Gemmę 4 E4B (16 GB) do `models/` i wytrenowany v3 z Hugging Face (0,3 GB) do `runs/v3_published/`;
2. rozpakowuje dane i sprawdza sumy kontrolne;
3. **kalibruje model na tym Macu** (pewności, próg automatu, progi routingu);
4. liczy wyniki na 5 zbiorach testowych, przechodzi bramkę jakości i porównuje z wzorcem z karty NVIDIA.

**Wynik jest dobry, gdy:**
- w `runs/v3_published/reproduce.log` jest `release gate: PASSED`;
- w `runs/v3_published/compare.md` różnice do wzorca nie przekraczają 1 punktu procentowego.

Czas: na karcie RTX 4080 kroki 3–4 trwają ok. 9 min. Na Macu tego nie mierzyliśmy.

**Użycie:**
```python
import sys; sys.path.insert(0, "src")
from party_tagger.infer import Predictor

tagger = Predictor("runs/v3_published")
out = tagger.predict("BALTIC TIMBER TRADING LTD\nC/O ALPHA CORPORATE SERVICES LTD\n2 ARCH MAKARIOS III AVE\n1065 NICOSIA CYPRUS")
print(out["calibration"]["status"])            # musi być "validated"
print(out["routing"]["name_agent"]["entities"])
```
Pola do testów są w `examples/request_*.json`. Odpowiedzi z wzorca (`examples/response_*.json`) mogą się różnić
o ułamki prawdopodobieństwa, ale decyzje (`send_to`) powinny być te same.

## Ścieżka B: 8 bitów (MLX)

- Mac nie liczy FP8, dlatego robimy **8 bitów w MLX** z oficjalnej Gemmy 16-bitowej, z wtopioną nakładką v3.
- To zadanie dla agenta: [MLX_MIGRATION.md](MLX_MIGRATION.md), **sekcja 12**. W skrócie:
  1. silnik MLX do uruchamiania (kroki 0, 2, 3);
  2. wtopienie nakładki v3 w wagi 16-bitowe;
  3. zamiana wag na 8 bitów;
  4. kalibracja na Macu w osobnym folderze `runs/v3_mlx_8bit/`;
  5. bramka jakości i porównanie.
- Nie używamy wersji FP8 ani 4-bitowych od osób trzecich.

## Kalibracja: jedna zasada

Każdy wariant to osobny folder w `runs/` z własną kalibracją. Pliku `meta.json` nie kopiujemy między wariantami.

| Wariant | Folder | Skąd kalibracja |
|---|---|---|
| NVIDIA, PyTorch, 16 bitów (wzorzec) | `expected/` | gotowa (2026-10-21, RTX 4080) |
| Mac, PyTorch, 16 bitów | `runs/v3_published/` | `python reproduce.py --published` |
| Mac, MLX, 8 bitów | `runs/v3_mlx_8bit/` | agent, `MLX_MIGRATION.md` sekcja 12 |

`out["calibration"]` mówi, gdzie liczono kalibrację, a gdzie model działa teraz. Gdy się różnią, status to
`"unvalidated"`, a każde pole dostaje powód przeglądu `calibration_not_for_this_machine`.

## Gdy coś nie działa

| Objaw | Co zrobić |
|---|---|
| brak pamięci | zamknij inne programy; przy 16 GB użyj ścieżki B (8 bitów) albo mniejszego modelu ([TRAIN_SMALLER.md](TRAIN_SMALLER.md)) |
| błąd „operation not supported on MPS” | skrypt ustawia `PYTORCH_ENABLE_MPS_FALLBACK=1`, więc brakująca operacja liczy się na CPU (wolniej, ale działa) |
| `calibration: unvalidated` | ten folder skalibrowano gdzie indziej: uruchom `python reproduce.py --published` na tym Macu |
| bramka nie przechodzi | nie zmieniaj progów ani danych; zgłoś wyniki (`reproduce.log`, `compare.md`) |
