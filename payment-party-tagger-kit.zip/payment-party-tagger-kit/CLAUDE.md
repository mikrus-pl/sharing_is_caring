# Claude Code guide for this package

The rules and the map of documents for every agent are in `AGENTS.md` (one source of truth, imported below).
Read it before doing anything; then the document it points to (`README.md`, `docs/RUN_MAC.md`, `docs/TRAIN_SMALLER.md`, `docs/MLX_MIGRATION.md` or `docs/CLOUD_GPU.md`).

@AGENTS.md
